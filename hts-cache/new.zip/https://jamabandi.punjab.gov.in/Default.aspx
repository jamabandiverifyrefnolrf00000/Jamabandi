
<!DOCTYPE html>

<html  lang="en">

<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="google" content="notranslate" /><title>
	ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records
</title><link rel="stylesheet" href="ui-assets/fontawesome/css/fontawesome.css" /><link rel="stylesheet" href="ui-assets/fontawesome/css/solid.css" /><link rel="stylesheet" href="ui-assets/vendor/bootstrap/dist/css/bootstrap.css" /><link href="ui-assets/sweetalert/sweetalert2.min.css" rel="stylesheet" /><link rel="stylesheet" href="ui-assets/vendor/datatables_with_buttons/datatables.min.css" />
    <!-- pe-icon-7-stroke styles -->
    <link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" /><link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/helper.css" />
    <!-- Custom styles -->
    <link rel="stylesheet" href="ui-assets/vendor/virtual-keyboard/css/keyboard.css" /><link rel="stylesheet" href="ui-assets/styles/style.css" /><link rel="stylesheet" href="ui-assets/styles/responsive.css" /><link rel="stylesheet" href="ui-assets/styles/plrs-custom-v1.0.css" /><link rel="stylesheet" href="ui-assets/styles/CardStyle.css" /><link rel="stylesheet" href="ui-assets/styles/custom.css" /><link href="ui-assets/landingPage/css/style.css" rel="stylesheet" type="text/css" /><link href="ui-assets/landingPage/css/flexslider.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="ui-assets/styles/select2.min.css" /><link rel="stylesheet" href="ui-assets/styles/selectStyle.css" /><link rel="stylesheet" href="ui-assets/styles/backToTop.css" /> 
    <style>
        .d-flex {
            display: flex;
        }

        .margin-left-right-auto {
            margin-left: auto;
            margin-right: auto;
        }

            .margin-left-right-auto h3 {
                color: #ffffff;
            }

        .head-legend {
            padding: 20px 0;
        }

            .head-legend span {
                font-size: 20px;
            }

        .digi-pub-footer-top {
            padding: 25px 0 10px;
        }
    </style>

        <link href="ui-assets/styles/plrsheader.css" rel="stylesheet" /><link href="ui-assets/styles/CrossBrowser.css" rel="stylesheet" />

    <script src="../ui-assets/jquery/jquery.min.js" nonce="cRAyoVO/laV5L9mW5DJlGw">
    </script>
    
    <script src="../ui-assets/jquery-ui/jquery-ui.min.js" nonce="cRAyoVO/laV5L9mW5DJlGw">
    </script>
    
    <script src="ui-assets/sweetalert/sweetalert2.all.min.js"
        nonce="cRAyoVO/laV5L9mW5DJlGw"></script>
    
    <script src="ui-assets/scripts/plrs-custom-v1.0.js" nonce="cRAyoVO/laV5L9mW5DJlGw">
    </script>
    
    <link href="ui-assets/Pgstyles/defaultpg.css" rel="stylesheet" />
<style>
    .margin-bottom-2 {
        font-size: 13px; /* base */
        padding:3px;
    }

    .margin-bottom-2 h3 {
        font-size: inherit !important;
        line-height: 1.3;
        margin: 0;
    }

    /* If anchor wraps it */
    .margin-bottom-2 a {
        font-size: inherit;
    }
        .card-icon {
            font-size: 2rem;
            color: #0d6efd;
        }
    </style>
        <!-- Modal Popup Animation CSS -->
    <style type="text/css">
        /* Scale + fade animation */
        .scale-modal .modal-dialog {
            -webkit-transform: scale(0.7);
            -moz-transform: scale(0.7);
            transform: scale(0.7);
            opacity: 0;
            transition: all 0.3s ease-out;
        }

        .scale-modal.in .modal-dialog {
            -webkit-transform: scale(1);
            -moz-transform: scale(1);
            transform: scale(1);
            opacity: 1;
        }
        .gif-badge {
            font-size:large;
            font-weight:600;
   /*background: gold;*/
    color: red;
    padding:3px 8px;
    margin-bottom:10px;
    border-radius: 5px;
    animation: blink 1s infinite;
}

@keyframes blink {
    50% { opacity: 0.4; }
}
    </style>



</head>


<body>
     
    <form method="post" action="./Default.aspx" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="MzOQZh4gWKrbcpPFO7j0nCOFZI23ZZvFC8Aim4/YVuQuDK6r6iYHgueIivWm25XD5A8C7mBFPGGntPPgN2i9pDh1JnBCWJg6MUQI09kVifE83PjM1m+jQroukAXNpTgM/lKdTe56HIw+UMIoZUBYG8MaRjKAWNBaPo7UiqEq1PE3iOp4OleqLtfwfE/F8OxqaUk4xXy3WcBPB9+J+WkK0lXyEz3EWjm8yCXy8O8iUTOyVPgguI6RC8Xhwh7cgCb5t2FE0IdWIoFkqgIIZ3vAM2Xre8OhvaZv3YFd7pq9lzq+61X2Js3ledHkcXPXisdJDjlDjdlLGRBHZsuWGgO834VTfqJ4fk+npF9lNdEyZtdNYOQbuidAnqu5fs/XOj8C/l6tIAbGb/1QRV4nbgDfbk59i1hq29XBe/6rDOk2dWU7XMcqmJ5uX7ZMInV6uvUsVIZDh4OhoSBksxJEekgX9LF5GYZJK5LY4Q8Q13nyfk9rn/Z+flmtgxC6joOVFQHgHYkX8JjtCJFiLRQc5UKCvNtSEjAReXdHAsnmiikfC2dO07kXgseB6Qgn7qPEefihhpzAWOfaz5he9rTGMPd8JrdNLh59fQZFtU5CC0PCZRcJgVhY+5s670gu/xaYOW6Ka/pA0YDo7dUcXULedR+RvDv3oIpTxIyt45Atx2x4DW3qZpPCC1LdlpbEATFjPu/OL5fP55VLRpxDXCap2sBGp0FI83qxksz0DvnRvj1R+SGlipMiIL++Er1h5Eg5TJ0GEGUXMpMPOaLBk2995yzIfAsgVpUo91c5JmEWnLpK912JAdxeJPLBgvU4n0UcomwVx355L447bIyY6o6dfs8ki9JZ9OVu/0qnpVreDvbCgoWSO8lU0wQsY/wDG4pPrAJEY+5ZLdmYJjOHA2UBJGwUkLBeIgE7edC8dTD23aetJ/A9Q7hGrr0HXYgPyjIuBidjA0khJJtRbFx+xVq+9/85O9wgJ2wJJEuoWsf9uzY7GYFj9tTyAtm2Pho1kFkH7u8iZ4GvivPitMKfmlk78eFPy8zZtaT5cbWD/+iM8awsphLKHtE9LZZj05vLy7IcynisHxrEvYfrt2F79yaiU8NkJCzrtUYUvlbp7M4oo8KI3v9R2xHrgsYvqIa2IK3xaRkLR/Cy+rud/TqXV0oBY7pyYWS28dkjJ0avKqIR9n8GgVDUfKzT3/dexncEXBVxbqcR8WGblQHs+79Cp8ZEOdkG0lQr4Oi2XaiJyAwkkdSliA1yQ3/TjO+d5FlkugtvfR8ssXS62rv83ZosRjWeRBfJXQBhEApbEnG2S5Mg40WTQbmyyFo9AN3YM5zDsnGBzPNIROnPZ4Dh+9kkHbYHnq28XrSy4jnTvoRJI3aJ7rgPT4sZhBDxlDMuSnyyrK9nUSgz27qqYatqYGyga2hZjZ02WLCw5F8QLrUUVsu/O1eibn9sDVEDPCDOmT1A8fJqLNspC0R7znbmnr6ai3YCQhwp9YCWSzH6YXKCRL68i6FCrzUddvPz3BprykjruHZTF5RRFD2qCG0PRs4+rqT97G/tJzNBsFlId6fiakFP86bFhVLe6qr2ILDJVIhdWh0JXJ9JA/9zVdOOB6cfEsuHr/FWGhZ0/UaDA2TF1YQuU2Y7J9Co2nyo7JS9aeT6nvOpnVTafv5U9q8Agsp60XHpVl02GhM9+KrJPKUtJFjsI53d7hnJZ3QXB41vbkWMpQtP3S/if5BXX602kHekXwzWc0Fsueq8YVuo48T7kR1TnqDhHWklkuytse+vf/o43iF4XZAxPjqWIKlDLXwYbtlnMeGZPopmBW1oleiNfRK50/zemzmVzh8f6xTwq0CtXj2EM1BfS+EDcWMNHATBphR9KSGrouMDVBG1DwewojMRR9Bw+gXxb6mJnFcFOW5CCUx1NcQEocTjqP7U6Aw8nlfug9HYmWQEwlcu76x+//EpoKR62lz2nA3ZAtd/zK3wfoiyFX4kna0JNzisjTeQV1MQu5SaPC+JsUNb6LNU1E/UsqOXAqKX+AWuSIm+kXcN8NN75eca1mOc/zC2UjbaPvQ2N6NfMKUarBZf63aMuTFLRio69VMMiAB3fUhTkD+eTP4I7D7f1CCU4iM7RBYFC3r4EADcBMpl//MXSgIYboTLhu1V+TXY9tj3Z2wes39aO9FqjKf7tYgQqFaI6zUssyafIP6PDH8FdN3AOu7Q5xD5MRS/6IINIL0sPp6f0xqhm7t3s5SRlzyPGOcbP6F+JGE9IqTtgXSuKIwwAApEHj2B/h0caJ+0Rsx6nHHFQPcKM4AVirZ/yUw5/vHPpJiCayoWClDfXuEZ+KdYuPNmCQi3iT9ZuYE5QoRCyGaJf5O+eLu5byXisQWV4ek1SvGbSvGBbloHvds0SN83uCrD0Ki2MdzoJgzwhTvNRHz6Pht0BikeS933mXSPJIZxlPa/iZJimNhFcph7PnKzT/+gvTJSkvSVVbUdduwHR1Q/2kzVqDMI9gGHbVV4xaELqOmk2nA4wUm9PRHz+URgUdSxS/Tc7m8caDIhJF1RAzNKHgSeeZLiv7ZDGsVbtSmsomYmWc2bRTza1ugDYYkFQklmlqErMhDZFfycTxkknDAvY0W11ZpiatB0NUoWtZpHaSLu6vReQFTOYhfWmyxw+mEe8jFgcLLGFaZ7mnzI7MzW63fe2k7B1ojar1k05G32gTweILH1tCf9Knwm30hV4RfcuudZ9PKxfRvCQoRoHaczst1mk0qoBkVD7IKaM+j/23Kw30an6CdyvIPhNV9BjiZcYlj6LK0hzbGhlbkL5tKU2AYG5I/kLhumcK0gDxZRVD7aJAMOe0h2gGKF5Uw5jRHs0pyS1Mv2eVOjKGMKihv/qNWU33xz2bDyrJI/+29lOXqUfk72VslvSDMrNMi/t59u/OnFdlJlHipD7xPRZQfffCV8c9/YtGI0nz8B5ca5U4N/X2Fvb0pX1C8klADVjJmD76lPJ3EpFM3xCpwKCmWp2VqF96u9XthucbxPc9Ri0/7vfgYCsQzIgDED9YGqzaFrWWqTzESr3CEPDwHOqHE4vF+N7Y+QVJwlIbQ2+l5euM0w2zoAJ3OzLq10TZfQmNpZQ2NraKLLHJhRbBAZFkAnivVvPV8KfZL1noCK5+CIepqHOPi9Ic3YGbVTJpoZErff4rhnsLYpbK+2J9DxpYlLFHVF4FgogFT/RKmB0MZaw8dNMNHoccJ5nEk7xz6nXpZ0RMEVS0HMNFZXXJFRL1XFGAz6DwPpHqxOQ3EcTjKYOFwEEWyt7W6YzjoV6OrjkE5vzNCnPFUytbnjbxN4Oni+f3oaSCSmgcrOxq+Nl0w14ZeHLWOT5BmGbCeJkvJ07RaykjT6LGR5amAzDr7tksYwAiMgKOWaWoXDU4iOb9GwbhewzLmuvHqOu2KgOfbCiyWuCQyxUKPObB3LTu5cRO6d7S8DbetuaHlEE28ZTskRKyDbMLkiFg9EQAsZIYu6QY17RgAzakXn04f2RRy6uZ165d1bN4fd3J9gb1eNlQLO/sTP3Qf1+vEVdgV1SoG2jRlS+XJ/qxCR0GszsM7DR0MPJjVhxBtkesh5pHR96JLRe6UkUJJq90aWXQdQPH0YMvw/foBXqCdnn1FVM9pgvCueHJyPP/7Ooaxpqoh+7jDRdW4YAmuPnoDM0t2U/vswykqDJeCJgd55c8O9WjCunedWBiWmfDG5AdPVcIQpoUQ8244SzLL11O8hTN6g7ZZi0KilmJ0iz1Csvr9CYNWIwGoKehAQ1fxtL+wPERmr7dYmTjfuxcgs0daLx2tsr+XE3cJhfOqLpholhxQOgAR11SQuRbzqtdnoyx+gFlaUlOs1wbU41wqPmNvTJPawuCKR6nUcylUrCmneFxMYns2T/TUcej9pXwSD2S2CCCLNCUzYpTTx1v9WWC5SK2DysmcUN6CYbWRas1YtroV36bDSchoSzxwJ56zCUK2lM+zG5YMnt1Opcp9+gePDlJSix82KLAFF0AK6gYszuZg0B86u8LNTd9zDDIRTtYbPgHDc8bF+Wg5m02WVEwcPcRWbDdYgH3oLE87nP/LZHLNJBwGo9KYRSlo2orK3VyniwnePVia96rY+LAhOY81xHLJpl8dZUXzWWeKW0KoxqEg3xPq8qzfwJ5/8iD1cvIod9LWpIq5VlvspbaWoCaenEwgqLO3UgbH92AGL0Fx0E9vyFaCKzMZSZANOaHDa7FXjL3y6V/AxfiGSzbBINhCVRu20ws/1IAW+PVFrPlq7hcWxjkOnqwy34oJjnVaopNtvMHHc1Xi+9LG9ggqQp9YKEOz6AlRXF07ejn1Oruoy230w9Yn2Zp1XEXoXtXA3jSQLNfENBFSQTuqqVw5n1wVcKl/vDUe84dSk5XZ+RXLysX7D8jNYgnaIWrNFYXQWoi/S+Nr/76LCqofOt1IJh4lvq2y3ikDe15q8aMfDrtdmcYsk98Idck9QiXlGzIbPhR8q8l5h62U4VTCr4ny1nLpNfeud0N69uE7n2QoJNmuvwTlZMdE6XPgwHeHDoNs0rcBbMgbWn6fvUwUU8VTh5ObpIu1K5bJF7vXhwlk7OTzukr10wpmA1qBeR9z1QOAGzWvHiphsMGU5ZarHrlP+DZO3gtGFeYZL69AFO3V5NYcsNgNHt2VOMl3jhVNDZ55z5BiT8jV4zVxaJv1SoPH7B6bylTVYE8kKmNrni1SkWcTprJwXV/XLyaH9/OqTc2gs/a6ATQcJiSMSKe7M30BqvAUhcigzknsDg7f3XMzohDxi6VK1aHZnFM0CUgKhMVJ7O48dwwFoPMPfjMfWFy/C7Zs/h3/kfp+A9z2NjQwy9674R1zZeKEmUmcKLamielvVMQH31LlQFOzcNai7lIpINlW36kj0xWj9tdWT8R8tClxH+RxCnY9ifQS7PcNzLbyYq0mdi4QW4cC/ofMFl4yf0WG5p2Wv5iBtFP0K+ZoCRyZ9weqizkAsxxMZleTdcRjfn85cZAvf2fEjQg1o3ni+Pl48xPSWCYDUYXtp8ZoBHoRIrRSp/L56XzPdxPYWUcvrFZz1Nc5h5rL1dTAMpKAensxbJ78w0Jjinp7IeGnkbbKzP5a3Am8Asl9hNGfeqRyZmnjpzG0z1N9H5++LqhbVB3/qh+Q1HvdCucK/OVfw4NMj5ZRNVYMW8LlPjksVNEurvQ8CEER4x6hXP++BvZlANw+7IqJK0C4/M7Dr2BAruniV9oDpGiFXGvoURIOybI1f7RJZYD4X7/ie9IT9f9uaNtKvN3GuRSgPabVijcS9UnWPotpxg+E43zcpIrkgQhZ/Do4Po5FgO6mLWHFqdPpA/qqwQKPdLz1zg3MG8s42G5ZH2oCJv+Xl2wPGLNdgcqp5ftcnHmtNinXUhlPYiNaLiJ+Z6laK7/UyLhUMRTSczLi+CCpX3RkEIbdwHVnel8j1WCAznrnBwRMNDhGfG1v6MSoEDzkVt6YB+9rl3OQfltPFLYqbevHEZ0wb/ALD30NZJlz1H/R098g+LNO9A3Bwxt/7/WmtCiMzbAB3Qrf02bQ+TAcL6z2xDqO8WGhS81ECha1BpqbdFN9FXFwlPAWzi4PhtQS8KlvwR18obEnfu/i76+FVW8jQx07FLavJmUPqzIXyZVe6S5rcM3WgiS3PlHhqJxWFCahqNeNt+yKj6QrFMnJMRAl8SFxP0ax7+nwV2Vhk4OqwM4Q5dEC6oNEOkTLzhpDePdPELT4S//T12VxUgsyYNpJ/cB09YiP76wDrP5qfL8kK4s2GpsuqP6m3j7tCH4WPJfeBIJSFlDdb9JifnJMHXMnBYnQQL5WGp3xZKOS7Y+7Toxjklrqo+vWw5vsEXFd87uvD/b8c4wS++kR3VjWoLmx9w+UGJ38sd8JiSqKHYJ0rwgOLTtFp1RkdaSf92iw/Ew17VWH/LQ1fwyD6wjadjRS2zZ6dQ/7z8U6ARmrx3/Zlkl7Rsv8wUuMX77HpVEjCoeM8VyJ4HaNU7zH9dZFg73eXcLWqoFkNNkM59S7Be4JZVLKJ7Ux0gHSsO2+8eL4somh19VhRLRSdsO1gBZpP1T3MlW+dPeKBXflu1VpOWiOOUB2okZMjeFlSBXH4B1C9tY0mvRCWKoweIwgIfHBeMjHya3G4/K4/2w5hM/EHw9V/Y1+/8sbpoP9xt47Ma3m122NjXlM1tYsCth0Q8dwJudHepOxO9+D4QNfMXpadQiMs0SNiOopj82enGm1EFHYRnTfYHxBA/Pvvh3rJYuSJxRRjHqGN5jYEogM1YH+mGV4d/1yLRLX9Mht5bQyGD/QLf4HMdGXbjS+pczXrSCD861AR1kUkaer2mIdbz/+IMTQZHRAZ6uZbQg1gs2WOFTqA4+lBGg0HTfXGmxm7ndPaNSp817DyVPWj+03YZdUkwnfadr0rHzGSR/xnrYWGqiQHU9pE6tebNvDtDSo6nGTGOOqFM+yrj5LzMzvXGSJpBA0rdNBzHxVFDN/xLfq59wpakZTZ1yRPbdGW9nWVFexjfP48Bhn5ysAn+moSpX1Kr5CYvlBfIyC3Q8V43R7BjbTD38zwS4htZDdwqFuJSRa6JEouOP7+iHi+e1bHv16R7ciJcfMJqr4x6+RZX1IuCDw83H8DNesGEukuaQu/t0XZ4feJmAjvddA7vFyC0TX5A1/hWJH/jn3+jCs23n5dnZIS17shH5K2LopfsaTo5vc2hVtLHWmZaL5shIDdbCj1srxoXsVOG3huer+NU/juxAWJJ3X/9U7ua8CL3CnZ9U+fewscD4DszD98mLjWNvhJY2h0F+SJlCrRUcn6R4fJ1YPeBdQrssVifs8OQWutSjo0kLgJQZR2KVK2+FjEcOP+Sa4thGp0Wn9r9d6MjrQ1OzBjlPTdzQUuTjCV6pm9V7z+nnVAWGvpJ52spcPC4LO2tkzGSXjxVjeTRNyd0eMwb9ypcF7lCnZR0zCyrbOcde6cFwPSVsiwhtrd1OFw5Pg9" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZBbRI-vLFGPASeYxh_KgLGJAGhxxxQHaAFUowMEJ38zbzJMIHhOPM0QVtz7ClVSrJw2&amp;t=639202794265548063" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvqBoWBYTDUGuawA_2GYbNQlKfMSt2G6fTRv2v_CvkMQC-NDKOxcBHZBsr4m43UZoWnDElLWlfRSMae7wFN5-j848Bfbquym3Qmm_a4KPTP8MlNJWDtdRKeoXno9ND71Mj-dmT4RATMPqWph8tRm5et41&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OAh7tEdde-lvG3-30egxXz8aAgw_K6hDRuGQnL44pJNvGX0k88IpkhwtBpf_hp5FI_xl-S6IOzDAoSwTftgBkdwIVbozv2itakdYRoj6lyvW2iAmc3lxcxcAsYCLcWBMdMG64QNAlb5JWK1NKm4PkKk1&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div>
        <div>
     <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', [], [], [], 600, 'ctl00');
//]]>
</script>

              <button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-topD">
  <i class="fas fa-arrow-up"></i>
</button>
<!-- Simple splash screen-->
<div class="splash"> 
    <div class="color-line"></div>
    <div class="splash-title">
        <h1>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h1>
        <p>ਕਿਰਪਾ ਕਰਕੇ ਉਡੀਕ ਕਰੋ ਜਦੋਂ ਤੱਕ ਅਸੀਂ ਤੁਹਾਡੇ ਲਈ ਖੋਜ ਮੋਡੀਊਲ ਨੂੰ ਸੈਟਅਪ ਕਰਦੇ ਹਾਂ./Please wait while we setup the search module for you. </p>
        <img src="ui-assets/images/loading-bars.svg" width="64" height="64" /> 
    </div> 
</div>
        <div id="updWebsite" style="display:none;">
	
				<div class="loadingContainer">
					<div class="loading">
						<img src="ui-assets/images/loading-bars.svg" alt="Loading.." width="64" height="64" />
						&nbsp;
					&nbsp;
					</div>
				</div>
			
</div>
           <div id="header">
            <div id="plrs-header">
                 
    <div class="plrs-header-row">
     
        <!-- LOGO -->
        <div class="plrs-left">
        <div class="plrs-logo">
            <img src="ui-assets/images/logo.png" alt="Punjab Land Records" />
            <div class="plrs-logo-text">
                ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼

                <span>Punjab Land Records</span>
            </div>
            
        </div>
            
        <div class="plrs-menu header-link hide-menu"><i class="fa fa-bars"></i></div>
            </div>
        <!-- REGION -->
        <div class="plrs-region plrs-page-title">
        <div class="plrs-title-pa">
        ਈਜੀ ਜਮ੍ਹਾਬੰਦੀ
    </div>
    <div class="plrs-title-en">
        EASY JAMABANDI
    </div>
        </div>
        <!-- ACTIONS -->
        <div class="plrs-actions">
            <div class="plrs-font">
                 <input type="button" id="btnincreasefonts"  value=" A+ " />
                 <input type="button" id="btndecreasefonts"  value=" A- " />
                 <input type="button" id="btnresetfonts" value=" A= " />
            </div>

            <a href="Login.aspx" class="plrs-login">
                <i class="fa fa-lock"></i>
                Official Login
            </a>
        </div>

    </div>
            
</div>

</div>

        <div id="divBackground" class="modal">
        </div>

   
<link href="../ui-assets/Pgstyles/uc_navugatonmenu.css" rel="stylesheet" />
<!-- Navigation -->
<aside id="menu">
	<div id="navigation">
		<nav class="nav-primary">
			<ul class="nav">
				
				
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl00_liItem">
							<a href="OnlineRequestStatus.aspx?itemPID=77">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl00_bBG" class="bg-info"></b>
								</i>
								
								<span>ਟਰੈਕ ਐਪਲੀਕੇਸ਼ਨ/Track Application</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl01_liItem">
							<a href="./?itemPID=82">
								    
                                    <i class='fa-solid fa-file-export'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl01_bBG" class="bg-warning"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl01_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਸ਼ਿਕਾਇਤ ਨਿਵਾਰਨ/Grievance Redressal</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl01_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl01_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Grievance.aspx?RefNo=1&itemID=83&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl01_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦਾਖਲ ਕਰੋ/Submit Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl01_repNavigationMenuLevel2_ctl01_liItem">
											<a href="GrievanceTrack.aspx?RefNo=2&itemID=84&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl01_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦੀ ਜਾਂਚ ਕਰੋ/Track Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_liItem">
							<a href="Jamabandi.aspx?itemPID=3">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl02_bBG" class="bg-primary2"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl02_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਜਮ੍ਹਾਂਬੰਦੀ ਵੇਖੋ/View Jamabandi</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl02_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Jamabandi.aspx?section=Owner-Name-Wise&itemID=7&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਮਾਲਕ ਦੇ ਨਾਮ ਮੁਤਾਬਕ/Owner Name Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Jamabandi.aspx?section=Khewat-Number-Wise&itemID=8&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖੇਵਟ ਨੰ: ਮੁਤਾਬਕ/Khewat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl02_liItem">
											<a href="Jamabandi.aspx?section=Khasra-Number-Wise&itemID=9&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl02_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਸਰਾ ਨੰ: ਮੁਤਾਬਕ/Khasra No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl03_liItem">
											<a href="Jamabandi.aspx?section=Khatouni-Number-Wise&itemID=10&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl03_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਤੌਨੀ ਨੰ: ਮੁਤਾਬਕ/Khatouni No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_liItem">
							<a href="Mutation.aspx?itemPID=4">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl03_bBG" class="bg-success"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl03_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਇੰਤਕਾਲ ਵੇਖੋ/View Mutation</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl03_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Mutation.aspx?section=Mutation-Number-Wise&itemID=13&itemPID=4">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਇੰਤਕਾਲ ਨੰ: ਮੁਤਾਬਕ/Mutation No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_liItem">
							<a href="Roznamcha.aspx?itemPID=5">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl04_bBG" class="bg-danger"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl04_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਰੋਜਨਾਮਚਾ ਵੇਖੋ/View Roznamcha</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl04_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Roznamcha.aspx?section=Rapat-Number-Wise&itemID=11&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਰਿਪੋਰਟ ਨੰਬਰ ਮੁਤਾਬਕ/Rapat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Roznamcha.aspx?section=Waqiati-Number-Wise&itemID=12&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਵਾਕਿਆਤੀ ਮੁਤਾਬਕ/Waqiati No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_liItem">
							<a href="RegistryDeed.aspx?itemPID=21">
								    
                                    <i class='fa-regular fa-copy'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl05_bBG" class="bg-info"></b>
								</i>
								
								<span>ਰਜਿਸਟਰਡ ਡੀਡ ਵੇਖੋ/View Registered Deed</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl06_liItem">
							<a href="FardStatus.aspx?itemPID=29">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl06_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਫਰਦ ਬੇਨਤੀ ਸਥਿਤੀ/Fard Request Status</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl07_liItem">
							<a href="GroundTruthingDataMap2.aspx?itemPID=85">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl07_bBG" class="bg-primary2"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-2 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-2 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl08_liItem">
							<a href="GroundTruthingDataMap3.aspx?itemPID=86">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl08_bBG" class="bg-success"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-3 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-3 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl09_liItem">
							<a href="IPWTD.aspx?itemPID=15">
								    
                                    <i class='fa fa-university'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl09_bBG" class="bg-danger"></b>
								</i>
								
								<span>ਇਨਟੈਗਰੇਟਿਡ ਜਾਇਦਾਦ/Integrated Property</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl10_liItem">
							<a href="faq.aspx?itemPID=33">
								    
                                    <i class='fa fa-question-circle'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl10_bBG" class="bg-info"></b>
								</i>
								
								<span>ਐੱਫ ਏ ਕਿਊ/FAQ</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl11_liItem">
							<a href="UserManual.aspx?itemPID=35">
								    
                                    <i class='fa fa-user'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl11_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਉਪਯੋਗ ਪੁਸਤਕ/User Manual</span>
                                 
							</a>
							
							
							
                            
						</li>
					
                				
			</ul>
		</nav>
	</div>
</aside>


<!-- Main Wrapper Content Place Holder-->
<div id="wrapper">
       <div class="page-body">
    <div class="content animate-panel">
       
	
 <!-- Modal (only on Default.aspx) -->
       <div id="RanglaPunjabModal" class="modal fade scale-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" style="width:auto; max-width:90%; display:flex; align-items:center; justify-content:center; height:100vh;">
            <div class="modal-content" style="border:none; background:transparent; position:relative; display:inline-block;">

                <!-- Close Button -->
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        style="position:absolute; top:-5px; right:1px; font-size:30px; color:red; opacity:1; z-index:10;">
                    &times;
                </button>

                <!-- Image Wrapper with White Background + Drop Shadow -->
                <a href="https://rangla.punjab.gov.in/" target="_blank" style="display:block; position:relative;">
                    <div style="background:white; padding:15px; display:inline-block; box-shadow:0 4px 15px rgba(0,0,0,0.3); border-radius:3px;">
                        <img src="img/RP-Banner-564x370.png" alt="RanglaPunjab" class="img-responsive"
                             style="width:100%; max-width:564px; height:auto; display:block;" />
                    </div>
                </a>

            </div>
        </div>
    </div>



	<div class="content transition animated fadeIn">
		<div class="panel hpanel dblue">

			<div class="panel-body">
				<div class="form-horizontal">

                     <div class="row">
                                 <div class="col-md-12 m-t-sm">
                                <fieldset id="ContentPlaceHolder1_fsOnlineFard">

											
                                    <div class="dvNakalType" >
                                        <div class="head-legend text-capitalize text-center">
                                        	<span id="ContentPlaceHolder1_lbllgFardIssueInfo" class=" badge-pillLegend" style="font-weight:bold;">ਔਨਲਾਈਨ ਸੇਵਾਵਾਂ/Online services</span>
                                            <br />
                                        </div>
<div class="row">
<div class="col-md-3 margin-bottom-2">
  
</div>
                                                <div class="col-md-6 margin-bottom-2">
                                                     
                                                        <div class="Mutation-corner-col text-center">
                                                          
                                                             
														<a href="RequestForPartition.aspx">
  <span class="gif-badge">***** NEW *****</span>
                                                                <h3> </h3><br />
                                                           
                                                               <h3 class="card-title"> 
                                                                   ਮੁੱਖ ਮੰਤਰੀ ਦੀ ਸਕੀਮ - 30 ਦਿਨਾਂ ਵਿਚ ਤਕਸੀਮ<br/>Oral/Family Partition 

                                                               </h3>
														</a>
                                                           
													</div>
                                                     
                                                  </div>
                                             <div class="col-md-3 margin-bottom-2">
  
</div>
                                         </div>

                                        <hr />
											<!-- Nakal Type Menus Section Start-->
                                            <div class="row">
											
                                                <div class="col-md-6 margin-bottom-2">
                                                        <div class="Mutation-corner-col text-center">
                                                             
														<a href="DigitalFard.aspx">
                                                           

                                                                <h3> <span></span></h3>
                                                               <h3> ਵਟਸਐਪ ਤੇ ਜਮ੍ਹਾਂਬੰਦੀ<br/>Jamabandi on WhatsApp</h3>
														</a>
													</div>
                                                    </div>
                                                <div class="col-md-6 margin-bottom-2">
                                                        <div class="Mutation-corner-col text-center">
                                                             
														<a href="RequestForVirasatMutation.aspx">
                                                          

                                                                <h3> <span></span></h3>
                                                               <h3>ਵਿਰਾਸਤ ਦਾ ਇੰਤਕਾਲ<br />Mutation of Inheritance</h3>
														</a>
													</div>
                                                    </div>
                                                 </div>
                                         <div class="row">
                                                <div class="col-md-6 margin-bottom-2">
                                                        <div class="Mutation-corner-col text-center">
                                                             
														<a href="RequestForRegisteredVasika.aspx">
                                                           

                                                                <h3> <span></span></h3>
                                                               <h3>ਵਸੀਕੇ ਦੇ ਆਧਾਰ ਤੇ ਇੰਤਕਾਲ<br />Mutation on the basis of Deed</h3>
														</a>
													</div>
                                                    </div>
                                               
                                        
                                               
                                                    <div class="col-md-6 margin-bottom-2">
                                                        <div class="Mutation-corner-col text-center">
                                                             
														<a href="RequestForFardbadar.aspx">
                                                            

                                                                <h3> <span></span></h3>
                                                               <h3>ਫਰਦ ਬਦਰ<br />Fard badar</h3>
														</a>
													</div>
                                                    </div>

                                              </div>
                                         <div class="row">

                                                    <div class="col-md-6 margin-bottom-2">
                                                        <div class="Mutation-corner-col text-center">
                                                             
														<a href="RequestForRapat.aspx">
                                                           

                                                                <h3> <span></span></h3>
                                                               <h3>ਰਪਟ<br />Rapat</h3>
														</a>
													</div>
                                                    </div>
                                                    <div class="col-md-6 margin-bottom-2">
                                                        <div class="Mutation-corner-col text-center">
                                                             
														<a href="Subscription.aspx">
                                                           

                                                                <h3> <span></span></h3>
                                                               <h3>ਸਬਸਕ੍ਰਿਪਸ਼ਨ<br />Subscription</h3>
														</a>
													</div>
                                                    </div>


                                            </div>
                                        
											<!-- Nakal Type Menus Section End-->

										</div>
									</fieldset>
                                </div>
                            </div>

				</div>
			</div>
		</div>
	</div>



            
            
            
            
            
            
            
    </div>
           </div>
    <!-- Footer-->


    <footer class="footer footer-font">

    <!-- Notes -->
    <div class="digi-topBoderThickDis">
        <div class="container-fluid">
            <div class="footer-notes">
                <ul>
                    <li>ਤੁਹਾਨੂੰ ਦਫ਼ਤਰ ਆਉਣ ਦੀ ਲੋੜ ਨਹੀਂ/ No Physical visit is required</li>
                    <li>ਡਾਟਾ ਰੀਅਲ ਟਾਈਮ ਵਿੱਚ ਤਿਆਰ ਕੀਤਾ ਜਾਂਦਾ ਹੈ/ Data is generated in real time</li>
                    <li>ਡਿਜ਼ੀਟਲ ROR 2002 ਤੋਂ ਉਪਲਬਧ ਹੈ/ Digital ROR is available since 2002</li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Govt -->
    <div class="digi-topBoder">
        <div class="container-fluid text-center">
            <span>ਮਾਲ, ਮੁੜ ਵਸੇਬਾ ਅਤੇ ਆਪਦਾ ਪ੍ਰਬੰਧਨ ਵਿਭਾਗ,ਪੰਜਾਬ ਸਰਕਾਰ, ਭਾਰਤ / Department of Revenue, Rehabilitation and Disaster Management, Government of Punjab, India.
            </span>
        </div>
    </div>

    <!-- Copyright -->
    <div class="digi-topBoder">
        <div class="container-fluid text-center">
            <span>ਕਾਪੀਰਾਈਟ © 2025 ਪੰਜਾਬ। ਸਾਰੇ ਹੱਕ ਰਾਖਵੇਂ ਹਨ। / Copyright © 2025  Punjab. All rights reserved.
            </span>
        </div>
    </div>

    <!-- Stats -->
    <div class="digi-topBottomBoder footer-stats">
        <div class="container-fluid">
            <div class="footer-stats-row">
                <span class="badge-pill">
                    ਕੁੱਲ ਵਿਜ਼ਿਟਰ/Total Visitors :

                    <span id="lblv">2380019</span>
                </span>

                <span class="badge-pill">
                    ਆਖਰੀ ਵਾਰ ਅੱਪਡੇਟ ਕੀਤਾ/Last Updated :

                    <span id="lblud">12/10/2026</span>
                </span>
            </div>
        </div>
    </div>

</footer>





</div>

  <script src="ui-assets/vendor/bootstrap/dist/js/bootstrap.min.js" nonce="cRAyoVO/laV5L9mW5DJlGw"></script>
        <script src="ui-assets/vendor/datatables_with_buttons/datatables.min.js"
            nonce="cRAyoVO/laV5L9mW5DJlGw"></script>
        <script src="ui-assets/vendor/virtual-keyboard/js/keyboard.js" type="text/javascript"
            nonce="cRAyoVO/laV5L9mW5DJlGw"></script>
        <!-- App scripts -->
        <script src="ui-assets/scripts/homer.js" nonce="cRAyoVO/laV5L9mW5DJlGw">
        </script>
        <script src="ui-assets/Pgscript/masterpg.js" nonce="cRAyoVO/laV5L9mW5DJlGw">
        </script>
        <script src="ui-assets/scripts/select2.min.js" nonce="cRAyoVO/laV5L9mW5DJlGw" > </script>    
        <script src="ui-assets/scripts/BackToTopN.js" nonce="cRAyoVO/laV5L9mW5DJlGw" > </script>    
</div>
    

<script type="text/javascript">
//<![CDATA[
Sys.Application.add_init(function() {
    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":500,"dynamicLayout":true}, null, null, $get("updWebsite"));
});
//]]>
</script>
</form>

</body>

    </html>
