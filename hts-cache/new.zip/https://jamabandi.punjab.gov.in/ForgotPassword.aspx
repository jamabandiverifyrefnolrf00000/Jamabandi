

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><title>
	ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records
</title>

    <!-- Vendor styles -->
    <link href="../ui-assets/vendor/bootstrap/dist/css/bootstrap.css" rel="stylesheet" /><link href="../ui-assets/sweetalert/sweetalert2.min.css" rel="stylesheet" />

    <!-- App styles -->
    <link rel="stylesheet" href="../ui-assets/styles/style.css" /><link href="../ui-assets/styles/plrs-custom-v1.0.css" rel="stylesheet" />
      <script type="text/javascript">
        var seconds = 120;
        var timer;

        function startCountdown() {
            seconds = 120;
            document.getElementById("btnResend").disabled = true;
            timer = setInterval(function () {
                seconds--;
                document.getElementById("lblTimer").innerHTML =
                    "Resend OTP in " + seconds + " sec";

                if (seconds <= 0) {
                    clearInterval(timer);
                    document.getElementById("btnResend").disabled = false;
                    document.getElementById("lblTimer").innerHTML = "";
                    //document.getElementById("lblMsg2").innerHTML = "";
                    document.getElementById("lblMsg").innerHTML = "";

                }
            }, 1000);
        }

    </script>
     <style>
        body {
            font-family: Segoe UI, Arial;
            background: #f2f4f7;
        }

        .card {
            width: 420px;
            margin: 60px auto;
            background: #fff;
            padding: 25px;
            border-radius: 6px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }

            .card h2 {
                margin-top: 0;
                font-size: 20px;
                text-align: center;
            }

        /*.form-group {
            margin-bottom: 15px;
        }*/

        label {
            font-weight: 600;
            display: block;
            margin-bottom: 5px;
        }

        input[type=text] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-primary {
            background: #007bff;
            color: #fff;
        }

        .btn-success {
            background: #28a745;
            color: #fff;
        }

        .otp-box input {
            text-align: center;
            letter-spacing: 4px;
            font-size: 18px;
        }
        .msg {
            margin-top: 10px;
            font-weight: 600;
            color: red;
            text-align: center;
        }

        .success {
            color: green;
        }
    </style>

</head>
<body>
    <form method="post" action="./ForgotPassword.aspx" onsubmit="javascript:return WebForm_OnSubmit();" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="+aNxgCUPIF3Ms91X2kl7ts5lwidTremPskW37zsPSQEYe9wUwWjWj0Ka75UdZfWGrsX0rsrBjWUe9A8+74sJnZirhZAcqw75p5I7bPqs2NgIblwbCEyen4BaeTQNU+ctPFBH0Dlz8BDr8snjNQUmNvCZiZNwiX4WvnlXWtgPgPmr4iKtxtSDN+pvY9fdW4LdZxiaEtOC95+2QQGqb3TSzQgHXg9tsu5SA8voyXLAPXpG7sjHLtRXWgYcns3M1fh4RyoKmF0oO1Y5PrscBXy6xMjxHczec27mSf6nHZvV8NLgykPPVn3me7G/ALJx0oE5iTyPuk8QiiicPMOKxmO///bvqJdyhnWH092XLYhiUwtRsRi1DbSgQStknMJdFnQP" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZBbRI-vLFGPASeYxh_KgLGJAGhxxxQHaAFUowMEJ38zbzJMIHhOPM0QVtz7ClVSrJw2&amp;t=639202794265548063" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1HoTsDJCIwegf7-cSVNQxKlxqJplUAag2gjZMR_ctGyeKzMDbl61mq8CG1bXK2cKIO5F_d_eACHU7rvEovdRsHjPwMxL_2RbhdHxnXThSzdTd55hY37B50zmwPwIsJ1FnQ2&amp;t=4623e90" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvqBoWBYTDUGuawA_2GYbNQlKfMSt2G6fTRv2v_CvkMQC-NDKOxcBHZBsr4m43UZoWnDElLWlfRSMae7wFN5-j848Bfbquym3Qmm_a4KPTP8MlNJWDtdRKeoXno9ND71Mj-dmT4RATMPqWph8tRm5et41&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OAh7tEdde-lvG3-30egxXz8aAgw_K6hDRuGQnL44pJNvGX0k88IpkhwtBpf_hp5FI_xl-S6IOzDAoSwTftgBkdwIVbozv2itakdYRoj6lyvW2iAmc3lxcxcAsYCLcWBMdMG64QNAlb5JWK1NKm4PkKk1&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="C633E78B" />
	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0" />
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="HAi4OMzlSUGmMdwCcUdRmfhA5F0uJCkcINJ1uKpnl158AJLE93rdTGPztI9vmlIYmHHBbjC0Rs76BglbqUpdsYnSBydv7CgFdLdrZ3XuXOe204n9QfXsEcjHonExZxEw2TexrpVVV7fbTqgdOh5uLZRFjhQ9p88I45ZlGRkPU57psi6b9/KWXPtXGS4z7wRV8SVHH427blEi3ScuMGbHX4jvzFrOzv/NoaKxJ1h3KsI=" />
</div>
        <input type="hidden" name="__CSRFToken" id="__CSRFToken" value="e198c20b8b9447bf8c3ea5d626acbab6" />
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ScriptManager1', 'form1', ['tupdLogin','updLogin'], [], [], 90, '');
//]]>
</script>

        <div class="splash">
            <div class="color-line"></div>
            <div class="splash-title">
                <img src="../ui-assets/images/pbLogo_84x101.png" />
                <h1>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h1>
                <p>Please wait while we setup the module for you. </p>
                <img src="../ui-assets/images/loading-bars.svg" width="64" height="64" />
            </div>
        </div>
        <div id="updWebsite" style="display:none;">
	
                <div class="loadingContainer">
                    <div class="loading">
                        <img src="../ui-assets/images/loading-bars.svg" width="64" height="64" />
                    </div>
                </div>
            
</div>
        <div class="color-line"></div>
        

        <div class="login-container">
            <div class="hpanel">
                <div class="panel-body">
                    <div class="row">

                        <div class="col-md-12">
                            <div class="text-center m-b-md">
                                <img src="../ui-assets/images/pbLogo_64x77.png" width="50" height="50" />
                                <h4>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records
                                <br /><br />Reset Password
                                    </h4>
                                  <br />
                            </div>

                            <div class="form-group" style="border-top: solid; border-top-color: black; border-top-width: thin;">
                                <div id="updLogin">
	

                            <fieldset id="pnlUpdate" class="form_ font-resize-scope" style="background-color: white">
                                
                            

                                       
                                            <div class="form-group">
                                                <label class="control-label" for="username">Username</label>
                                                <input name="txtUserName" type="text" id="txtUserName" class="form-control" placeholder="Please enter username" />
                                                <span id="reqUname" class="text-danger" style="display:none;">Required.</span>
                                            </div>
                                            <div class="form-group">
                                                <img id="imgCaptcha" src="GenerateCaptcha.aspx?639274832565274606" />
                                                <input type="submit" name="btnRefresh" value="Refresh" id="btnRefresh" class="btn btn-success" />
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label" for="captcha">Enter Captcha</label>
                                                <input name="txtCaptcha" type="text" id="txtCaptcha" class="form-control" style="width:200px;" />
                                                <span id="reqCaptcha" class="text-danger" style="display:none;">Required.</span>
                                            </div>
                                            <input type="submit" name="btnSendOtp" value="Send OTP to Registered Mobile" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;btnSendOtp&quot;, &quot;&quot;, true, &quot;login&quot;, &quot;&quot;, false, false))" id="btnSendOtp" class="btn btn-primary btn-block" />
                                        
                                            <span id="lblMsg" class="msg"></span>                                            
                                        
                                </fieldset>

                                        
    <!-- STEP 2 : OTP VERIFICATION -->
        
       <!-- STEP 3 : Update Password-->
                                           
                                        
                                        <input type="hidden" name="hdnfld" id="hdnfld" value="$2a$10$n2y0Bq6gxEFjGz1lekIEte" />

                                    
</div>
                            </div>
                        </div>
                        
                    </div>
                    
                    <div class="row" style="border-top: solid; border-top-color: black; border-top-width: thin">
                        <div class="col-sm-12 text-right" style="border-top: solid; border-top-color: black; border-width: thin">
                            <a href="Default.aspx" style="color: blue; text-decoration: underline"><- Back to Home Page</a>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    
<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("reqUname"), document.getElementById("reqCaptcha"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var reqUname = document.all ? document.all["reqUname"] : document.getElementById("reqUname");
reqUname.controltovalidate = "txtUserName";
reqUname.focusOnError = "t";
reqUname.errormessage = "Required.";
reqUname.display = "Dynamic";
reqUname.validationGroup = "login";
reqUname.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
reqUname.initialvalue = "";
var reqCaptcha = document.all ? document.all["reqCaptcha"] : document.getElementById("reqCaptcha");
reqCaptcha.controltovalidate = "txtCaptcha";
reqCaptcha.focusOnError = "t";
reqCaptcha.errormessage = "Required.";
reqCaptcha.display = "Dynamic";
reqCaptcha.validationGroup = "login";
reqCaptcha.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
reqCaptcha.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        
theForm.oldSubmit = theForm.submit;
theForm.submit = WebForm_SaveScrollPositionSubmit;

theForm.oldOnSubmit = theForm.onsubmit;
theForm.onsubmit = WebForm_SaveScrollPositionOnSubmit;
Sys.Application.add_init(function() {
    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":500,"dynamicLayout":true}, null, null, $get("updWebsite"));
});

document.getElementById('reqUname').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('reqUname'));
}

document.getElementById('reqCaptcha').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('reqCaptcha'));
}
//]]>
</script>
</form>
    <script src="../ui-assets/jquery/jquery.min.js"></script>
    <script src="../ui-assets/vendor/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../ui-assets/scripts/select2.min.js"></script>

    <script src="../ui-assets/scripts/JCrypt.js"></script>
    <!-- Vendor scripts -->
    <script src="../ui-assets/sweetalert/sweetalert2.all.min.js"></script>
    <!-- App scripts -->
    <script src="../ui-assets/scripts/homer.js"></script>
    <script src="../ui-assets/scripts/bank-custom-v1.0.js"></script>

</body>
</html>
