
<!DOCTYPE html>
<html lang="en">


<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="google" content="notranslate" /><title>
	ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records
</title><link rel="stylesheet" href="ui-assets/fontawesome/css/fontawesome.css" /><link rel="stylesheet" href="ui-assets/fontawesome/css/solid.css" /><link rel="stylesheet" href="ui-assets/vendor/bootstrap/dist/css/bootstrap.css" /><link href="ui-assets/sweetalert/sweetalert2.min.css" rel="stylesheet" /><link rel="stylesheet" href="ui-assets/vendor/datatables_with_buttons/datatables.min.css" />
    <!-- pe-icon-7-stroke styles -->
	<link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" /><link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/helper.css" />
	 <!-- Custom styles -->
    
    <link rel="stylesheet" href="ui-assets/vendor/virtual-keyboard/css/keyboard.css" /><link rel="stylesheet" href="ui-assets/styles/style.css" /><link rel="stylesheet" href="ui-assets/styles/responsive.css" /><link rel="stylesheet" href="ui-assets/styles/plrs-custom-v1.0.css" /><link rel="stylesheet" href="ui-assets/styles/CardStyle.css" /><link rel="stylesheet" href="ui-assets/styles/custom.css" /><link href="ui-assets/landingPage/css/style.css" rel="stylesheet" type="text/css" /><link href="ui-assets/landingPage/css/flexslider.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="ui-assets/styles/select2.min.css" /><link rel="stylesheet" href="ui-assets/styles/selectStyle.css" /><link rel="stylesheet" href="ui-assets/styles/backToTop.css" /> 
<style>
    .d-flex{
        display:flex;
    }

    .margin-left-right-auto{
        margin-left:auto;
        margin-right:auto;
    }

    .margin-left-right-auto h3 {
      color: #ffffff;/*#126f00*/
    }

    .head-legend {
      padding: 20px 0;
    }

    .head-legend span {
      font-size: 20px;
    }

    .digi-pub-footer-top{
        padding: 25px 0 10px;
    }
</style>
    <style>
#SelectRegion_rdPeriod {
  height: auto;
}
</style>
    
    <link href="ui-assets/styles/plrsheader.css" rel="stylesheet" />

     <script   src="ui-assets/jquery/jquery.min.js" nonce="pdjtQd0U/BpiZDgAEyYFJg">
	</script>
	
    <script   src="ui-assets/jquery-ui/jquery-ui.min.js" nonce="pdjtQd0U/BpiZDgAEyYFJg" >
    </script>
       
     <script src="ui-assets/sweetalert/sweetalert2.all.min.js" 
        nonce="pdjtQd0U/BpiZDgAEyYFJg" ></script> 
           
    <script src="ui-assets/scripts/plrs-custom-v1.0.js" nonce="pdjtQd0U/BpiZDgAEyYFJg">
	    </script>

    <link href="ui-assets/fontawesome-free/css/all.min.css" rel="stylesheet" />
    <link href="ui-assets/styles/modalp.css" rel="stylesheet" />
    <link href="ui-assets/styles/HightLightFocus.css" rel="stylesheet" />
    <link href="ui-assets/jquery-ui/jquery-ui.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/reqRV.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/tblbrder.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/lnkbtn.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/rdbtn.css" rel="stylesheet" />

    <script src="ui-assets/Pgscript/MaintaineScrollbarPosition.js"></script>
    <script src="ui-assets/scripts/HightLightFocus.js"></script>
    <script src="ui-assets/Pgscript/reqRV.js"></script>


</head>
<body class="bg">
  
	<form method="post" action="./RequestForRegisteredVasika.aspx" onsubmit="javascript:return WebForm_OnSubmit();" id="form1" enctype="multipart/form-data">
<div class="aspNetHidden">
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="0zqcLoESFWx7C2n7GbbI5CscFTy7LOlFuJNIC0JM1z+LxrHZfIxYS8WWVl0pnV7i6yR+tjRa7bJIV8T4WzNyCSebxwu7/doQneA+yhYD9EREKIj9FCUD6/aVIEbRaVjCKVxsDYy4FBciFyD2O2ortQzC8/oOjx2pWXdL1cC3Erq1wNITvwdaeaypIFowT+IruN/gnrx6eMHV76DLghW5N3JypZJduMghelIWUmoN1ohuXVMgLb7ajfI+VMZUDFMrTBaFJBCadNl/MdwCuy2Kw4+fuOynON4AEaVD7WbKTpTmaMgvznhMrhaqPRCzmg27/yOxQjK0wh6Pvhb1vKsMBoC5O4cdACDImlFmDkzwZPcfDS4SKjoDXgZmAR2T/30TsGf+qlbrSu7A7ja8FksOmGIl0fMArcOj2QAtSyMLPTs8ViPnoLVXskmhUQrAPRRN7iX8o9YvfzQCLX/Z7bNNL4dz8c8/1Fxv3t65nDAmz1KpX2StVOr0gOwgv++g4PEcTh0yNNeqHfJq3bLqrDxQMLgxoCvXxwkma+shNz+NkBHcB58lP8vRioUdYlhxAxbiHb+CZhl9sahh2cHzz3urrP4tHkacxbGwNhbkIidlqvaqN36LxL/kzxgiJ0MrYmMFnI9lioKr8JDyJo54tPpWPeDZ3kxu9d4yoTcHgEDAbGvn1P3p5Zlqj+x8bn1R4HaP2IQFusgl2DDFaQUV1EJiYgFumvd5ARm6uSSYKlhtvtmqHKEfra+VtR29Q5IwCYETL8IELBHZBMdHMqV+jIZbdeOFvOXQqnxeVrjCIo61DeMfPmOhXsxg5k4kH6LdGUZhO1UmBM0qo3adFS8XudApSOPJFZ3NYI3D6tvSeAUZNfQHuMwTiJeBzfyFGlA6lAJHVaUDTAm4ts3dNF97EBsRsDUtRjWN8MKpULo5eb7SOUMbkNZh2FYSjA8TaDp1pE7nx7xpclkrU3aWjhqkqTsuSGTCdAi5nXSHnL/mW2lFOC+T9c9RxbOTYT7uOMTRru/Z+wZDIPoTzq1lhvjmXT75oY1wNvx2W3VOQsSKnacOnzbv8XCs8RPCc0vpoUJCNnM3LQbSl1fcHVlNjYt/uqh0qj739XiLxaRNSA0Gj7KKdcaEA0AE0/IqTDqf/qlhBAJvmzpXI3Crj1bM/WWueN8X7MoxV/UZ62E/TkOGmf/eOq81l4DvCX4/8dzoNumdwHX89jzk0hTmUgURHzCzO1VbgqV+YlHzco6TL0KOVkNznVpwTBAU6KagpaX3v034hWe731RUEy1GNnfLRj2IWWZ3Mw3mzqnZkJ+UpFXPxhiOpPUC05Rr1A8MSFroiT0uYsS6vaPhDvOqdbFBqalyxTxLEYFFszOPr5q+i7jREmX/XWfrR3TogrREotvfh8OwHNsT8RH4dqiB0kHcE4zGhP7ypETg/ub4WwM6vaYuhX8MZVoczjVRw8tW2NcJQLjf3xEEXM++JDhF17WSTD4OAWNAe1dfmIKxLh7hUqdv0MjF6PoYNtGBzpTN1YlUhhS5EALvrVdPIKk3aWapJfvkGkHOJWLpIYqGvM2PUGfncrR9YJFR6On0oeeuvQu3DFE/0Kn+wHlHcY9VWTxQKM+QIVQuuXHAhJMz8QqukUYOJxfRAGVhZ9P5gK8Dh1mVI4UX5H/V/WT+/3AEQyX7DVUKfJLc9QQ6dRT7Uh4kIRb87nSUoR+51RdH/iQQeIKDpCkDJVHbAqExhAVPINYBPBjGBzicBveN83woxt98DBXOoESMeBXEfC1jDlxCeRrjyxb8E+r8wk42pYw9BGGDf8iBDSOGzvODSAznRCKjm7vn05JlRT3NxDaF4XmS1/URK4j85L+njIkgscPeakooLdFV7F8Bmwt7YYeSaL37lwqARDnlDvnahG2leyf40ChFL/xVRR9fAGFNt8AHOT+vRN3OPbPCHXtEpCaeMKUuGPMzMePO2wDDh6yxLYQbk2ErCKxkCwRznX4wHbPti59b0pHV324pXFRqnG0IOJ+QahXcx7Y+k37qP//7270rPBRvIytPUewF8mAqkcw6IUSFEGAtHy0T8EJnvmB6jFK81mC1HhWVYFxbYnUMpzprnXoUnl10OhvKu3Q8GvljfkRx2dHUAUI3wnDOMcspCgywcRti8i07FAVX+El8VnuYkc8ZhJE6Xv/FqVmVVK6XSGQznOJTEksc3GPwhaJDbjMZ/eAq8zMNZa8prOn+XnjeZM9ppVE8I7iGi4FdBE5fh0TsarPbLlai53FZSsdO31h1yR86XdN3QPVerpOV/kJMo/mbqShk8hObpirme3IzrMsNSW+rX6pxNDyZVQRKYINd+wcQHWLEgttGnQTA+Agmw3kXL0hBY4z4f5PJoMu5eBEOO7XqX30sBoSup4+3jgGYF9paxK+JFKcX9hYch6rbEw6Bux8LtG3NwIVf0owea8SlysFQZdvkMIGSPVLhMFwX93jxEVYbgihFw+b52YcxjW8TkKdVE9iJwbQIq4XwTRCf+Pl08SMVjOIWUizqJeVFhFbX1/Jid3f+gPzA240+zRluuRlbQtKvbLTlYW1TrWGBjxNREMVRR74LDme9dlTkwn4idoflry8ujLN1AVmZg1FcsnMF6N1rGArvXoypuhuKHE5SIt+fUadZZ8PPlLkE6etRM+N3xkLBTb+HCzcvefNshkyUcpPpArlb49w/n3HY/dp4b7rtw7w3JUQz0/6NkHdx1nz/RdoLy4bDSq+x9vuJsmCmUEsxOvmvbwrkKMoUwCR+DoxKrYeMdrSFLptf6MGHsB/qI1d7P6yXVcCeaiE99H478P8NypMd8BEmz3bkKD2NXg0a/g4nGqBsEbDzLYIloVrnZ2cZ1qqRqvmJ5rdrQc5LW8klGWPc9nObmtJaf2QyUA+ZuRWhHWCg4VICnOeeXLNSOuYjZd4XZTUNEy9EwUk6040TJ4/pp3z6JzE6nurpoGQdEBM3urHeZ25hUBa7VNlBfjHOdK9aaKjcqOSgwXSCvPO+cSjqUguFcNF3aU/bJWWlXEQQ+rEN5dq81h9U4CGUBaUT03LSeuZziYykIUk9rEXR0eFV4wnOR+bQBxsVqu1WPSW2V+AEZGuh4xl4XHNQCyD0ZHQRLLFMHObBxnh38D+DKF8EoGuOOvSZhcc/6yTjQXnVRRBH71O5vvSOQnSeO9Q5rKxHNzAZW8exGK4YuHW9+TTy/lS6FVg050wp4ZHeYyRK2YDlzAxL5b0LciLxkzHdQE/f2j4VGIg7L8+NcAieubhJT6P3/TBCBJ6Zw2wkWOBxzUBy0aVpXtOzW2opdfmYOVsMw911nMVEwu/CROuN+JQtPgO2Fjj2F8O/vH83ZnZBiSXi2uPYEmghf5KQEdcZz/mCi99HKtW8Oai4eoEBtuvd1TZoFCw4SZzG8RmhA/HRTjS34UNQw4RFh1vqEQ6INTLmuay+Lalt1rnjHp9036BdCdSeP6NPK7f3K7BjoGy+dXaZ6IZwKlvSQ2tyK1ALYjs5JxJRTpeOS/Mt3oGatZK+cgtbCBuW1Rjy0X3puzGUDrA4HyU2B7SOZjFqIBakOShWae+OMOHb37NSsyVYYHDloTjPtb0HnWqy/TUD8RGytm+fJT2/g+w0iLAB65mvShk+zRAuAAHK0EDd9HmoxuQzyVKKR+CVymCmoYDHB8cx8IvyYl8ttZLso1Ugg07iH5lA3eAuTvzBPBrWN5IkoPVVF5jVbPcDj+xSlZR20PX0bNgcOiweKc2p1vCMMbixDIq4Q/KnKswDSXQ082xMdCQhqOzjv79fku4D3oDRZhd8fZk46bY4X/mklEFrjM0muSbg4cksVybT/lU77mEdUFkKtib27Dncw/Gtjwbe/L/Y7g+GU8B8ZZRTe4Y94UrrcGQOWshdXfGQe/UOVfbvnEP7TZKpyrrLF+kWNxetD8+efn4Ttw9nHxTe5gW93CJdJqL8zn5/ycX+W+0SpcmjYY91iLaj2BwUAnoZ9jRqr10DcIl8nrAGBFMJsGrlikYs4/LtewGayiOd+QzgW560uvquZuSYFlYS99yMh1kfPGiI1yeQCDncBTBxINshuqZ8PjFO5oLyDRxLxxGAiHBz+EHiO/5fo4SCKqNS9OD6TGCUv6xvUdN2nGE5sEiN3bnBkJcguzSVV70MWCiRpnOSpiwCYw43yrW1E8NUE/V22BkvNHgGfDGBRewU5sFcp81iAq/6pjdYB7LtLrDLscC4ewIoouaHrmc+aVvD6eTxoazaA6ke7SRrLByhdoEdta6pXG9Wc/Jb+UUYGpBYZ2gGNpiuPS1GMv6mnSiqOFprGcx1bpaYi5GLnX8VCZhx+uJwxWh4noS8fiIzsGqSQmCBYwI+BWDLzLrjLeo8iKlGFS1tJWei/ivuohbqvpWeoVPpBPkt6eoMYCmCgyEq5uj54bvUkSZliDhjLFiV6wW9fOYdjlrlezwiNPKuM23eW/blK2hDRP4Podde2DsNMWCZfcfBTAE1PH+okal8s+8RmGn3KJHBw10ZKJQn2+ezIFAg+06Q1vbFlw4s6S2UQ19c9T19op5H7avslsprm7DqxSjGuH6xaA9uR4a1k4NGhymlwjqfxbH+S7b8LFsh7oOXnxBSZQrYpYw6X9SbzC9/ynDV5Mf7Z0JVjtmKpoa6UVVtxSXDjczUatC8d9Io2AszGF+n9/1ExYabmOdjofsH3Unk/nPdSC+2bQB+tcy/SU9+DQPYsVq60vWHQkIDLV4/UXsZtNmwHmoXg1nZDR4Ceukg2FfVRHyRsuH0KrOrDpvshyc/nQO3H76s+e9GrPVOVVOJ/Nq7wn3DklzbJCnp9DwLlMaCdy+1m/CwayDsOxE/xkBahbmhOfttNEZGxoReJjba6U83+CWjnkSYVZ7CJA1oPbFmprkKFMMqYaSaRdcvyKAG9Mi1Gw5SsMeaJvSG6bmdIzk80xh712Ep6C8gGH3IFjNZ4JGOx+MZsJCzbFHAMen9ENo5TBTE9SzpR1uxvMWUyO0a+tuaoc8EaUPGIgXmwSZoD3MUCmUCvKb7dKArVar82WEreLuDS4bb04azgyLflEzpM0yfe4W2qYqqVvCLgEmR2CnstdZwnadQnrWjj3Yx4Tp+EqgYbvxBto38n/byqHHasUnGqZTXLs4dpZ6kTtFGYtiNcRuWhn44JH9YqJGtqu9aBGjy4xM765ZsM07DPfAbiA64a/AheFf7PnuXf4hAfO2DBr4QU0xuxojB6DiY2Hhv9pEUohar4xkVZhOdvy0ucI/JnAMZQUXxrw56y55h6JUS96jYWsF16xRkumZCvCNcbm4ZiP3Arbb5pQK+Cbyh1+xKlBKkauFynIUBdAgkhTOtfkyVjI8o3bL1UHIThkl25X+VW90LDmBo9QzF6LUkl/ol/J0klXYETMgGZ/dAEPCoCVKEeb0VNY8YxJbpEy9I7f+coVc57f+GJg5yRIxhHLe/0HddZ8Nh3DLFcNtCii3Hu4M2FNirHpa8jKpPDur5zAQoPJnti6tUc1UGEWZpS7X/ZZbpxIBf6SKb5OIyS48Wy/LZrDTV1mFfj7DE7myd01koGGOVWdc12THpeE8tVMORdidvt6YDNoLcSWDte1P4qlWlk3oOB9p6wa/DxKgGbFYJtIoPVwb0YZNlOzaeanPCqqa9j5DMm8/11D0cn/LXOZHj9BUHJcL3xYAjiqJhd2rYlUYnrf+lWSyb7Rcb4H2i9pjqT5B5dsPvqrodr0FIXemO6h6T+MoUh0j3s85QfO567TWN/GUmx8H9mIToW8R5kKlZSLexaEGajR4X58ScAIhemkicHSUq0wKFvTjmaZxFFVN30de1O5vVOcArh0ops3byExIsSor2zQlMEWSKGT5/Zw4q5f6gzNbLHBsAyQYGqS91mqVj2YlDGg9bAOYSAsaHsKLY9rn/5XXFUOxKExDIo8z8wVAdBHktTzAazb7Uuscs1NV+H4/eTv8ma4Z9dCOlVBtgRZUFgI7FRXmEmwr0T5fRlYNnlfY6mrS2pCrB1yau4uemvbsN5TcdbRMv2mZd54LD4ReJaKs02+E3z058sGNnO+3hCjuO1tD3xK3OE0k13tYq6FN78zWtYzo8qra2HzhhwovwzL3caPh9EB0HFXn9OOPUCD8+z/VbYrN1N/jYyfhB4AGWfAvCyHdN3K1+DWfecULiDSdL+6HF/Ax5KPJmYraDJ7ltNgPctMVhePq9ZAlVgItd8FsvBwHn4OAcnTadNCD678cpuwxPt+xCtfqF+bHJKw1kkYQWwOrtNr4bSGdXOKW4Cy+2DR3SrC7pk35wY0LiwCRgs+KscUnd8TtPkHGXWd0utIuTMXq2vHNTjKf9URWilLmDyDzTgac4hrk4egDaveCDxgY/bDnXi2yc8q1LAcVaxC7HuIzEKrGVGkv3vJ09JGknM5IM43dlepfZ3pVdQth3eFzSJI97EI7+7Q+y5x9qdVdWhLvtUSiEG0V8QPIGIPOeHa/7VmQMbsFZulz0pB1eXCnEQs6Bk8QmwBAoXPQS6PHfLZ7fZ+u1zly90grAooaYPTu0AgglR4H3bhts1tpN80fBLJYAbktFM6GqhXDFPYuvC2Ir6o3XFpma+dTAPLwfilU+QyqtOwoRB1jitpqIBWi0wvamPGDGiBZTfWb4b4GlwaNBIhVCcf35o80R2pOQynSaAVws87ufNPpMNbZRS/g6pnHsnOPzTv55jT0saoSp9azv84uXutrdVoWaZI7WjnaIKRQUuJzazAJB75heVVPy3Ly5VOCFqXbvcdRSmQGGNpK5nHihbOSf5DCoO4tSCO8lEvp1QFOg6eRRrhIjHguvE0AGlpRdxX5hG2/Y/JdPddh0SfwlKT/uFi5yBccFfIjtW9512jBTAV1CFcDpacFVjGSFKfvTtmfndmCfc1SZoGYQBzHYfgYiYKmrygA5inBn5Mqa0OhwkFpS0vxBZfNp7eM0YgJ5MNIP8nLjpNoK/5CMC0RmZCXtac4dzl/6ArE3M2xjpg1vQAc36HqaGNdZFJ/9B3li6zl4/PxREEL6y+r9P+kggzoSFZH5tY4Aq21/TXsg8vO0OjsvgNRMo0FMuxBuoChFd8IDldLtjOj/Qj0TX5NKh6fgXodw79pZO/bKuAS+H6H4LcL+eMF2LdEk25KSmq68r2QwjD8YWrqqpOctJNLncMcK0GUbiSeoGhlEMbdS0mUOpJps8GA6uPNoiBRt4cU1R3JfKftPohcgpGRJesxFdn7tqA9gX9g+gbsSzcy3CDZg1L0ZamKjLIGPfvlSOxDxnzyIS32FRoW21NkMtU9VZ5/KKGZzbc9LmORfDUiCNwsDZtTM3Np8xZ4I+XZOIjruqkSiF6c4UnfaLZOOIapi5zjOa+o8pgCA1CLGgXEm3gk6CxVLHsFXhNxDWo/5qrqwU5i6LSI+HZecYX0Yl89d7V3uSK+JPwklu15x7aOi1WVWxXieQT3KqPtfBNu1U19Ia/O1VoNOgtN+U4zg2CeyPhWHxoMHcDKq8s3zEZiOlRtJ58HMkzcf+DlHyZESxMUQJBrhFxBJ9JaQI5aGs0g8/9kaoq5jkj0vdDqMBcLN7r1NPRBJz+ibZcb/VJokpCDn6AXwLrZYk6Fx8xfb+XcJa4U+XDt4gXJpUEDoSxBUaAQRlFJzvqZbmxSHcxNugJD9jx+0+sqQg+Ze9TWi7JioeAsCESQvr450kdKCiRPp0mUa4mmYdZ1UD59V9jRbwfiWz91mHKc/yAKfZAWRhCr1fjcW2bGZH+SnSEnkFnEoRYRz6xv2gyHjtTDTRE4RQhTndKk4dsf+waz2MjMLjStgBl7SRVkh3gQfNQGa69+5x5pg+4sVnOe5L6quRGrt/u4yI6p7Bs6WomimABcB6ljrWkpXjJR1/GJnbmnYkd5OThyKQ1IL1AlNHIeP+kbhykAsZjSf6gLz4IahlNfap6Lc0/TUdxehvHSBlsuJ1MIupAZLfR870cAUo8TYqMl2XjB+zDY3TFZKqyKrwEq0GmpAz43fjln7QyB2O+QoxBNXTXKbP2w9/0Ph1se1n9D6I0r/eZDJhi2sKHKIBbw6UEHWxbtDsqtf8434SqzHvtLzPpxh6GOYOx+E0aj5N0m9xDEBqnV1RD90q5mEVvKupQ5Gyp5Xx5t6+ePQoYw5GoMc+G99yU4K/L5FbLjhspUR5V4xg5zM5+V2PhLEEBz18/o68vB7xA22vV1AP7yQr+vUop+BqbF10+RsE5I3BueMg0OQpmQwpEu3D+Ped3oRCy42/IfReBJ09QVOGUN3Z16/4RfVP/KOsuiKRBfhVvxSlHEy6RpVec3ezG4TI4IgXBSZJBdEB/0r5G70Fm+AdDxZIXudtt2lqPZLBCfGAsTYPm05CQmSB+vtHWVkSiXi4R0WTUAIYOMZ173ngzWJl6afa51W2J4NGhSD1Wai3GzyW9oOi7KCL6RhBHWcZ9verCIxiVVELf+8X2gx6gA9vP+wg8Oory7hwExzf4KpJa/KYqw5nuIAKqVMyZSQNpEeHI32XlTKtGadY0yksar5ZJ2hNM0NaYmuyN58G8nuUiUkf5xPYp4h1yEpDOuLxZcp/LlepImzJJ8lME0Uu4Q/NULGMMk0Hel4H/FVTC7yzGy9k2w67k4lLgJZKv7AynF4Sv62TdWEctzbyV9YfKnmnK8O/M16N1GzEe3QGQmnuNRANRc6iZ7tqdNftJkur02xtwyP2Ns0v4u4FGEpqCh8uNi+RC6BySRQXaHLL+xJA9wGzOXaJt/wy4onJFEpZCDiNyA6Ms2dilKmVe8p23O9w93sXk31Ozs+Jg/LzISSjoQRLsKlJeUhU19Xg5NT6xq9aqmWr6bC6dGMBCXiG6VnlTK3eq0c91qeca64LG7U0E5Yj2T6Rleu0rfLf+ilBW6Jtbkq0pbfLyeuleRToSzpa/SWwYu+vDFkLySKtYM6+DqQfzu60kVZ/19+Ehq1yGCe4ilxiDnGVA7b/zZBhtkJ8DzWZYc8Lqz7Aze0p3H3JpdHNWMKSjIp19xbzQqxXyjjCf7RODQrqWucD/3uqlurS3rh+hqiGstmS9qQ9ktHxzURFFl2ARuYTinJzVcxwQjThKmaBOdwDcxbLdoxx0Di10GzWFQVz2gkzRyJzJuMfO3Bi/tiVyuF5unJdqp1BCzksz7JQ6KQMagbx/QIFJlbX2wmAMSR9z6bON6x36jJjsMSZqJTs8uRc1uEacd1dtf1xMrpma79UjLdRFbhKpw/QYPp7MirxaEjWmAv562dC6s8hBVD1ti7ZoYD5MsrHD96Yjg8v4Y+ZUxFV4oAdlHxA2l4E+45/F3CQCSl1zanbHL3O5A3uJfVsQSaDWZQrQG3TYCJc1fgyKCEuHAcYimwSwayt+MVTNVG7l4OhRETUM955i4+pXhvIM5wC/6/TbwO1KhHTH36oLI8zIxbhvayzl3JVmKvQJHBTFIzNSFaFTNp+zmmNGqbObFL5+TF0QXdSFOejVEa4TJYAO1f4GPlZyT0+t0rs3mxCFhcJEOv5IDHZC8jqt7kjq/b3ab7w8xA4FuhHQSviBxN+n7MvWhrr4lP8JR1XVA/DmYYUP+UQuir5QEb71TEVJUqZfwfIUek8kzXLsw3HfSjspLLTOoOOSK0xZnOiY8q44KG0xfe5rdJruYNoppXZM5NfZB3J8aZkFL7Gwd0vrzXw1IdWskgrxf8dZtMfIhsFlJZwZau4ztgwcUf/lXTfElnTPPAw2cbc/seu7OqS9TcEtq7vFbcYL7h4pcgFcY0a4YrA2zTyKGP7t7SCm7j8nqCC1cDOe1rPluPpTz8MzJtaMZngVGhAKRL/71XBf/ZR6CpD6qaGz+G/hBJ5zhDivnxa7pHNOKcHymk3RKpNWh2HjzO7nHn5KXz2PqEdIbKAclvzS/mfXMBiX2iAvM7cRkxqNnN1nMZiXG6pjJj2A8F/ldlhooqEFNBrU1VcYbI+hvZVfuJBQZv8RS9WqFAUPfgJK9RGzE1oBdWHOQlY/wR+HbO4FLS98qoeApmffbNki6tVWXW4SrielHM5ew3ZmpCWOor1svBDvf78LvCfxhh92U0u+zlBR8GaNUSuY4aU7Nom5pvYWnxV/LY873eskj9IjHjvf4AQ5Q7dEEzLzw75wXlEcGN59czCytNXMA5MRJXwbJYhf0ABvvx7KXTYjmHIw2NoNr93gkBZVLI9MdiXb1LN8lozs955bbyibJZCxedgqXf0+Zyq2qkeLHa4+UoPOhhFZvQpa9AdKCJ5RxTJugKeZ0g9fcObB4a5+/3cf+vaL2PpsWMuyPyGbQhWIk5B6fAZPwNieLu+U4zWUrf1+bxsxnQ4nmC6v8T24qWK/lfvlOFmZi3uvBGc89FnOF3NkYb4HJyH0CrVL99zeBwsLcDcFmbBR4i83VUxW7A4JrcxjyHM6DusrdIu2CgsDaHVW1iKHWO0hsDU5st4lajlA7qq43R7QdZVqPuFR7kcuEWz1Tmw9lpb16wOn5rzyW0k1a2l1j4V3glID77YY8a/LFQcPha8Cf0cM05OxyRZYe7kWCu3EXSDGn5GxwcQZCcH7/hyh5Sa0iVsXLEalTk1D9ahSkbZojYd7/Q4Sprty4aHuS+Vq0Dzymnh+WfCKi1OZXC9gdWqY8B3VGU0vL/QpkYDU6vKyTj5nFOC0raO0Er6Kxti1hPEes9b6uCuZGu7oCbZfeVmyxDorSb2crEHABi+pCt4c6DLA3rFtGI+xJKowgx619h6kd1n7Eviqplyl+fB1pHqvEhGVakw46F+nZ+T5GUtGbeXFhqTT2/sdmYYQ/lL9vnzHKyXd7l/dCSTqSrNtPFwkOLpuIFPvRqHHNudl9M7YCxQSdrsaSjhccZx6gQbEempiUAetKv1gEK4VrZxN0ywKr5/XbrgQPV6L3W/VMToyCp9Vi86RttF6vLpJra8glK5cTryodr7qtGfm9L+MOqxF6TqCob5ewCLB77PdP3j56PTIyrUbNWZZhGyXBC+cRnuVBnnUs5g2hTT9z9u4AwOyoAoPyqfrtkToJZV6MFm9Ml2dyl5cesLwqiHczjFLMQHFswQ6RDbjCOiddq3WrMIrUyY5dQrHfZ7v6wMQM8MIaGtRlSU96Tv1MKWRuKL/d7JcHF/xAfXj+25sh/7zUO1Uo7vE7Z6psTSaiGbXI306CAwMcdbv7h5rtMXqHd8gJihgBackXVBmR2yDV2VKMhbPLk+8pWqQZbtrNXVPRuKYh0JavVwqog9d9i56lO0NaIGsVjWtKNx8dvGkj4Lb1rvbX1hNQnw2AlPDvUSpPk31SIjrxwk86r37rhahEBwdv/FpoWgEEioxuPH4LBpN/ypo4mbn5iTzWyyOuQK3M29RZ0yPx/qn4Lzep3MqZ9iQmlAr54FAqlA+kzjT9XcXr/y7wdBS9+bJeF2uJkJrvgSTJEJ45pKxjbZkw9HxKiNwwi/5x/9XB0A34tPyburvjpYHtLZgDaFvLuVFv6eJGc6DWtwE8p+HBGkpcsYYF/uZXcGyEhD7o4fDEn31LaNQmr1pNq9O4CRuovE7RdAI3IVjRAzdSjWWy/Vqhz3TQy+gcku8mdAQC99fbIIPfmb+2QOCHCxj4mXbXzX+NGZCJdwF9aoPrawHhszfn3JPlFa5AKjg0F1JmfINXpA2A9xM3uUPNvNYgNq3qLaMv3fJachlRo/s8N74p9g0lyMVyitbg7cZDFJI2PNc/5zJLDgc6pA+4BRr4QTKYg803nx9lveSn4t1r+RYFfZKt/lXT7vUDqZ8jZtuUZIEsV/2gAK5Sdm60nP+2LzPPzaDf7RU24k18xiE50NGHeDnhwQ1dauNCGgK8MoFQ3XtIk7BadRR5rzHzNFErG+sJ7DTxYn9HDNixnIHJUUmiSfK8344FXuUbpKdGvVcNUoUL9NthaJvFSBcufkmWTuCOXtYn9K44voUy0ymvaiZZxnkCcBoYTRAJpnVEhDh514BNy3xvDl5eDpXsURHh6Wh2We2uw+ZWPxGym6lkw39QVn2gx73RmiXNeK284kq/ZF5We1tIh6+Xw6gJwAzZGorKtNbo+Xe+51SI2SXXdX0QE5pPIV7nftHX1rPZqQ7tzCF3InWaeitS7FMlXkDf3uTaBaKS8HXINwcVYQNHTg6HnnU4XwfZiS6fzhIOeIG3WapoLhpDsRW70D84ukDXLyVsbO+pk+aD1i1346enG0MeuXYgQUO+hv592NC8w3dCnWwfTqNqmFLQjBfmSKAtUWsab4NyJfDEtUoz+G816jSD6QthTNxSSsPKb0Z8EfIypnx7f36W0qOIzVaE1QoLONPwsWptYBysN+036r+NcBYf/nyVtrI0zUmtpd5EpPckXy7pHdPfkPbeuxJcpv5rt38J6VScjHxJ94EVp4lBlnwc/JqFo/RzzxS5o/dEL0o0aMgxWFHJDvLWWJ0KT3HiS9ABGik6N0Aqo8hPoumY/2VSGmmcqXCkdoOcpDP15My5VMDxlmBFmNf9LEz/rm26EUlPbIyDLInT+4hhQ0YZ6ePjBtqQcO1ckdPKrlpaI/PhX2ES4FofE0+PTYREztltZ62hDd3tMwximL7uuUgukh2diqRb66kzgMKnxkOTYmc7VJBSMzUeZbHA66JUevlLF2u3DQVSts9cQeVoWuOUZlSCmr31ETVOruYfmB7kuKw7SqV1uu8/piy8DiUPvqpth0B9fvQ22KG3hquZw+AmqiNvFhH/jveHffyyuZHC3mGYnjGJmDAR1t6K42AfMWQgr8QOgiOwPbrP0/en/aTXCoAuTqHWOye2VPYBhfzppz/kOwsl/U8R04m4lAPI+MfSA/L5H3DF2Psg8DCADh1DPEhk9MJSNeyhDNuypAAn3qGI/aAqDbfGjSpeyPcxAGLRB9kp+CxqipPuoMH2eUhiAhfsYHn4hb/1ntI9/aHAZW00Fu4N6u6tjI2HrXcZ4mMWRDeqpfxmL5RMqK8lIhrCNP5Jp94fepD/HAwhYHJRLi3Z35PjgjAlA/4tvRP89Y6zKAc+e/BxihOcC0aZ5r7OVuTPQQHnlUqT4gyYgiUuUOAZO8qVTU2SvwLQciog6zSdpS62eUj2ah6SrGb+AumpZMtM/TyKggKXyypOPakOgnS6RZKyM5jS4Vn2sRybdLJYrIbV9mZT8X1XOUBNvb2mLjSzb/B2YOvgIauDVFzhANo31T3v418s/mBT/7jvLGVcvqOrC0dSpxKJjJKdpUEaXZnjXjeGXqKunzl8Uy2vQHNAs8Y15ka6jH8YtAqNcltbrHQQVeS+YjePzFr+YxuZLfvL1YaIKz23DODrQF6yqeKk//el/5AZpEGvkXi76nqMMc3BkyaFveP0PTktaUtpQOJ71jyA7iqtDLQTFcLLo8nQzX3Abddgb8YopfvNs984XhxryJG7u3Mu1hl4ZBq51UFK3k5h5orUP33oK66pUA0t1UiLMgrJrWrTlWM21hlKlpMSSBwQTJ2M7OqKg64F05Hl761QFb7qEjPtyRmidHjgpulxCQSaFovorr6eA0K3ZMHvLnx1K5KAQgl0kVFH7zgHfqo9IAv2GYNnzAbp340CuLWnp6OL1Bob8FMio9FbxPJLj32lFz4bUXV9jTRZopCoptEYYdI2P16BSEPqyYC57C5hBrxFzhWPpySbQkXHOgYSFg8ETUrli489o+3kYo52bH5zNg/Dc9EUEcxfFE/5Ie23DF/X0U6CRpIp6b5XkT4pQwampUqRY/og7wiEsGn5MQcHdTsiHRtlWdCADWn2JjvUQ+WJ68UhqZBuqzuYZ6Fr3YC2MPVcHY6OBFdLsOGYK98VwTF91P14HKcofPH7t/weJaNJzb5tXLqMvUoZOg9LenCopjIkAhRJF8NG9yI5TBWSv/VrZSLvtU9F6u/jEGhkv9YgI34lu9xswMbLPKjofbxutw+oRrF+HO7dzB2ieeeUmAAaeREzwgB45BcVCLq3H8C36IZ9M87eTfONeJJh4uygEQdoD0DwwNa7sf+5p5KEDsh6v7WJcR0A+Gw0ovdSWImrlfZ4pgHbzc39MLwaZNuWxXVMeG+3XvgdpSyoW2re5sEUQFXF58Gjrq9IQtv29ABn4r7+HEnvvYb7i/tyiuXi3jSm6T2767BRiq/Q8NSXfJt3Tf9yMKdIUtvm2fJWbJxVnvbUQx84siOnxSWAY0e2p50OWVoDjsbYwVR1C+PYgeUcO6z3Hnh3IOzJeZYtkanoD4efMTygTllIDEvhyYuIPj5kBDYcbcNB9UyHEJ3KfM2evi3+1+8igyoroXO8/aSZgWKmKcxU7jAlPMJxSAfB5/YD7UAfv+FNRFJlHZBskqwtdKEx69glu0qaAwwzJAeyOpGEsz9SkgMzG8QkGtgEygOGh7xooK36sMjSnwEI8RrOl3tWC+Oh8PJK3afAvzGsZnRQGrrtaDZr3I6zjTjXsysmHiAYCxe7SpZAul+QxFaDplIK0cr6T0BXrPFtGc5j29PMWbYsCgz123RxvZOiAkznA5NPupPfbFDaSE90SaFAoegEnPQigOQu5a+/ogvbxt65EALLOxEOLLOzKQgvbnEHstPcgI9mii3ThzmaUqCRIKtaJb5PKxeoDPI9R6QKjFr1m69hNfpPVGd33h71ENTY8OGQMnDDxfihwlNZcncORpef/feenoGh1kom7I4n/Z7SHjouozeY45WD52s6WboyoJIpXZi752pNNGLBhibRKtsxQoitnenr+1u+IuY2ADx1DWjp2zSzsvRicvWH7TI5PDQ6x8yKDNWjuknZg4+4BgK5m7OKUDc42jQ6jgdB9SPuov8qZgIEQDt3NZHP6G6WVLjM/G0qTPL7LvTZJWWfHQwzM+EkIA6dwmczQfvuhF4wgKdaSR5p1nFLDHpGurbhNKVOfRvioxxKeOuPzyZczCzqyKetQWyV6QnhlO3tp7YqWaFZBUPyG6KML1K6ywwzbuYq/5og0e3fjyHWEUSSLEbvyOO160q0gWucXKdnM2IoRiYl/DNnWkNFBE93Tl3HDB6D8Sq8C3fkb0H9tVw5oYg0M3MHozjW+ry/leLv0S8kN/AwC3JCGvzULfydt7r/GDMa8DF+Y9BVZu2SANBopYv7cZhQjvmrrJmubQDmBrO8dCg7BHh5mljMwxV3iTnqov3E6/uXtfMUKOjtgzzVUbcNbX4IGJUFmTiiiJaHC1oPNLaap0UXhdUoNtpGyQ4MdO1eJOFihocHh1hImdDIjhhZ6l1CyjN273HPdTHkZlUeDy5P+d7efU3iLxx9qFbh4BCodAzZr45dh2Z+nqtjvdPBW1G9y1PsRQOY1bdWC4gpCveaO1u/cS8dDVRKPkoH9LygVLnPBUy0KIvJ+p0kjQ67vLqM84qhB964FpiIghRCrx71Gb7Bs6uD4RNqN7WxMDMRF3SXxSkZpp1l5WQGftfd6OBhynnyfmZXsNg2WD8l5kgcMa3k/tlQ7onZMhTsvXaKp3daUUTypFe/bP51BOO5MjFxi/0OTEapwmTslAF85JelLu5xmErvHDJMwhyxSK3K71fqO71ypRMVMDRSCJSScnchnPThR1TefNlN7g1mSN5N5/s7cCv3nHFts8ZlMVbou0EiH3TVJBNT0ksB1mKKdHQPaZGe3m9bvj5Lk305tmlOXPdbVlztd0+HHf1WpdKKhAJlE2nHGoqUBNAAWKD3vfkkDIyaHIn6mdffChwEB6MceC/WGt9VCkHopzVYuxrbUknF8b5sMB7c4+dWiIWTx2XPDrcnKhA2O7zUFD1cIvKJZt5aj13Uy9CaRjlKTT8yEeKbbq5IOpODgoDLZMH0VdZ5IIE3MqQbV9Ym1DrW9V3280Xow+2ti5LKrBFQuQGiL5eLtHRY5UB82DhKGlaL/uel8Crjc62Xyy2S/MN6UrGG3exmL1YsOdj2KtOrMqDT8OlbH4A9MAq5seJjJ2jSMW4kJ6FTap5bzumWej8RfSknWjY7OpvTyYUkb4lku8tR0fxQQooRqlC2Vi0X43hGHVFkILlTrikVennQwi98jjURiYbPry5HyYGgGqr6A83/XKueRVGnDQCRqn9zun5svrE9uPBC0RkWtiSn0cMZeOgEjwBihAhXTaOi3W0ran1Ph9Os24H5tdvzuy30i/r1os1Cx8c9Csb9nxeEuywz0UDS3ZRKpI02E6JZRJ2sFtQmSc/ZRIMDRBMu5XGmYj3SmVvq1m+nxF+HLF6URiDpTK4WQRMj68sKHRqI8wRqa2s6rfkW4wfdV/BCuEvxrcc9hmtpqAJqRoVWs9VsFOPuu8ee3S0N0Jhu77QG3TUOg3IM0vrn1rLphYO/7s7e3MDE5GQsrUHU0o/cHo9jeTsOtT5XvLuYUV+rI6rE+BEj6ksdL+M5qiiIMXb6sWF4+oDDOY40g2BNS46j4eokj0bu2C+3g+rhLlxp9zlzYrc4WEBcCZThrmt+hKlromUSB0A5KbK6no5Igb+Fqa4HePGTiuso7Gp8/ELr8LWlfdKEz8Jln9PMQ5jcYYFXj9CjyETe4crp6QNgJguf0V+px7T8d5hPL3ukb4gN9xZG6m1rbIfr0YUclUr5pmVIHGOybD425OP+cefFFzPeBcYM/Tv2swLb4lmNfPIcuNvz0UFzxvClZ1hwFVbrxaTQ1HuMmAqNPgY3Qb+7jF4JlZjd4+HyMpVUxH25j96L4SxWXRqyNkcNkgQSwakgteOLg0QugMnC2waRxdHz+6/qmutercCaNdgs+pFTr3Mrdan5Z0+fG7suGYIWkKcnKnyuLnNOU5oe4Sv/hoVIppAPYdlE3+dNXKbq+gps2JUhZ4L5xSPPHpVq9o/n3pt5QxTKNvJhHyYQufa9vOuEbpyfWfw0+ES7dXjWFZqXME0JKMsylNC5r3NXWNXWhCYNncSOchCGpf3TqM/uM1hdNYS3D4GA58Xe6IOUFseBFtIvlcEqt0YhSEb/0ZK3AbxYbDwseWQRsnFsRX0I8rVCVC8Fl+ZPd1/3qGdtFrrzy34dAzMLt2fYx5Qbha7GtU+FpwQZT9CZxYJid2ugHsgnaeiyvCbqarPeWhQ5Oc5YVtDcyRGi+v+dJuc9dlzWNVUCWKGLY9jRV63FshiamUG35feY0JqHSw3yzfwcX1J1XhL3cdjb+lFPVWojT1Vojz5YC1bnwy7fiTt/QqVKNn2Av6A7zQWT06vV7upmvRaQxDF4+aVtr95biOQoi/of+ZKm/C1O41IWdf2u7fIrqMtba+0ePuGkWJD58hadpJ216dOdb5J2qeoBwfzjtpEJhO38du/9hIY+7T6nvNV7hbX0pWHebw8II1AtAxw3TUNAIiEknI7U7oJpxkWiwEI7SE/0t4+C9PuFN9ZAjDgJObTVn4wyYKTtR0WyQe6o4LQloXr8gOMKYzu2+WWC4YUslZDpvXOhaP8fvO2hAv82s41LjMOC4Ip86miFxw0nwVfvyDpNmhbrX7SMOrkUoYB0/9ytdIEORxenW7zPFM1DN7RKt+kgQ6WcB/tei1EF+8CqVvvu8M8EvQg5EUh7YbfLxj55hrzdZSj1wkbxOeQTNDi+8O6uQJzlj/MIOV4xXmN/amjp8VQSjWnq5AAIMRTZa3z5QwRA8FD6ge0sDOTmt5Z9FBZaX15yAlyiKk7V5NUHKtATDXPhQmZL3H26wpvGUT0QzPs7LzeyrnEi8j7SeSEkXoLnmZS0cC1UaPJmWlUu6nlNgZGak6skrlBzOjT4LMsHdDJUxR3Yrfynoy2LfvmJbg2zSA6hMh9HpdMbq9rRKHIObyqWvi6SwroIwJi9GB5pT4ItN/q0JJNV7KOIj993Vw7IhEWg4BwPJHXsmaPeBHlGBNxc4xucxcChObtKAshNN7Nr9vuaAEVxRFkTQEPoaxvQOsCdigtOKLiFfJioNn9dN+2U8P810fg4Cjg9kjGjer8JLUsKxhoe0WTA+8uRzkebUouwUwfyeuuQ9GVePDKVyp4UJ7hR6MLs/4JH4BaCJy/HQ7u1K2yPvZkzFdRT97oM5zqpgk7r/Xr41n7Hc3DrkGzWxksJZoyaEmHGPhYUaM7eMlUBE63LU9guyDzKYPorUktH3bRzPJiRJHjdrJ9lxKU2Z/Wt4uNp5KKt5gdXC5hO+fxhRfo/SOO55Nl29H3o4CceJd/iMqOb807DRG9bmi/7YU2nJP9HpZl6iuIQOYRbUX9Fqrx8+hP7RcrmXSn8oRrpodpwE6qGglWiylPS9k5SCgPVrF3wy/2yDyG5jqKh4ec6Wq8QkRs2bx9/9qXnSX0Maai0600tqV1tAI/rDTBQMGEBt5s6/jWt+6zRO7ne6b7+xn1fT38/R8jzbNmr/f3rm3/bEea0FtneAQ/A0hNMl7rh1FFjnYZq785Xi5HDeiLZJ4ID8CPrfzL3SeGhZIgTU5NwpSKztaogSSuN9dNoY/X2lJl2NxGQD2emyPgytUDMt3M4NLsUbGLtQkPaluimCSd8JmISz2dytWIo6BIPeUt9KOxdaBadqrx/pqsEoRxOuB9d2yaEAT4FRhFQUxSsdYsfFx06sq8pgl2MJmxiR6q3OqJH8vwYdC9NUdbeduEH1pUy324K9eK+r3mWCQa+o9Ldemooe1mhcP/LfIEpGAwzuW9W4b0cK4pjHYDjLFep3EBaYvXqg1O98KGePdFA7KT2MvnMXh03KpWOkgLF2MZWyZsl696EkxT2AaGhUo/t25F1J7so4nbdMuG0aOqiCO2N5gkMLT9XeqU9gOW3kkybVSH/CHkozH3c4g0HPlgopWkdjGc/R+klOY8g9RibtA/wogVQfZc1EG75PKeiutIS+GRUEsxpahomEuvspyQJdlSwlfOt9ZnuN5qmaidxIn7k3KacdWkj9cWOx5pwRR8E2d7IOgwTWPRRCoqzUyOoDCjJmAW+s0YFkjzVqE3Ig7d6QppGq2tXM36bZ4y0E70Tl2nvQgicll59jyFdAJEUsiHmGZiFa8XzZ3+GEYFdRT8GdIR7ndiXyyJrdjLoQLmSACJd1KYTHrl4Var7dkXrVZt8aFsMwzcKWBMoRSUyinIb10w6BHFFmRW1RL9tQisebnmpvexI+a7ZNFF9OyUFL5gmY5DQLQVXVuhGg5E4joYTS9o3k7GlFhUhNgjJJWnNpAKh5OeRD6gIm7NKlq21SOtN/PbOR8TGRxKkOye+glZ3XysUj31OFL4xlvcp0DmZy68fosEE+prTXcuM7qMJ2/YS4NrkCOKjo59eqfJVa6nbDjZY2bE2OOjxJF2j2akzLiJC3QcTRKWE3PnpK8bAxMWf9hn2OkilOSzxwlX4Z/uNZ6tjocGkYl6TqeVoddeeJXvxMeL7FLykK1KZMwhNnhzj821h1D7b2aZ9kGKZG7UdA8SoESr5kOT2izTMZEDHoodhAa9N6zeIMbWgJ92APiZO51EkJEjJZWiJPs96f/tvio87+mq7cxrqBhTL82SpptkvuQv06MZ9ects0oYHN5mdsD/BWH5MWJqqyESKuqF0y/PgnWvcd1YQB6ULg5zkP3Sh+VHxql5uavE43KGs2yaVJ/1/ROVgaDuED8ItZW7Jw7p4jZfru7cWNQPPya3UU2iY+k+X55AZK/H3y00QKjxayqHzuL0tezKwL9tfL127r9P0hbIIrSIg2J1mfxIXSFOG6MK2oIbqub+EkHWn2cf7Xdz6D6HHJIlAWpXBCXnsJwlCZGijd0UPnFkmhIBrf5sOD5/UNcWKgbOS0iEm1bA/dneS5wBlQB283JC1kFYWd6GI7tD7mdEqxl6L/lgzTX2wTQctIMuM6GDQji5Vzokw8sb3gtiD3jpFqGq1VrTAvWMnFhjuoolVyYBbxLF6Jm4lLngLCMRtLxcRmtKXpxX578JQRvgNNgQ1VK4S8tUXUiVmlXnAuYuVGZ6iv2+bf94PdtfXK3+482oDvnM7Ma2Al5c6uqlmkrrIx/SWy3pmCavk4u6g2YgakzlN5HnR3jgRzU+kAKPo1CrPOU/L1QydKzACTUmfxw6VVv+rcgqNefwP3LNKEa6quz/ft37mS9dwS7/BiiibSVznKFQKoq3MPUj70EdJQ5NLzVYQA77efh9xprMISwiRyw1M9g/vQlAUiwi1jxzbeAEzlpC9UDemdrLBv6SBpsllJw5fYtaB7RDYiZcw2jHmIWU4HsNmw5Eveod+t2pN2NgqWr1yzdNbRKYgw3UFtGJyTt2LQM3tKYVM9O2Mq/MmjWnSBW45xNV0mxMfW5zLwEd2IVb/OBp37Dch1ilVXgF537L47y+VOnTmj/141OdpjGpuPhaNfo9+Pmij6oEpBeK/4pnTs9RzBwL3bx+clGk+biyVDLBt3Xyfyi9ZtYgaXLZA9ig2lfMo5EtAABiEg6zAyKZZ21oRGxO7xNjJ80eVvbgHndB2bYxtGnIaeBqYFeKN8kbld10FJ+sg4wqij1rFLz2G3eH6z7fd7t9mygVTFv9uwkR1FupsgZTwSlCrfAMcpR0b7JoPyhQcvnQ9MYjcqcn3U7FObIZHELfxzvARokZJLqGwCRLYxNGYHXL3qdcdtQ52gcL6q59QOsqBRi2KHQbHuvNdzcZNVmnmA+Q5X4YWqHifNF/gWVnxiw8dYUfONZ4Hq6VhspQHnGXa41raLVf0vUBlp6w75uFA1D1bPVvIAOLiyAl4f3iJ9QcOUEr4pIKb6q8Q89VdwBcKI9SbnkY3HwYtX1Ck6SiStv37Qdy+2OioGKVcsPQmDOGVD4CRKCmIxsN99wqkkky0zSxNDLPHoZaxuQ1lFbhdcAIvCNTCcR7Sudmg2E/n0pOL3+0R7SOoEDRJSPyMz9p12mqkL5eZvKtZbtI/GJiTsxN2rXW0wAivclXa36obOpUnyPjGLKksY1FKeuxgnBedDAUvjJn5dD5EltIwTvXjRy56DweGEqeDX2OYXyDuEC/kqbnGZlsCLL3JGCYlwthJ/PI6BueO3nFmTDHdXIbocvz8jdIF6b/mU8ATbKUFG5/udKbukWr6lVGhhWq1c0ODCKKj6Ul4F3oPfxidOIiYiBWeSgOMFbbecZzVEqxCTHj9r91jBDoSRQBhwKZz/o5N/BD4D0ivLZ32Cwn2sSxBffAdVap4HpmOpTfmJdFbdvo09t4LlOMW6nm/8xY+CCJHDXB4qnoWT3DGn0sPVtflZvMH9QzRCpvsS5BfgZnjd7c2l0folG9VZ89B29d41w5N7lGG1sY7NXmCtbiIIlXcknpfh+GZoAOnccTw+bqGMMR1sobaQp+ruNE8oLLJOpggabLxjMDLygAaNsqO2EriYhkl/tHxixNg3FdkgzJcyZEAmJWI95oyO0srfHsFJeIJs3fgbez1eYqQgfitonSnLFqn3tC7fimbFVy+Htw1nFAxyk7X8yilTgYlw/+Wvo+teJVNjWHc9Zna77u6aE8WzAX/YWzvi1qsWzgrODDSjMTMDKNCT4R9/0RinBytgyK5ceRT8DLCGEh46txFWX0M+Rz7LPrtom1CekBZc0uxsvAUHQh4WF4IxoikG5p//WAXgBzqPYnvln5mA2tXV3aReZnAefS/oJvv+VutdckJ9dA7VFG8/IymtiCpRqiOasNJX4BJf0EDb4b4mugpUWhs6xwQDumOWV4DKrXrQllfyvuO3nct53CIYgYE8cZbwTzlGB8G8I/HkWQNBhn4AayyDcXM1p6rZnOKSwgdoXgXeyTyOBYkCSwjOq2/hjkOnTg==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZBbRI-vLFGPASeYxh_KgLGJAGhxxxQHaAFUowMEJ38zbzJMIHhOPM0QVtz7ClVSrJw2&amp;t=639202794265548063" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1HoTsDJCIwegf7-cSVNQxKlxqJplUAag2gjZMR_ctGyeKzMDbl61mq8CG1bXK2cKIO5F_d_eACHU7rvEovdRsHjPwMxL_2RbhdHxnXThSzdTd55hY37B50zmwPwIsJ1FnQ2&amp;t=4623e90" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvqBoWBYTDUGuawA_2GYbNQlKfMSt2G6fTRv2v_CvkMQC-NDKOxcBHZBsr4m43UZoWnDElLWlfRSMae7wFN5-j848Bfbquym3Qmm_a4KPTP8MlNJWDtdRKeoXno9ND71Mj-dmT4RATMPqWph8tRm5et41&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OAh7tEdde-lvG3-30egxXz8aAgw_K6hDRuGQnL44pJNvGX0k88IpkhwtBpf_hp5FI_xl-S6IOzDAoSwTftgBkdwIVbozv2itakdYRoj6lyvW2iAmc3lxcxcAsYCLcWBMdMG64QNAlb5JWK1NKm4PkKk1&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=eE6V8nDbUVn0gtG6hKNX_FhBCrEodp5vWm_YmsPN6L6kd8QLjOqCyZgy7R07cf_-q6jt6CUudI9DljzC2TdIySTnrKddg3RKYGaYn4SUdM3lZcSR2HeYBRZYoT1mfgRe0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=mcAASOSteirJeuV-3by3Udl0BXtV-9r3zqXldfMmh4nMyRrfOyOUzm9PjtxhXMnCb3u1w9Bl8xQwuZ3vJQhQk5K_jbJ7TUVZSafdbK767TU1&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=jwf4VSQi7LeShc44FJ-gAeDpDtsq5KMQ8v0UGSwL0n57o9DwezYikDFx_PyigWyXj_0OxQaznPKYQt6DlIveEltbNvWSF7tPucSRMMT0SDIeemWSUwY9H6muRTmCFq5y0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=nai7mGcYyE2dix_TwveLDUh5s-4A2YxYW54tIrkM_TUunAGPTDDQIgTi7_jF0ZDsXQf2DAdig0qNTG97Zho5rt0FlKu4f2urbVFVmxpi95du0q96Rm7avCmT7YWIJACc0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=yDT7ulzE00Yqzs5zd38bJ9uYK0mE0NQaZIaf-pwWkJgWYgpXpMmyr9X13OsEF0tAmtivqF1lykUd9zGXXG_12HtYlW9Y5ThEGbuS1bPsUkjRauDlH9wZ-Gg0tVnmDj270&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=HEFpVKbnoeQjkjHkFKu3MFt9ri5W5MnThyWIA17NLksVbAMJb3b4J6FUWFjTqfhe62vQzBBryc0D7vtVE9sCvRaBkQXkkFQdNC1ak54UhzYYY35kSK400VtcrgLyqWDD0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=5ib3lCcyinHeLQmkwMF7EsGoPbLcoTPc-cgtukLJYPUZaLkkgAnENQdSi8NDc4l_BKxYZA1H9k0706BHQRpedGJsNRjKTrwz8gPmzzA-oap0ysiJ6VwrD01uCYx37kM30&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=iON9Jxe8QCRam1nkdNLgkffrRZCMCj6iq7qHWPZc_e3jKeMk_XnmxshFxNhoGH9SwE5Oz8w4xs83YnQN2PvBuUDeB4qmPOBf6C6AjLMoHrEWhVT0hkNgKR3X5v1OCzxI0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=xGmPTKfsNy0_1Sr5I58kO5DASLN2udyuv-7sLUq5_rfvt0h0nqG8q3lnLwCBbElWqxPrkky3q5vq3pg0VXsmEcTWWXMOeG7FgMUlD16VLKssIvRudHPE5Dua6R6EOhY40&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=LQ1q2RBSthBAZhliMjtG_6LMhlQH2DbcQYgRKlCVjFIh5IZ7GFZUyt66Y_m4cqI1Qb8Rf2oM6HCIJJLQ9rSBDT1GrsRxo5ZypZQOZ1maIbKPmaC4yLryG1OCPsyASQdm0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=VOYD8Xe7kQA0lniBYXVpAuKo3oFKAyHWpDt0JH4amXNlZ9J7vLHsxoqoc15eTAjA6oglPYd0zwAK4QpQdtZv0jvkOUq5Z5is2nQki9YITO0skfivF47CJZD_3wdgAEY50&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=hOeJu0xhC-uW6Gf8ooKdXldiqMjTwkMrPiRL7tfxCMAYgx7LQGO2FKVjBYyeRQsczHJO8YrvOhmAf48uwtZEnO4Mu9oj9tlaZBV6uinaXInS4irYgdmuHH1_fMK8aVI10&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=XlV9GqTk6b5uqDuL38kZ4M4-D19lMtmt0Nfm-OaIfmfKZXxxdkEy0_fz8Rb50xJiOME7ruSlDELDwr_q88n93Z8DbpgP-PrvolSTi43wrxjzmVSKMK-250V1wOfusJzQ0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/WebResource.axd?d=JoBkLzP19aTuxbWOhHobYndLm8rB8C7w5JAGcozHelAi0yxlDEHXqwBJPZODPDVe3kynVZnW81KTBhLcr2IKvw2&amp;t=639202794265548063" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="E2D9F36C" />
	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0" />
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="gbSHbjZPFDbCOrCd8AD8pfC6/pxHa/KvEcSNDfCn09SS5GG82VrUBxPKInO9jyPODX5MnZAvaP2pzb0BcVKFieeJxB6QLTXfhlMSJBFEffghHx15pQ/urGFPNNH4nF1NIMlYC1zFo1WIWtVFqPAcill0F3iwonUjSAwfsIEDAghLhgxoqZWVgLeaQpJHl9E4gfgGtuxN1r0qb0wgsD/g2FbLqJvhAI2tS9NB0HUOAVtqoRDTSyflCR+gFTQ5dLc9CE6yWRi6zkdJlcy6Gw2yotYjTkZf1JVlmwWtj0HiABA/0JKtRi3iuCMRdXc1T6kScXJvKC4MWYbxB6zl5LFkbdvPTuZcsgM/T8ywN3S1rlzaBeoVWFo970Hl2VmG/aEUzMz8zNutkQZYVr+xSKxjnyBo5i7u8RZRQxiYAYFrtdJ22lY4pSugFOQkPifaWIeaHPaXATOomCSF3OtwpGZiPKVlbitXdX7nHdjJ7WBjQj8+31lY6Cde3tUME/c79QnriZ0R9sUn9VsSR9dFfDpzivbuYfNXt53y46U6A8iZf+dXQx7wWJmIU7m5xihhnU068qCf17Z2/rRKI6e2g6jV+mfNNEz75CIjR84HvFbafNqQblpsJT92hb3DDIw3Ueh74t3BxMHruEoCHBqYD4wsMdjZBUk54pIPDddWeQVI1o9xloZ9JFElk/jNvmZsE/ahX1gICETZHUAyry+6AtdDO9RBTpaC/Ve1+PWL/dFNOYumpDRUVAC6JTdRliCylb+9luxkFlIPdeUDUpKsrS5c/DomsZOhDPVorfzq4Ym5xyOsL8mn3fafoOB7zraGnZItkXx7Ph1ZyWfty9XaNtmGzV3N0W/dIjNQtdyZ5AOlgLfNsvsplS3pf5TppDYS3uNcnHoP3bygtkVtzF5YbyLYVw==" />
</div>
           
        <div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', ['tctl00$SelectRegion$updChangeRegion','SelectRegion_updChangeRegion','tctl00$UpdRegion','UpdRegion','tctl00$ContentPlaceHolder1$UpdatePanel111','ContentPlaceHolder1_UpdatePanel111','tctl00$ContentPlaceHolder1$updtApplicant','ContentPlaceHolder1_updtApplicant','tctl00$ContentPlaceHolder1$updtForm','ContentPlaceHolder1_updtForm'], ['ctl00$ContentPlaceHolder1$btnGetOtp','ContentPlaceHolder1_btnGetOtp','ctl00$ContentPlaceHolder1$btnOTPVerify','ContentPlaceHolder1_btnOTPVerify'], [], 600, 'ctl00');
//]]>
</script>

            <button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-topD">
                <i class="fas fa-arrow-up"></i>
</button>
<!-- Simple splash screen-->
<div class="splash">
 <div class="color-line"></div>
 <div class="splash-title">
 <h1>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h1>
 <p>ਕਿਰਪਾ ਕਰਕੇ ਉਡੀਕ ਕਰੋ ਜਦੋਂ ਤੱਕ ਅਸੀਂ ਤੁਹਾਡੇ ਲਈ ਖੋਜ ਮੋਡੀਊਲ ਨੂੰ ਸੈਟਅਪ ਕਰਦੇ ਹਾਂ./Please wait while we setup the search module for you. </p>
 <img src="ui-assets/images/loading-bars.svg" width="64" height="64" alt="Loading.."/>
  </div>
   </div>
		<div id="updWebsite" style="display:none;">
	
				<div class="loadingContainer">
					<div class="loading">
						<img src="ui-assets/images/loading-bars.svg" alt="Loading.." width="64" height="64" />
						&nbsp;
					&nbsp;
					</div>
				</div>
			
</div>
<!-- Header -->
	
        
        <div id="header">
            <div id="plrs-header">
                 
    <div class="plrs-header-row">
     
        <!-- LOGO -->
        <div class="plrs-left">
        <div class="plrs-logo">
            <img src="ui-assets/images/logo.png" alt="Punjab Land Records" />
            <div class="plrs-logo-text">
                ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼
                <span>Punjab Land Records</span>
            </div>
        </div>
        <div class="plrs-menu header-link hide-menu"><i class="fa fa-bars"></i></div>
            </div>
        <!-- REGION -->
        <div class="plrs-region">
               
             

<div id="dvChangeRegion" class="modal fade">

	<div class="modal-dialog modal-lg" style="min-width:80%">
		<div class="modal-content">

			<div id="SelectRegion_updChangeRegion">
	

					<div class="modal-body">
						<div class="row">
                            <div class="col-md-12 m-t-sm">
                                <fieldset id="SelectRegion_fsSelectRegion" class="form_ font-resize-scope">
										<legend id="SelectRegion_lgSelectRegion" class="lg p-sm head-legend">
											<i class="fa fa-map-marker"></i>
											<span id="SelectRegion_lbllgRegionInfo">ਖੇਤਰ ਚੁਣੋ/Select the Region</span>
										</legend>
							   <div class="dvSelectRegion m-t-sm m-b-sm">
                                   <div class="row form-group">
                                                    <div class="col-md-12" >
                                                		<span id="SelectRegion_Label2" class="label label-lg-font-size">ਜਮਬੰਦੀ ਪੀਰੀਅਡ/Jamabandi Period</span>
														<table id="SelectRegion_rdPeriod" class="form-control smedium m-t-sm">
		<tr>
			<td><span class="radiobtn"><input id="SelectRegion_rdPeriod_0" type="radio" name="ctl00$SelectRegion$rdPeriod" value="1" checked="checked" tabindex="1" /><label for="SelectRegion_rdPeriod_0">ਮੌਜੂਦਾ/Current</label></span></td><td><span class="radiobtn"><input id="SelectRegion_rdPeriod_1" type="radio" name="ctl00$SelectRegion$rdPeriod" value="2" onclick="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$rdPeriod$1\&#39;,\&#39;\&#39;)&#39;, 0)" tabindex="1" /><label for="SelectRegion_rdPeriod_1">ਪਿਛਲਾ/Previous</label></span></td>
		</tr>
	</table>
                                                        </div>
                                                </div>
                                <div class="row form-group">
								    <div class="col-sm-3 district-dropdown" style="position:relative; z-index:9">
									    <span id="SelectRegion_lblddlDistrict" class="label  label-lg-font-size">ਜ਼ਿਲ੍ਹਾ/District</span>
									    <select name="ctl00$SelectRegion$ddlDistrict" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlDistrict\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlDistrict" tabindex="2" class="form-control">
		<option selected="selected" value="">ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Choose District</option>
		<option value="7">ਅੰਮ੍ਰਿਤਸਰ/Amritsar</option>
		<option value="8">ਬਰਨਾਲਾ/Barnala</option>
		<option value="9">ਬਠਿੰਡਾ/Bathinda</option>
		<option value="10">ਫਰੀਦਕੋਟ/Faridkot</option>
		<option value="11">ਫਤਿਹਗੜ੍ਹ ਸਾਹਿਬ/Fatehgarh Sahib</option>
		<option value="12">ਫ਼ਾਜ਼ਿਲਕਾ/Fazilka</option>
		<option value="13">ਫਿਰੋਜਪੁਰ/Ferozepur</option>
		<option value="14">ਗੁਰਦਾਸਪੁਰ/Gurdaspur</option>
		<option value="15">ਹੁਸ਼ਿਆਰਪੁਰ/Hoshiarpur</option>
		<option value="16">ਜਲੰਧਰ/Jalandhar</option>
		<option value="17">ਕਪੂਰਥਲਾ/Kapurthala</option>
		<option value="18">ਲੁਧਿਆਣਾ/Ludhiana</option>
		<option value="18953">ਮਲੇਰਕੋਟਲਾ/Malerkotla</option>
		<option value="19">ਮਾਨਸਾ/Mansa</option>
		<option value="20">ਮੋਗਾ/Moga</option>
		<option value="21">ਪਠਾਨਕੋਟ/Pathankot</option>
		<option value="22">ਪਟਿਆਲਾ/Patiala</option>
		<option value="23">ਰੂਪਨਗਰ/Rupnagar</option>
		<option value="24">ਐਸ. ਏ. ਐਸ ਨਗਰ/S.A.S. Nagar</option>
		<option value="25">ਸੰਗਰੂਰ/Sangrur</option>
		<option value="26">ਸ਼ਹੀਦ ਭਗਤ ਸਿੰਘ ਨਗਰ (ਨਵਾਂਸ਼ਹਿਰ)/Shahid Bhagat Singh Nagar(Nawanshahr)</option>
		<option value="27">ਸ਼੍ਰੀ ਮੁਕੱਤਸਰ ਸਾਹਿਬ/Sri Muktsar Sahib</option>
		<option value="28">ਤਰਨ ਤਾਰਨ/Tarn Taran</option>

	</select>
                                        <span id="SelectRegion_RFVDistrict" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District</span>
								    </div>
                                    <div class="col-sm-3 m-b-md tehsil-dropdown" style="position:relative; z-index:8">
									    <span id="SelectRegion_lblddlTehsil" class="label label-lg-font-size">ਤਹਿਸੀਲ/Tehsil</span>
									    <select name="ctl00$SelectRegion$ddlTehsil" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlTehsil\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlTehsil" disabled="disabled" tabindex="3" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਤਹਿਸੀਲ ਚੁਣੋ/Choose Tehsil</option>

	</select>
                                        <span id="SelectRegion_RFVTehsil" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil</span>
								    </div>
                                    <div class="col-sm-3 village-dropdown" style="position:relative; z-index:7">
									    <span id="SelectRegion_lblddlVillage" class="label label-lg-font-size">ਪਿੰਡ/Village</span>
									    <select name="ctl00$SelectRegion$ddlVillage" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlVillage\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlVillage" disabled="disabled" tabindex="4" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਪਿੰਡ ਚੁਣੋ/Choose Village</option>

	</select>
                                        <span id="SelectRegion_RFVVillage" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village</span>
								    </div>
                                    <div class="col-sm-3 m-b-md year-dropdown" style="position:relative; z-index:6">
									    <span id="SelectRegion_lblddlYear" class="label label-lg-font-size">ਸਾਲ/Year</span>
									    <select name="ctl00$SelectRegion$ddlYear" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlYear\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlYear" disabled="disabled" tabindex="5" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਸਾਲ ਚੁਣੋ/Choose Year</option>

	</select>
                                        <span id="SelectRegion_RFVYear" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year</span>
								    </div>
                                </div>
							</div>
                                    </fieldset>
                            </div>

						</div>
					</div>
					<div class="modal-footer">
						<!-- Submit Button-->
						<input type="submit" name="ctl00$SelectRegion$btnSearch" value="ਖੇਤਰ ਬਦਲੋ/Change Region" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$SelectRegion$btnSearch&quot;, &quot;&quot;, true, &quot;ChangeRegion&quot;, &quot;&quot;, false, false))" id="SelectRegion_btnSearch" tabindex="6" class="btn btn-pimary submit-custom-btn" />
						<button id="SelectRegion_btnCancel" class="btn btn-danger btn-no" data-dismiss="modal" TabIndex="7">ਰੱਦ ਕਰੋ/Cancel</button>
					</div>
				
</div>
			
			

		</div>
	</div>
</div>

            <div id="UpdRegion">
	
                    







                
</div>
        </div>

        <!-- ACTIONS -->
        <div class="plrs-actions">
            <div class="plrs-font">
                 <input type="button" id="btnincreasefonts"  value=" A+ " />
                 <input type="button" id="btndecreasefonts"  value=" A- " />
                 <input type="button" id="btnresetfonts" value=" A= " />
            </div>

            <a href="Login.aspx" class="plrs-login">
                <i class="fa fa-lock"></i>
                Official Login
            </a>
        </div>

    </div>
            
</div>

</div>


        <div id="divBackground" class="modal"></div>
		
        
<link href="../ui-assets/Pgstyles/uc_navugatonmenu.css" rel="stylesheet" />
<!-- Navigation -->
<aside id="menu">
	<div id="navigation">
		<nav class="nav-primary">
			<ul class="nav">
				
				
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl00_liItem">
							<a href="Default.aspx?itemPID=1">
								    
                                    <i class='fa-solid fa-house'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl00_bBG" class="bg-info"></b>
								</i>
								
								<span>ਮੁੱਖ ਪੰਨਾ/Home</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl01_liItem">
							<a href="OnlineRequestStatus.aspx?itemPID=77">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl01_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਟਰੈਕ ਐਪਲੀਕੇਸ਼ਨ/Track Application</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_liItem">
							<a href="./?itemPID=82">
								    
                                    <i class='fa-solid fa-file-export'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl02_bBG" class="bg-primary2"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl02_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਸ਼ਿਕਾਇਤ ਨਿਵਾਰਨ/Grievance Redressal</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl02_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Grievance.aspx?RefNo=1&itemID=83&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦਾਖਲ ਕਰੋ/Submit Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_liItem">
											<a href="GrievanceTrack.aspx?RefNo=2&itemID=84&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦੀ ਜਾਂਚ ਕਰੋ/Track Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_liItem">
							<a href="Jamabandi.aspx?itemPID=3">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl03_bBG" class="bg-success"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl03_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਜਮ੍ਹਾਂਬੰਦੀ ਵੇਖੋ/View Jamabandi</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl03_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Jamabandi.aspx?section=Owner-Name-Wise&itemID=7&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਮਾਲਕ ਦੇ ਨਾਮ ਮੁਤਾਬਕ/Owner Name Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Jamabandi.aspx?section=Khewat-Number-Wise&itemID=8&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖੇਵਟ ਨੰ: ਮੁਤਾਬਕ/Khewat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_liItem">
											<a href="Jamabandi.aspx?section=Khasra-Number-Wise&itemID=9&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਸਰਾ ਨੰ: ਮੁਤਾਬਕ/Khasra No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_liItem">
											<a href="Jamabandi.aspx?section=Khatouni-Number-Wise&itemID=10&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਤੌਨੀ ਨੰ: ਮੁਤਾਬਕ/Khatouni No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_liItem">
							<a href="Mutation.aspx?itemPID=4">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl04_bBG" class="bg-danger"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl04_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਇੰਤਕਾਲ ਵੇਖੋ/View Mutation</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl04_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Mutation.aspx?section=Mutation-Number-Wise&itemID=13&itemPID=4">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਇੰਤਕਾਲ ਨੰ: ਮੁਤਾਬਕ/Mutation No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_liItem">
							<a href="Roznamcha.aspx?itemPID=5">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl05_bBG" class="bg-info"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl05_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਰੋਜਨਾਮਚਾ ਵੇਖੋ/View Roznamcha</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl05_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Roznamcha.aspx?section=Rapat-Number-Wise&itemID=11&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਰਿਪੋਰਟ ਨੰਬਰ ਮੁਤਾਬਕ/Rapat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Roznamcha.aspx?section=Waqiati-Number-Wise&itemID=12&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਵਾਕਿਆਤੀ ਮੁਤਾਬਕ/Waqiati No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl06_liItem">
							<a href="RegistryDeed.aspx?itemPID=21">
								    
                                    <i class='fa-regular fa-copy'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl06_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਰਜਿਸਟਰਡ ਡੀਡ ਵੇਖੋ/View Registered Deed</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl07_liItem">
							<a href="FardStatus.aspx?itemPID=29">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl07_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਫਰਦ ਬੇਨਤੀ ਸਥਿਤੀ/Fard Request Status</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl08_liItem">
							<a href="GroundTruthingDataMap2.aspx?itemPID=85">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl08_bBG" class="bg-success"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-2 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-2 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl09_liItem">
							<a href="GroundTruthingDataMap3.aspx?itemPID=86">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl09_bBG" class="bg-danger"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-3 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-3 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl10_liItem">
							<a href="IPWTD.aspx?itemPID=15">
								    
                                    <i class='fa fa-university'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl10_bBG" class="bg-info"></b>
								</i>
								
								<span>ਇਨਟੈਗਰੇਟਿਡ ਜਾਇਦਾਦ/Integrated Property</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl11_liItem">
							<a href="faq.aspx?itemPID=33">
								    
                                    <i class='fa fa-question-circle'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl11_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਐੱਫ ਏ ਕਿਊ/FAQ</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl12_liItem">
							<a href="UserManual.aspx?itemPID=35">
								    
                                    <i class='fa fa-user'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl12_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਉਪਯੋਗ ਪੁਸਤਕ/User Manual</span>
                                 
							</a>
							
							
							
                            
						</li>
					
                				
			</ul>
		</nav>
	</div>
</aside>


	    
		<div id="wrapper" >
            <div class="page-body">
                <div class="normalheader transition animated fadeIn small-header hide-mob hidden-xs hidden-sm">
				<div class="hpanel">
					<div class="panel-body">
						<div class="row">
							<div class="col-sm-12">
                                <div class="nav-pills bg-light breadcrumbs">
                                    <span id="SiteMapPath1"><a href="#SiteMapPath1_SkipLink" style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;">Skip Navigation Links</a><span><a href="/Default.aspx">ਔਨਲਾਈਨ ਸੇਵਾਵਾਂ/Online Services</a></span><span> &gt; </span><span>ਰਜਿਸਟਰਡ ਵਸੀਕੇ ਦੇ ਆਧਾਰ ਤੇ ਇੰਤਕਾਲ ਲਈ ਬੇਨਤੀ/Request for Mutation on the basis of Registered Deed</span><a id="SiteMapPath1_SkipLink"></a></span>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>

		<div class="content animate-panel">
            

    <div id="ContentPlaceHolder1_UpdatePanel111">
	

            <input type="submit" name="ctl00$ContentPlaceHolder1$btnShowPopup" value="" id="ContentPlaceHolder1_btnShowPopup" style="display: none" />
            <div class="content transition animated fadeIn">
                <div class="panel hpanel dblue">
                    <div class="panel-heading">
                        <div class="form-horizontal text-center ">
                            <h3 class="font-resize-heading"><b>ਰਜਿਸਟਰਡ ਵਸੀਕੇ ਦੇ ਆਧਾਰ ਤੇ ਇੰਤਕਾਲ ਲਈ ਬੇਨਤੀ<br />
                                Request for Mutation on the basis of Registered Deed</b></h3>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="form-horizontal">

                            
                            <fieldset id="ContentPlaceHolder1_FieldsetApplicantDetail" class="form_ font-resize-scope" style="background-color: white">
                                <legend id="ContentPlaceHolder1_legendApplication" class="lg p-sm text-left head-legend">
                                    <i class="fa fa-info-circle hidden"></i>
                                    <span id="ContentPlaceHolder1_lblApplicantDetailH2">1. ਬਿਨੈਕਾਰ ਦਾ ਵੇਰਵਾ/Details of Applicant</span>
                                </legend>

                                <div id="ContentPlaceHolder1_updtApplicant">
		
                                        <div id="ContentPlaceHolder1_pnlApplicantInfo">
			
                                            <div class="row form-group">
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਨਾਮ/Name of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Name</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtName" type="text" maxlength="200" id="ContentPlaceHolder1_txtName" tabindex="1" class="form-control label-lg-font-size" />

                                                </div>
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblFatherNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦੇ ਪਿਤਾ ਦਾ ਨਾਮ/Name of Father of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVFatherName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Father Name</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtFatherName" type="text" maxlength="200" id="ContentPlaceHolder1_txtFatherName" tabindex="2" class="form-control label-lg-font-size" />

                                                </div>


                                                <div class="col-sm-4 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblMobileNumberH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਮੋਬਾਈਲ ਨੰ./Mobile No. of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Mobile number</span>
                                                    <span id="ContentPlaceHolder1_REVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter a valid 10-digit mobile number.</span>
                                                    <input name="ctl00$ContentPlaceHolder1$txtMobileNumber" type="text" maxlength="10" id="ContentPlaceHolder1_txtMobileNumber" tabindex="3" class="form-control label-lg-font-size" />


                                                </div>

                                                <div id="ContentPlaceHolder1_pnlOTP">
				
                                                    <div class="col-sm-2 m-t-sm" style="margin-top: 30px">

                                                        
                                                        <a id="ContentPlaceHolder1_btnGetOtp" tabindex="4" class="btn btn-primary" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ContentPlaceHolder1$btnGetOtp&quot;, &quot;&quot;, true, &quot;GrpRequestotp&quot;, &quot;&quot;, false, true))">
                                                         <i class="fas fa-mobile"></i> ਓਟੀਪੀ ਭੇਜੋ/Send OTP
                                                        </a>

                                                    </div>
                                                    <div class="col-sm-2 m-t-sm">
                                                        
                                                    </div>
                                                    <div class="col-sm-2 m-t-sm">
                                                        <span id="ContentPlaceHolder1_lblVerifyOTP" class="label-lg-font-size">ਓਟੀਪੀ/OTP<span class="text-danger">*</span>
											        </span>

                                                        <span id="ContentPlaceHolder1_RequiredFieldValidator2" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the OTP number</span>
                                                        <input name="ctl00$ContentPlaceHolder1$txtOTP" type="text" maxlength="10" id="ContentPlaceHolder1_txtOTP" tabindex="5" class="form-control label-lg-font-size" />
                                                    </div>
                                                    <div class="col-sm-2 m-t-sm" style="margin-top: 30px">
                                                        
                                                        

                                                        <a id="ContentPlaceHolder1_btnOTPVerify" tabindex="6" class="aspNetDisabled btn btn-primary">
                                                         <i class="fas fa-check-circle"></i>ਓਟੀਪੀ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ/Verify OTP

                                                        </a>

                                                    </div>
                                                
			</div>
                                            </div>
                                        
		</div>
                                    
	</div>
                            </fieldset>
                            <div id="ContentPlaceHolder1_updtForm">
		
                                    
                                    
                                
	</div>

                            
                            
                            
                            
                            
                            
                            



                            <div id="ContentPlaceHolder1_pnlmsgConfirm" class="sweet-modal" style="display: none;">
		
                                <div class="sweet-modal-header">
                                    Alert
                                </div>
                                <div class="sweet-modal-body">
                                    
                                </div>
                                <div class="sweet-modal-footer">
                                    <input type="submit" name="ctl00$ContentPlaceHolder1$btnOK" value="OK" id="ContentPlaceHolder1_btnOK" class="btn" />
                                </div>
                            
	</div>
                            



                        </div>
                    </div>
                </div>
            </div>
        
</div>


            
			
			
			
			
			
			
		</div>

    </div>
    <!-- Footer-->
    <footer class="footer footer-font">

    <!-- Govt -->
    <div class="digi-topBoderThickDis">
        <div class="container-fluid text-center">
            <span>ਮਾਲ, ਮੁੜ ਵਸੇਬਾ ਅਤੇ ਆਪਦਾ ਪ੍ਰਬੰਧਨ ਵਿਭਾਗ,ਪੰਜਾਬ ਸਰਕਾਰ, ਭਾਰਤ / Department of Revenue, Rehabilitation and Disaster Management, Government of Punjab, India.
            </span>
        </div>
    </div>

    <!-- Copyright -->
    <div class="digi-topBoder">
        <div class="container-fluid text-center">
            <span>ਕਾਪੀਰਾਈਟ © 2025 ਪੰਜਾਬ। ਸਾਰੇ ਹੱਕ ਰਾਖਵੇਂ ਹਨ। / Copyright © 2025  Punjab. All rights reserved.
            </span>
        </div>
    </div>

    <!-- Stats -->
    <div class="digi-topBottomBoder footer-stats">
        <div class="container-fluid">
            <div class="footer-stats-row">
                <span class="badge-pill">
                    ਕੁੱਲ ਵਿਜ਼ਿਟਰ/Total Visitors :
                    <span id="lblv">2380020</span>
                </span>

                <span class="badge-pill">
                    ਆਖਰੀ ਵਾਰ ਅੱਪਡੇਟ ਕੀਤਾ/Last Updated :
                    <span id="lblud">12/10/2026</span>
                </span>
            </div>
        </div>
    </div>

</footer>

</div>	          
    <script src="ui-assets/vendor/bootstrap/dist/js/bootstrap.min.js" nonce="pdjtQd0U/BpiZDgAEyYFJg"></script>
	<script src="ui-assets/vendor/datatables_with_buttons/datatables.min.js" nonce="pdjtQd0U/BpiZDgAEyYFJg"></script>
	<script src="ui-assets/vendor/virtual-keyboard/js/keyboard.js" type="text/javascript" nonce="pdjtQd0U/BpiZDgAEyYFJg"></script>
 <!-- App scripts -->
    <script src="ui-assets/scripts/homer.js" nonce="pdjtQd0U/BpiZDgAEyYFJg"></script>
    <script src="ui-assets/Pgscript/masterpg.js" nonce="pdjtQd0U/BpiZDgAEyYFJg"></script>
    <script src="ui-assets/scripts/select2.min.js" nonce="pdjtQd0U/BpiZDgAEyYFJg" > </script>
    <script src="ui-assets/scripts/BackToTopN.js" nonce="pdjtQd0U/BpiZDgAEyYFJg" > </script>              
</div>

<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("SelectRegion_RFVDistrict"), document.getElementById("SelectRegion_RFVTehsil"), document.getElementById("SelectRegion_RFVVillage"), document.getElementById("SelectRegion_RFVYear"), document.getElementById("ContentPlaceHolder1_RFVName"), document.getElementById("ContentPlaceHolder1_RFVFatherName"), document.getElementById("ContentPlaceHolder1_RFVMobileNumber"), document.getElementById("ContentPlaceHolder1_REVMobileNumber"), document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var SelectRegion_RFVDistrict = document.all ? document.all["SelectRegion_RFVDistrict"] : document.getElementById("SelectRegion_RFVDistrict");
SelectRegion_RFVDistrict.controltovalidate = "SelectRegion_ddlDistrict";
SelectRegion_RFVDistrict.focusOnError = "t";
SelectRegion_RFVDistrict.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District";
SelectRegion_RFVDistrict.display = "Dynamic";
SelectRegion_RFVDistrict.validationGroup = "ChangeRegion";
SelectRegion_RFVDistrict.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVDistrict.initialvalue = "";
var SelectRegion_RFVTehsil = document.all ? document.all["SelectRegion_RFVTehsil"] : document.getElementById("SelectRegion_RFVTehsil");
SelectRegion_RFVTehsil.controltovalidate = "SelectRegion_ddlTehsil";
SelectRegion_RFVTehsil.focusOnError = "t";
SelectRegion_RFVTehsil.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil";
SelectRegion_RFVTehsil.display = "Dynamic";
SelectRegion_RFVTehsil.validationGroup = "ChangeRegion";
SelectRegion_RFVTehsil.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVTehsil.initialvalue = "";
var SelectRegion_RFVVillage = document.all ? document.all["SelectRegion_RFVVillage"] : document.getElementById("SelectRegion_RFVVillage");
SelectRegion_RFVVillage.controltovalidate = "SelectRegion_ddlVillage";
SelectRegion_RFVVillage.focusOnError = "t";
SelectRegion_RFVVillage.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village";
SelectRegion_RFVVillage.display = "Dynamic";
SelectRegion_RFVVillage.validationGroup = "ChangeRegion";
SelectRegion_RFVVillage.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVVillage.initialvalue = "";
var SelectRegion_RFVYear = document.all ? document.all["SelectRegion_RFVYear"] : document.getElementById("SelectRegion_RFVYear");
SelectRegion_RFVYear.controltovalidate = "SelectRegion_ddlYear";
SelectRegion_RFVYear.focusOnError = "t";
SelectRegion_RFVYear.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year";
SelectRegion_RFVYear.display = "Dynamic";
SelectRegion_RFVYear.validationGroup = "ChangeRegion";
SelectRegion_RFVYear.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVYear.initialvalue = "";
var ContentPlaceHolder1_RFVName = document.all ? document.all["ContentPlaceHolder1_RFVName"] : document.getElementById("ContentPlaceHolder1_RFVName");
ContentPlaceHolder1_RFVName.controltovalidate = "ContentPlaceHolder1_txtName";
ContentPlaceHolder1_RFVName.focusOnError = "t";
ContentPlaceHolder1_RFVName.errormessage = "Please enter the Name";
ContentPlaceHolder1_RFVName.display = "Dynamic";
ContentPlaceHolder1_RFVName.validationGroup = "GrpRequest";
ContentPlaceHolder1_RFVName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVName.initialvalue = "";
var ContentPlaceHolder1_RFVFatherName = document.all ? document.all["ContentPlaceHolder1_RFVFatherName"] : document.getElementById("ContentPlaceHolder1_RFVFatherName");
ContentPlaceHolder1_RFVFatherName.controltovalidate = "ContentPlaceHolder1_txtFatherName";
ContentPlaceHolder1_RFVFatherName.focusOnError = "t";
ContentPlaceHolder1_RFVFatherName.errormessage = "Please enter the Father Name";
ContentPlaceHolder1_RFVFatherName.display = "Dynamic";
ContentPlaceHolder1_RFVFatherName.validationGroup = "GrpReques";
ContentPlaceHolder1_RFVFatherName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVFatherName.initialvalue = "";
var ContentPlaceHolder1_RFVMobileNumber = document.all ? document.all["ContentPlaceHolder1_RFVMobileNumber"] : document.getElementById("ContentPlaceHolder1_RFVMobileNumber");
ContentPlaceHolder1_RFVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
ContentPlaceHolder1_RFVMobileNumber.focusOnError = "t";
ContentPlaceHolder1_RFVMobileNumber.errormessage = "Please enter the Mobile number";
ContentPlaceHolder1_RFVMobileNumber.display = "Dynamic";
ContentPlaceHolder1_RFVMobileNumber.validationGroup = "GrpRequestotp";
ContentPlaceHolder1_RFVMobileNumber.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVMobileNumber.initialvalue = "";
var ContentPlaceHolder1_REVMobileNumber = document.all ? document.all["ContentPlaceHolder1_REVMobileNumber"] : document.getElementById("ContentPlaceHolder1_REVMobileNumber");
ContentPlaceHolder1_REVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
ContentPlaceHolder1_REVMobileNumber.focusOnError = "t";
ContentPlaceHolder1_REVMobileNumber.errormessage = "Please enter a valid 10-digit mobile number.";
ContentPlaceHolder1_REVMobileNumber.display = "Dynamic";
ContentPlaceHolder1_REVMobileNumber.validationGroup = "GrpRequestotp";
ContentPlaceHolder1_REVMobileNumber.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ContentPlaceHolder1_REVMobileNumber.validationexpression = "^[6-9]\\d{9}$";
var ContentPlaceHolder1_RequiredFieldValidator2 = document.all ? document.all["ContentPlaceHolder1_RequiredFieldValidator2"] : document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2");
ContentPlaceHolder1_RequiredFieldValidator2.controltovalidate = "ContentPlaceHolder1_txtOTP";
ContentPlaceHolder1_RequiredFieldValidator2.focusOnError = "t";
ContentPlaceHolder1_RequiredFieldValidator2.errormessage = "Please enter the OTP number";
ContentPlaceHolder1_RequiredFieldValidator2.display = "Dynamic";
ContentPlaceHolder1_RequiredFieldValidator2.validationGroup = "GrpRequestVOTP";
ContentPlaceHolder1_RequiredFieldValidator2.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RequiredFieldValidator2.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        
theForm.oldSubmit = theForm.submit;
theForm.submit = WebForm_SaveScrollPositionSubmit;

theForm.oldOnSubmit = theForm.onsubmit;
theForm.onsubmit = WebForm_SaveScrollPositionOnSubmit;
WebForm_AutoFocus('ContentPlaceHolder1_txtName');Sys.Application.add_init(function() {
    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":500,"dynamicLayout":true}, null, null, $get("updWebsite"));
});

document.getElementById('SelectRegion_RFVDistrict').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVDistrict'));
}

document.getElementById('SelectRegion_RFVTehsil').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVTehsil'));
}

document.getElementById('SelectRegion_RFVVillage').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVVillage'));
}

document.getElementById('SelectRegion_RFVYear').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVYear'));
}

document.getElementById('ContentPlaceHolder1_RFVName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVName'));
}

document.getElementById('ContentPlaceHolder1_RFVFatherName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVFatherName'));
}

document.getElementById('ContentPlaceHolder1_RFVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVMobileNumber'));
}

document.getElementById('ContentPlaceHolder1_REVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_REVMobileNumber'));
}

document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2'));
}
Sys.Application.add_init(function() {
    $create(Sys.Extended.UI.ModalPopupBehavior, {"backgroundCssClass":"modalBackground","cancelControlID":"ContentPlaceHolder1_btnOK","dynamicServicePath":"/RequestForRegisteredVasika.aspx","id":"ModalPopupExtenderAlert","popupControlID":"ContentPlaceHolder1_pnlmsgConfirm"}, null, null, $get("ContentPlaceHolder1_btnShowPopup"));
});
//]]>
</script>
</form>

</body>

</html>
