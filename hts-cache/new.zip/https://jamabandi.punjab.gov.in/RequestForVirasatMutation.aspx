
<!DOCTYPE html>
<html lang="en">


<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="google" content="notranslate" /><title>
	ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records
</title><link rel="stylesheet" href="ui-assets/fontawesome/css/fontawesome.css" /><link rel="stylesheet" href="ui-assets/fontawesome/css/solid.css" /><link rel="stylesheet" href="ui-assets/vendor/bootstrap/dist/css/bootstrap.css" /><link href="ui-assets/sweetalert/sweetalert2.min.css" rel="stylesheet" /><link rel="stylesheet" href="ui-assets/vendor/datatables_with_buttons/datatables.min.css" />
    <!-- pe-icon-7-stroke styles -->
	<link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" /><link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/helper.css" />
	 <!-- Custom styles -->
    
    <link rel="stylesheet" href="ui-assets/vendor/virtual-keyboard/css/keyboard.css" /><link rel="stylesheet" href="ui-assets/styles/style.css" /><link rel="stylesheet" href="ui-assets/styles/responsive.css" /><link rel="stylesheet" href="ui-assets/styles/plrs-custom-v1.0.css" /><link rel="stylesheet" href="ui-assets/styles/CardStyle.css" /><link rel="stylesheet" href="ui-assets/styles/custom.css" /><link href="ui-assets/landingPage/css/style.css" rel="stylesheet" type="text/css" /><link href="ui-assets/landingPage/css/flexslider.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="ui-assets/styles/select2.min.css" /><link rel="stylesheet" href="ui-assets/styles/selectStyle.css" /><link rel="stylesheet" href="ui-assets/styles/backToTop.css" /> 
<style>
    .d-flex{
        display:flex;
    }

    .margin-left-right-auto{
        margin-left:auto;
        margin-right:auto;
    }

    .margin-left-right-auto h3 {
      color: #ffffff;/*#126f00*/
    }

    .head-legend {
      padding: 20px 0;
    }

    .head-legend span {
      font-size: 20px;
    }

    .digi-pub-footer-top{
        padding: 25px 0 10px;
    }
</style>
    <style>
#SelectRegion_rdPeriod {
  height: auto;
}
</style>
    
    <link href="ui-assets/styles/plrsheader.css" rel="stylesheet" />

     <script   src="ui-assets/jquery/jquery.min.js" nonce="WkJ+eIw8/3K8i6BTDgyNiA">
	</script>
	
    <script   src="ui-assets/jquery-ui/jquery-ui.min.js" nonce="WkJ+eIw8/3K8i6BTDgyNiA" >
    </script>
       
     <script src="ui-assets/sweetalert/sweetalert2.all.min.js" 
        nonce="WkJ+eIw8/3K8i6BTDgyNiA" ></script> 
           
    <script src="ui-assets/scripts/plrs-custom-v1.0.js" nonce="WkJ+eIw8/3K8i6BTDgyNiA">
	    </script>

    <link href="ui-assets/styles/modalp.css" rel="stylesheet" />
    <link href="ui-assets/styles/HightLightFocus.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/reqVM.css" rel="stylesheet" />
    <link href="ui-assets/jquery-ui/jquery-ui.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/tblbrder.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/lnkbtn.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/rdbtn.css" rel="stylesheet" />

    <script src="ui-assets/jquery/jquery.js"></script>
    <script src="ui-assets/jquery-ui/jquery-ui.min.js"></script>
    <script src="ui-assets/scripts/HightLightFocus.js"></script>
    <script src="ui-assets/Pgscript/reqVM.js"></script>
    <script src="ui-assets/Pgscript/MaintaineScrollbarPosition.js"></script>

</head>
<body class="bg">
  
	<form method="post" action="./RequestForVirasatMutation.aspx" onsubmit="javascript:return WebForm_OnSubmit();" id="form1" enctype="multipart/form-data">
<div class="aspNetHidden">
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="mTY9p6PRJw2p4zN7tWPPtXJwJwfdxreV+UGqy9gy8OrzLMZ6sWsVuFlj+k3h9dp8Tiqdws/oItzhT3zN+fBgLo7AoT8DzCGfYm9t7zReBs2XSannzyavkD1R9JC+/E4XbE2GX1l1P0Y9TiXX0a8jBTLO8KWsr0UNBzmpGfcxze5+FPtYDFlmwFQR1GX4XLtVDFA0IW21neq3C5wnXoMyOCykyJQz9fSJ/tPgZ9w23s/L4xU7D2jbgCAUleJwnoRoPhlSqQiwLmKeTfBHU7NfNnd8MhX4eynZEsTyjzaVkL1SpGYdadf6LgaiyExsZ3L41OnbsiARioo9l2OhpV2FjGBd3NgtbUvNrrpp8YpDivK+qsOo6iRntplqd6KBqG7walIdUGExiERIjp7TP/iZ1IuWPsZr1DvxAMmZ61Gp5KRKpdfOXu4z6D5Am2xjtRz1K/JdRhjsD4oD3/PssVaAJ7rDbVHUkgkns0Os0i5l2RhsznYJ7KL38amJeGXEOcTRg/F4OKH3/bFDDSRdlrQnypEHPl8mvRJ685eYXU9fcqbZ9LMVJ2hxdKOXCe1gA0BmvGVKCchsFiALuRD9v3lOnHkuRdBXHdWOJj6yZjYyW3xcjhkhca2ZDRmBULcVWdJ1TVvdSrSTOdiRcqawNAs6NP8ach5VimHn33S8UCKJCP3HdZEaC2JdO+PuG8E6ia0U1tZEHS0qPL6LTqdzgZRCVmmIck/n2SQa0AOGYD15vWXVu3DVGZ/v4FS+18DQg1OHIjtNJ+gA+8IOVz7e+QFb+DQ7iWI7A1BaHQVc8vguF9h8fI83ALTXIU80OONWxendCE6TTrHz4A9kxMdwQw60xIXRIvNSTCjwDv2fk8G9RWUHijZUUwUlgBkIwCD0LQuWzxqQZU/JQDqKqqVvUmWbjqbu675MriwjkqTWkdcy7LFqMmk2APC9aQslyUDUb0zSBnzo3dNlTcn5Cas3l3LdShTDupSPqbo2u3UbwCBZ31c/ZqCuhHIRbCh5O2kg21erAavYKFXfCAUvMGs9A0pgXDtQzZ2MYHxzNXu1UgcsJLcVs1GSh+A8TKkAtGususKsZk+aDxZy09uXt+ZtfoALbWoNRM7Ntm3Lm8liVXriXXwIZ7QsUMmoOUI88wMYRWf9LdZHd8Xur2Y4zU0MwPDs7oGL2nTLB4tM/mdDEah3g+om9WIZyUuYB6ly7ja5iGtfR4svC20DVJsVn5EeGXqGgyRjGL5Datr6Fwjg1FJapduoEX2vOdSBkbI8ipu8yH5rQDr3+Q0e0C1gOgnyoD+2XWdNv42Dc9HQou0rcIQMyLBkA1EzAHr/GBaWfTJaDAnEbPoqBgasiWWjfaaa9QsdsXAxnbpFY9wRk/ebecq0NHoUACvqx5ggj/1bH9ZQKxmhbpea6dGkeYLSAj1CMxyMbxjM7zxN6PrDZ1/sl5psD0ojDP6D1ctFBKJ1vIDkJ6ZSz73E9jeGwEJuOdygqqOW89QnX55gAPsyVuT0BXZxKbJLKtQRhgxeumDXJHucVNmAvQec1bnNSl+WcJyYGc22hyr4FWjJOUCvkFebvvD+/cCJcJPf3pdEyrMyKXqjw2W7jUWp2Vsxo7x6C4F/yFKIgxL9iMq/ss1F6eHSBYWfR7HOYZKdkLYM6+5XraPIgxo/HDVRUcegTlSM2XGp5L3boQLr+ubkvo8G1A46KAm8vN0+whq/FwlQdg9gRblhw1wCGbdxbipfUl4Qv87m8kyecp/FCC3jjfyXqPCTkGjdukFDw9aD8RJbKDpUAWag8idReZqoir7WHUMlIHqapgt4RVpbG6+Zw6leokh7Fu9Kca4RdN0sR6T6w4NtPLqbVxkooUFchMmV914YX+J5aUvZz3NKrq7CAkODbCmSOz9E5akGzo/T94mXOj02h0Ax0R4tbVrx+mt8IGVhP6n7eCJfFoq1F+lqZTk2yiDrpwDJSXtfp9++MB5GElSBN17/nMKPNyAHU5hdBbFrvUmmhGF8sBMCcv+K3C/adFOceF/CrzEyK1y0wclFK4h4rRPF+3c/cnfXEPquY2mnWlKaeXs6pvyg6B9TCHTTg1FE/hRjNBRuLLveNM0b12eBm6zDDn9D9e67H2Bf3nHOWyw6PRYwbLfWEMhbVYrr+X7EjOFpRF7n2YmDWh75QJ9Hr20RDXEmnhROOgGCcUpr0l67w5eXoNooVXmP9iw8X9efl/ZjQKIw7c1rkWCS5UkrAlDFKLVYefEj8JC18vujI8su/arm/c1/R2vL+gDjNrGs4MjZEaNXeIHQvMFtKCmYgAv32mrbkTYEhTDC11MgQ3qO4c92icZFXo3g8J1bKcxPHlohNm0hSFYV0ypSheF3WHqK62aaJmbS1YMbtC5XS0hTbnr5KiEV8d+j1x2zwjZSrA6+xFMU/u45zMxZmwW4NbZ6nETY1CGfwYOhL2XE/IJUzGafwXREJKQbmu8rvI1StWhccuKJmUKYL2PVSSi3z2RZ5VKWrF5nhu2Md+j8VM9HC9kjEdoEJwMiV5HPRruHpoY40gDWg9FHVTPUvuNj0BnDN0lMjaPIXK6avMblQQQUmqKvF7ra2TRvCPYB4GSPqh18D9KakievP2j3tjahpQ+lXAChRxhhQivD/PSb286D6+lKvzVF/y5SR9IriHNscVEzNMIauCJ6vp2T9GvfIk0kt6Ok0vTJWaCt0eQa087iBAYgA0hbeKy/hqNdCaFBnxaqtZEZxfRo49r2kHBashcYC4izAdgwWUnz1Dn+jzgpsJTwS1IzEWuukmiwSmH9tn5d/ArrbGESsju/HmhRnr0IK3dcgjbGzJYlCimzgL/GUwKjBjFKAVtv6z+owBIeE9jdoFN+aTVxL1SsUxs5L9bKJLGtVhEIGbiWWjqQt7WuF5cryfOxVN7xoTpweeiiuoutQu7ummfAnbHZS4zROJIs3/p2cQLh6vVK7eUeutEl/i9+LCQ4OY1XY6cKH8c0N+Q2zm+uvac7D0rPkKjOF+D3sxJ+wxi8AeEmnY/gZKXGhgqg8XLkOyB61t4ce/16DoStqRFcEgz0z2KB4CiL0HCdkJFaeB4X8ccikfdmzNkkaaJ020l5s/PKTGLdSQK+1CKby5wMfq21Fa6v948ewbEXqG2N6uwLUau9kwPiqWG+/oVurkS0QV/gUK+fjQG+hf3NQ77jxyJj3vL4ladvsT/0fJj+pxpRLu7Mz3X9dB4v/n5gsiDTatUowuWmeEgeHAHMKcwF/dIOaUr5H5dMU6wpPFOCD2jlJFod4rbKLN+WhoHzFYr72q7Njd9iibdwqqwaGMzaSIbr7kw0RtoFNk+32E+dvmc1aYLNZQ2eGHqpx9vYUzPJeWxoOOAMbwZyvrx7VhxgOgcyAbDOIPMWgNFC7mbwK2DAbldk3vRJ8gm2A9BcU2UY39Z6y7gTxq+H6Aok1SPz8GjWAlejnL+lXwX2p4C5jG9JmhNj4S3mZLzKMZASKX3ptWRup4v/3PrSqw11DsyApLYiqMC6W29KXKJsk9HsS5Z120RHmOxogo39fVSxGy7mR7YsqMqRF/K1Nt3Ic5QU0a6yHIq0hp9prrHYxG3qIEa0ymLFzyu3wmP9rl/BqOTej2cLRkTyrwxDzJYWXAEqWErfQ2jCcwdBEB3cxq3NLPW+tHuBsdRf1vkJywcmrLXYR9UyW184kOLokiazmZGWbUA6iSLk8Fhi8oD9l28Yy1Q4UXnzPEbYW8DWs8wf6Zn5iYR1aAu7BwP9hHmrHZxXy3AiFPctJQWIhgMK4nM7MMgcyKBN+RpcXuzrVR4IwT3BBqHWXtjFVM7v6SN92OyA+KB7C5GGPzu9YDHotDmURPtikYnmxAMXEG9tEdaz4sQhd7o7b1b3E9jw/gjwc9aovya3ltmulF6O6NGhGhn4OfnG3vL8892xBdkymGh3dBUxysvjpjWHzn5NNdnb/s2x7m3zre9aFrAfpRHSmfySGpimOE9iQq/FyKXGGO1DrUc6PmKh0FkZMwPba6BYuV4KUSbOL1dp8guL3hO8ufS13kuZaBI2hi7qErkbG1lr/tH9faLAtotBqqnVJsKjpdPTMGRNtobZJB4jLzYrC7HxLP67L0XbkFpOp2QGvHfKFnRW3MgB4ILI+Dl6TiROBYA4ZTx2toJ/dEcdfIUVF9TxPOi/hBcMHcrfOwEddCl5VoS46tsgiGkQ0Eb1swD7WCxbECP7xJzAzPbEbdXTNDMBXdohDGauQnoqCDeG1G4fUEb5kHU3yjHRhIdY6ke+gESsbArgWu2W+CZIrfX98TBaBAXfVe2jgGMleJtTkRAPHP8CY96F3nh/bv+i6+82T1EMxhjZCZUHdj6mzDtP9Thfj3Dx60M8cHbzva2yGn3zvUdwpa3Kys3gaJY6NmSfodXG2gPzXwUvvmDOxe0HA/1TixRx5/A6QLuMwECw2KJlvC94p3Bp3iZUsV6tA0galB/GlL6G5av5lfKHvDyggHRAqmr2HjRLOGTr+MXZTLiQP9FeQVs2GufvvmjD5pwmmdjadypAgRfBKUBrTZRbNzHUkYRqcRrcyT89sbXoVg58vY/89ASpE4VpoQA9D8Ra+wJQ7pI2Q33M4gkM8tKkS+FqSvnrKyNBmkcS0t0+XTAaoNVaRh/DtpnG+wPPv8wJvEzBGPbHIfSxx4QWqNm8S31szPObOR++43wcVqPdI+PGSf7/rx/2AlleD6syCyp/xX3L63kzemuFVr1kWZy7Mocc4H4wY3etFDOYMkRJLof4hm1PS6ZaBc7CbfGBHyVC4atV7lIw0Dw3PUXFMoLamHYzx5/pKM0RT2FjV4qww+htGiYCsOdR6v4HvVFHP3x2MPiFMJZ8xY2dPh/VFI3hjPpnKCi1/tSBWgI/huGM0bicevuyErxYbnB2o9Et9cHFZKyoEO2q7rkQ8Q1DrwcAfO1PBCyI26ev5acfw5E2FhN9A4w7W5q+ws7aaHwHLyF00QoAVGASaHUZmXw4pPPD8qapOw6JgnxgN0cttaJxkMWG/74ZA/ICrm3NkolFvRI+hR5zCSrfBMrz+hW0Mmw+knjoPPiJ2IWajp/7RbdklYt3eocqD2Y7KJsycMgPzAEIiGsGmGbOmR4M+16nN5/X/tfEil7OYtkBwyQ7wBSmlzwuyjrbZEMU4RwRoJuiqOunXGb+xp8hzbpEQrV2PPSWgdsAIHgVCqfyhFUY1GyGz5INtNsuGsFJ0w2XaRQ6mXdtbfa+wHawsrC4Ufp4g5GYBAqDF+UxW91BKc/c/WLoO8TkrP8FVB1V3opQr0mQg+RDTDMY9e2lpxd7WUZXdURhUFCed+t5hUvLeR43ZP+/uwPsAQ0kBRjtKZd1PnaZQRCf2s3+1ZDMRRGf0/xOtigbVoI3Q3yd1SNoJ4ApZvXur+LEYMeE3OK3MV9AnEszsW2CfGmSLxrOBcfVlg6jbk4jSXj7l33JsWFFLCwTwSq04LHbmwgQ4N5dWkyaw9UnJTUSW7mugCObGGDiO712rqeFSao7Z18FsdvJ+Pzbp7pgI3sxf4MmZpjsU40kobwyYPGwyAcvXdHejDOcAkF0PWUER+/4dNoL1WZDsGhLLBI0bnJ0ClfhZj4jgGxrpG0mdqN7gX3Na9vaEZUrQbkkKs13XGqmnKOVDTTZeVMBN6ssFRmszmupxOGSBhmCRrKGZk+imsf35y+Bu/4VZF2apq+d7eKUykt98aUikZ2ROo351ZjkBEQUxxzmufn4LNRVb2a/wYFMMJpn85gZ+NzABQ5zbndmGN6xtrogzY4DAXCtAjKiyrAaA+jcbD7ACZQuMV5q+yt0c33/JgHkrlNysSciV8HP8VucMgh6ko2DKyWU/Lgx+a3voVkfWQQt9EcCohR/ze3Odk7sLp+kauAfDkgzQuFQKnyS4VoMN3Hsox/1sNwDAkaEB8Oku5Xc/2XoDtVwNwG221ziZNsBfglRwTGdFjaanlLhCDGnKBJDlu2xsBnJoG5Lyo554IzXu2JiPWbYB2pjp3NUGnRumqUPOoDnQL1YH0Y8/XMEqNew1SPVnySgZs7La+xISk3/rOZX2CzeH6sYwYkcwAaZe/WlwbSW3IPBDqzrWFaVOg57IcD8j1ax+eexghOyeobsC3R/6S2+L23ZqchVOp13x/1c1b2h3oLLK3mQT1GSi/BK/LO6aD8LX9KQGmMy5gyFKYjFlviiIuM+sXoqLfLhkHK8B/E/NF/AyuFiwx5nF5Ozhw7MYo67cU7FmTuZbZ1V1zox7Mj0gFR+SON6XCT+DZUf7pUbQRe4oPBpC6DOe6wZTjwdy6PKmWQkE02aoav6QYio+cK+PfcEN1W5M7DNdeppILp5l4Bi45PrFQANvr2Lx58I6le2h3qvOBFfBaxoZET/vjSMgmh2pm++D0YwOkUixn0cQzl4YeBmD1GNRTNj2a26G1dSjFuzIgk5n09oHjU0GhalA8kmJGDm4o5VwNErplTFwwiszdEE9+M5ydM93ZJEzkUDKwHeaXwlhcFxj1vkJYa6k/xlGAe/jNd6K4RyzJ5RWICCXcF5EaUW0m6YRe25T2uoYnVecNtFWdjyps/hp3AYI6frZpTJjOlFITaSly730y1ts/XT8O1HZ3rAJW+bx2Ofsc3RTztu64/uCjpP7Xb2isjLJ6pv0BpBTXF/rgzp+Va+/sX7tn//A004sX7tuR16kUxVkNhfnbKYdNLHGkaCyr1zuF95RdrdqgxkLEYtGbrm/xS4UQ7XAsDxBsYfC8+vr6d5NNabZaD8hd+t/M0QiZdo4EqzYE+azNE8sKU1O5HcmJex09Q+5pR6c2M6snB39CW9JoJF7Ztyl4lkl69j9aS44GZLZQF006IaXcPDl6XWnSTl7gFNRwXg72tITFK4Qrr/z/UifvtUx1SLRBMutxYSQ7Dkc4vo9oh7GnzqmItyymIrmvjW3tktlpCKwN5wWK40qb0J1RntgoSOLBl/ZEnJFkKxWJeTOk6/7QTHciGimzM9UWMwe37XullkRaZLAQfZ1B74wOVPe0Vade0wPVXoY6HzlWOM6sAurmoy1SiU7AV5z09rJQ0UyNR0DA8uSpEWO3viOSCjipYd0gFcW8PrxBcUv0vYmGkSrSeluuNQ8IDPI01UiITtOU5v/u7fG0sbcHbGMc4RAzvSFgwSyMHklaEVf9XhyF51UvMeSKR6zgeKp6YlKVs2yK1x6jkYZAsdQ4URuDEABUELToVlOXuZO/bS6UtHaNzQMjIcUMcTVQ6A8xnKr3kizqNroMyGgH8P+MvzhuTC5Y7C61fqH9KOVFMtIu4AzKmuPfMP0p346j7elXsENBOyrTDQBDZT+x24GKynpBE1Wim9vQDfQ1+ZZOvae9t+1b7NJ9LPRpJSBhwkGf8wiCfCxrOK5+FIPb+nIrxDu38hcg6GoQYnqv6U5v/5tzkBYZx1INEUdPSLDlCk39qryraOcxCuZLgJjEiZKXU0Uea/22o8IDG7s/hXji1uOdaiSyjOPYqygBRDsxa+cT4hK2Dk+QrgsLmDG1IkUCcc+PxB3rqUBJiYvpe+qXiG2xqydrWH8JGBBSe/HtiAiMIXtHKAkB0QSH47A6XT4Y2MB4oyaWX+BBUU926IxNjpsBxkHLR46ezS1M37na3QQT9XZ5lS+6lG8Z+EAz8NgEmZtE7HXYAEan/WZ2dLFv9YuCJMy0ocLTNmy4mxJMXOQOHk2p+3FDO9iKeIJtRZhOu9q2f6WksRtIsDIRAkf4npBK+lLEd31QMZ/HbxO/yhHWboHI20ZAXLynWbKqSHBn+eL15PMCdEVTV0uwp5+bSnIZP0+2xgP32ZXjUFH4ftefhjHT5XtXfYTs8PP0tPcayQ879ct1H95Bz2MwMrnGKFqeZGh6XeMT7D+7as1X8aknekpw8F7dt12EULHgrykiuznyLKH7z2ISl+gxhI9DLF/1a/sadzr+Tnd2oanHKWaNW6iltxwGhSksAqi4FO/s9kRbItc7FQYgUtMob3tUwCEblPvwPXZ4SdEyJs8+PtCpxAUK8Nt4RlV2V16GEFpXFlQtW9ctS78QoL5LmcsL0ed/IW/N4JbvA3/TXl2KkBS3U+56XE7+CYGy8ede3BhDmoFdbwBCgLXMluIMZvGuFoT3AzlGEfaDjVEF6bmD5NmeqnO+OhBcWbQT+JOQFcuLaaVua0maEczk8t549sQLnCY8WChrbRVKIArU6Ac+cSR2PjdmVb4auf0O1XGtbxDG5JCDjafW/Af5IP49hMQZTq3ijs71jEr0t6AbeGTuczgjMg477yPZjhSYWwdFfQ0SYq2aUKjU7c96p7zuFeovi4tW7xnix3XL7R4ZCn2I31fAV86ySAu+3MDibsf/lstjK7avfxUIaHQ+iYQOJwO5yQqzrE80rrjJQXzwxSFnwZQoCiFOvuSBU1lZK8nNH2VU5w1Gk13qyBNdaRwj6XJSyhyD1faxVzDMYnM8b0+RVsQhW1bttCM1PPU53vvZCWq18SVKw5nYxnw+ljPNT0xVYaViEuw25xX8JVHP4TeoTcorG0KKtxqAC0I1ssGFEcL06gonluBYgp6cKfd05AXi3GTyTDYdxvLmkfRgyrkmXzoupyYFUh0jyQ+isDa3eePCicUqHDkt+wI7OB1fe0M91b3TGUpQ85xKE0RNYzvxjSe26hRSem7fxvxUdX2x7NBcmaV2u60hAOyCJvEN4oWvc3u3gI5DRbtxgVqR3TAstCjtAJ6V7fxVn5NZSHYV7iG19PexqRpzcOLw3Yu7PRSR3RIMJHcJ57Hb30+bp9x6JFsvWFUxX/SIQny2vraxgfEuZ6OuunOgmRRaqS3SAu5SAt+k9SrIi27a0hXgFcLcjXaRU21rJuTf5K8/E6WIMKEO2Gp2wsgbh2Gv53ptsorXdbzaOEsk3DWobS6aUbTO05t+dgNet0VLXEoaFoskhZ2CB2SCHUyBT9HO4MggDG/wAICOCMdW1cD8YDt+8cibJRJr19UkH42Oiw3PCmA+Rdupct8EmPEx++SGT/OMER7Sj4Uwjo6WvNfIYwg65QAycSwJuqIf0UZFL93JoAacmpAFv1j6ZAxRQ+pwB2ifJfDGkIOHpExuZ8tDXoUUtVqAO24hR1vOCqoCmnRhF9qNbuV58QfHOtXQgL+kgThVqDcGbX7QQ3YYCS23vZW5xRcn7MyPchCp1Gz3YiMRuzFKYwT6uInD/HZs8ZgA1bOUf5prAUcXGsGVJiWJ5LoIiBTFms+bTyNj+mJ8MahNxxDyfIG8Trnvaovzl5BMxV0DxxA1K36ZfT9DFZk5SDRge6PB+Kz+i0nZUARg45eA0w1ZZVBzYiZegk2t/H/98GLa4lNLYsPUCd6dBE9FJa4upoY+zjxb+jnfi18CQUSYTAkiu0at3uO4ecMJZTRnAbc7WegBc8i4jsPa7m7fNRmkMwjcJR5gXO+ZK1iqX02iDg3b+xyaRqk6fRs1WyI/T4y2ENln9FqeGjs2avAQeJEaDN6oVhi9H6JFcREd0cC1wO2whJjk9PeZox63pmZeEJfgObupXyDWZi9jMsqgtAp2Y2OshncpiUzyqfwQCcRnYoWEHJ3QOLiEfwwWCI+/Dl9heFxtmlHGhB9xKSJpAOX9VcdUvBy2mOPnqIqOFeOePPUVSjFZXCQhMOQhprfK27XigvDXM8a1L89xK2wpyOR57/w1UMov+FaxHBMKpfWnVt/AI8zA2vu6fBoA18ipdZ5RTkKoihco2gXalwkkue71IhH2XRToT87xTv4kdl+jVimzzkjyNs7139o2F+MAf3DQuNWP2zOGn6Xe+OT1korSr2h2tjGwdXP0WmANzTU0c9a7W9fMkGkukdZ7cQT0/gan9mEQaGiXRJRotCE7GHW9qxGZSrQiHfW7viYXAA9/od4NjYABGNFcGkkFAjSVfCNP4euL+JG4rZpWJh2iUITK6mg9ZL1eDZVi6GBVJ+5GSNYJV30OIxnme79PpyCxX4v9JgWUmSDVpc/LB9SSmMvuWn4vK7Ap0N58MGzOFT8sHCVncwvwzaRFZeRUEHzLN6zsyGrBJd5ENC0mOYAXwOCHKpq4X/fbT6iV6zgBvDPf8iIotlSiqx00ZfYkScza/fX2d435/+iSEpejZosmMMOGlvOmZWfvv7Rw+SIm/IPSc8QEbU2wDFAbUtuuuPqU87JlDcSWflFtnjDSTUjX0o3Lcza3/3cdHbJqKCRKatBH6tBV/iftKTAG+u1mhukmdlKWtDPU5TY7ccHBT0B8qz9JrgP0GCnIdrJ3LbVpxYJgGo378WTK0HwdlAf8NVWw9lQG/lnLO6DwKOkktHtopmdBEIOGz9nXp3ipfWgq9I6JJrxfnQJ8B4TCsJNSjMy/ps7kDBd01H1sHiE5XCbJsiGAitZNIHAANt4EKHRY9bd83pV2Uj5ENlrS0+npXpZO8VAnvV8W9oTXdCEZPsvuu1D6u781zDmCkSkTsyCpRVC7sppzWBQhd9gNZ0bf1iGAFyPJpK5Tuh4+590PekwzNOtRhOg+h4XmAxBly9/UXlZc7OiWp3/qUWzNQiW1DQYHuttop3/AsAtn9zrzo//qYPLt/QzmfPFp0nEKMNsRNLRKcSePI9AEqpIMiOuprRrx6Vz8OhiPwzlfQqennyDS+KTlJ0dJgQATEI7T57ncyDNWxepQLgB7B2tzG6iV1ZI+vKyOV0XLoqbOwmcD1LdD6vdoSqoO64GL7c3EM77aurizXBfIp6ehpFOqyP9CFVNZZM8MQKp5ezl8rPeOxq/2uL+S9vYdVmTfRwXTi5Ic4XaN/GJJ5SCz6ZfdDKeC1Ilw0fJskhaqdtytCJEAZ8T8Ixrti87Rchc5ir2zrZ8MX0cwLXnF2ZZo4lOpJvVzX2wTLen9ObI73R52ANwOL0k5P2fgjqtv09BWk5SX/gGKEaGTl4slCd7bnOZBkbx3YgnTndlssbykNHIViE2F3P3DO/0rpPanbksNqMzsM2lzfXvGWhFCSDYRLJtv/t/P6d+TaGNtd/hgayrT7Xrj6lQruSlSTRhsSnhP694ZygzN2BfaeDWHez73GqkSuQMa6734NZHhDMMJYSgIiylxfhZAIIViFgSZZnEH82pN8jFCeVdFwBovCwWS67WiabXka5YNI3HmJZI26S1NUVVT7SZPyLPIjnWQeMpHRAOFH/omaPxZTzwCznwdWGq5b24wPB8+xlmZudNDBcQ5nEaQQFwJShNJbo/WbWZxnmrvDpooDr//rafCi/hub0Bkle26vb+PFic5bOjAMv+uLloaDRG55MPQPxHpfNo1zWysIEO3vqc2malaZ1ULlA7QOILIIrEiikKFeyBHL26tbePxHvIvLcpKctlgv40f3hhX0oYKCxM4cg4XeQFs00dTxiyL8Xh1wO/xYQ8L/S333ZPKzf6Iwz8iGsmRCwroBlehItst4Tdke5qLtNC2T5I/ZK+DB+K8lEYWZn84ar85y98KNDA+jv7dMmm2RtxSzW3h9QOXT/x1guRlsFwM6FF28BOvLEK8cPIBsflvOizD/ChkihDYuZO8plncdK54MScrYblXBWqCD50vnbNMW1gmvo0yC9zQ5e7g3htcKRqVFVoWvq5NiRFlO5Si8ozlbDBle2xu7m0+1vfZVPz2bey2lJiwzPAl3Cjn4IbaMCgR9TsZyZWW/t/EABwuNMd8RDJ2SXEzHa3+buHL9GXjPE5s8PTVr6B25fQ5UfOALOpkOFVQtjfEEJmrxehZYQClWScr//OxCaTCusSM20aH+ACRr2dSf0zKeGE4npGROYlfO5R9ir3zSC3vwhTf0I5zJhlNUGMk0DwjfbH3xqIM2Lx3O9jIj/oTPFP0pSeyGzQ2Q2jT9h4x/FgzVJC9uNk+C0We8tpTMwrf+KBMM2DTMTlS5zOhVkgxzROZo4R5dK4U/3rxmUgRf76kCRa9UXgINHOECi8LE1DupC0ndhAdRhz4vyHDQ4VdKvkV8E19idWicPoOyc7s+nXj9Yv7vqxRDcDbuspq1oeQqk6pUV038kRehriIHXIxfiomMPtynW26HLiK7bwQAHsn0tJRxWYlS1F5882fbrO45wU++w7pFUXGDOKWfwc5Fl0ZLXSZoeO/et/pshXzS62v1nSAO4LC1re0WdsA4Z13Zvhl64qSi3SJWTLmRlDn58pAL1SSnMXUWH2zPQkWakMN5XG6ns/Tpa/e2bxtUNLA/91kDTx6dtdDLEd1UKEQbu5XVsOl6h4XdwnaADPEgH0ib/msyjv+o4yndwZtLsMLJLCTBPbNHdsoHCLP1HHgb+6py6+GMjNl0Axjn7YrNACuranGNkAuyHMgZsE59xLfVS8PG8J1lETgnzkNSZw5f6zJPNfwynEGFaTpoG2w5GuRMLaq1GzfZBk6/sMrhELZUBY6K/x2dqU/9eyHQZ+I+x1+M4t6wOr183cVR2h87zl91chZc6f88sKeo4Mto4FNBTe7l0xMffwnyWKkb6X8eo+XVCcsx/aVypJyDZrMPWpKDN/429PN8XlTXkwxxUFaVzBVZt/zvQ/Sk8JiVbgc4bG9mpyL5sJE/DcW7B+mMaVVQfqSW1uBCywbZ4ymwIYIR+CnglSKPLzymI/jORj+blV5YwtYJdSzZf7zRIxQGZjtIBNWAaeYOhpcijX1JSUX5fm/QfoEzSJpuJQVwpqPutZMpl9toEO3GN5/W02bxpLSIVZCiMoz836M5nyppNfSyMMCWhw4EwtWJB4IkEJxM/VCoK4Qpa37GHEvMFqBA42k2zNOPj/rQDC94UOiE/NT9/pUYx41DqtyTpiG+4sM4TPm7BEXLzcSqk/DH4LfCtkhYrczzL+EV/DFc9kUNbcoNmC5dqqSwuGbVfCZJmBcia71SQfZRH78+8WRGUGH6hqkUak84+zgN2pzawmKzR3U4cEOzQ00xLcKfsFuzt3Gd0UTS4AE1PqJ8vWvPkiFsquBJvgJcCkx2/rMTGBF6slrx6jyU2AbYDPDL1d6CDtNZaA1J/4ufmF8jk9vbMM3j6Skj4v/CGhtlIFY74SHzFs6SqCZmiCQb3kvUqOu+4/MOQOjwZosN8ZpQmd0VPEjxsBGPyP1/3WWbMO1zhQ4u6IDTbOeNoFNF2IpH0QFir8q89KpDoYTTQ4r/QbT0Du1HzLq3k8yUKP9IdxNPdAacAlOAk56Qt3e+jTOUeSxhtkhTX84ZfOhL+Oek6ttUEgwS2BtGFLQi0xMZfoz42W+Q4MklXZgdKfAJAosEUDQ/axZqc76WLk9+oZtkOrsP5hkKLyHlFLu9+KDKlnYWU6IHXmTDph+H7NFqFkRaFKpm/qMYIVq3zSZblH6zRSJBnJd3uxNBLRDQ5Y+yXiHS8tfRbknX8RBzBPGjVydvSspPFGs1gf2GbvW3q7CnE/KyL7G/KAncUllUBhXpWD7WdudOMdQUGKArt8DS6+dAISu2IwyN6h+LB9JXN3GBAmYM9tCcgeRMXbsGDpWLsodH5vAr0zCMkbopZv+6G+CBbUcI4IktvhMBkUgQitJaJ9c/3jwOUy0XjPa/hnkkr/b103lCj1F1L06rzIahwRpsuwTBWbzecsYcV7ua6W3uaBFOkC/dk14HYsdnFvDkQMMyEDu5C6nujgiFsNwAdyXCY8xvyRlzXPPLXuzjVpLds82rsRHZqcvd6Uy/MS5FfIup3MV95BGpy1IvJTcXlb7hbkjknxJaI6r0KoDZ0RbfyNVF28ZYCJbSbZMmB89cGWProFn50wufNHhlz1sIZbCQ+ec1CBnNE6ZJD6+u7BA/TtURddrfWn3HhWseagqKWmY/4EqlQXdP25sO762e7oI9jM+5QrKesBfsCOjqRNwNDM+ymQ2zXTvJE+Ff0hy7Ksy4qZr3hOzk1yKH9B02Ow5rdZqWvf1kdfPtnB8JIUckmMiEDVe8m5JnA3g1lbRhLyT8+ke9sOdhmiQNQ1/PKusAq+EySJw40W4dz+R4tDNadXodJ7eWeH3VnZigGoxovjGwMgSh+q4mGQIDc/icsnxDZZikwbH/4yMxwtKtgDDis1/sGHblC4nvkOWie2BRoNmt7tz50kgWXn++nm7QOc5O6Bi4p72FhbnAaLGreAnRh1cm1qSrH5+yoY091HMFvQL2RIJNXcNu5zB5icIKVC/rVj3dixuWf235QqrVGah23bz4QI7q7o0Nfzk6SG8GZQXsg7pgsnJmHvvBUygMEGmzgcEoKLy5PH2aQHul4BYNEgFFZkGw75RFmRnF5v/GNQwJOj/fYBPkPWWFihr0etZ9jj0awXTcnHwFMps/IKF48XLAkXd/HaMUPgaeo6ULuziXAYR6w7fvplZB8BLrTnM0pIcYDO9F1m/9zDfcTHZEX3XUoLXSEEOc02HUDGRLkTDOIIzyfYVKaoRmp3in6dDh55EdM1kqwj1RfDy2s/U+hoUrWkzKLaShAKR3hqddHnfxRk2KOeyiDS03Q+R7b3Xg5cksXIGJ92pu2fqKCIFFMI889/nVLFG47gWNpdETYQCxq93V1iNFQ8xY7d5lC6yGb6q24I2Q480hWyyXwKrQMdazeWO74E+p74MlJZcKDi85B2jIxapcV3YiXGJzu/GgqQTgKqVpkOd4LN6A5QZyOj+0BlWHjdqhwBsgomwHkk5LDx8Udxu+DG/IBPqZHFnq8KeiIA+F25QQPIbjDIVzCyRiJ1/oVQhkbRBdW4xgtbWWjMNwEyy/M3Yzeq1LYqlYY6l0P/Q/o/4RBfc4yjOnGG9zQvmM6QEcYnHKC34i6G6fb9skSTUq7usxrVwGzssiGQSJrO9i07svi/NBPSrmhNueb9VSr+wGWDRk92bHjVRPxG1bRKyNBkeyBDEegsnGGDKpECzqzrlXzgQJ2fxOa/r+Zp/ArX734st/zdwI3qjzGiKHaxouHgJ2CNgwVjAafSx/LMFu6D1+IGYjIZA5raQ+AKkD6TjkTys3Bhvp8wvpZDm63NpR8ltb/BP3+e1RjapsgsL/tQbtA/qdO8DHZ35MRsXHeGByc5pfNcTnL5ZtS6+/nQS7csvhitBJq14BW6Z3q7H6bAYNRxjjMgNER7zPECWQu0mTEhCb3H+2g8V+tZYNZv1VbUHYtm0nLx+wJIwYUAjwzY7AJIIIlybvGoizO7KV0Mjrfg2Y5kDeuFetOTXJf/AkCFs17FNngwuiHgX1JF8lZh7YJGNJkex2KuK47+AEd38aLsLpUr3yZpru52R55gFDLhmwSZZ2bKB0FWywAyBj1qOQXn6gVDocyhuFFYQRYSL+ksQdfqshAb5jt/vIfrUJWQBu+3BU5+LxW7f/1oFoLkhnJi7zPHE0NCdrMCcTocFjPbgOs9LA1SxOSfeyNg/oBNoGpanAInAcvRcXgZH/17gYxgRG9oBxYDlu6hHUwB1lCiTHO6g+dAt3GoVuwP3oUtEV33BHZSekK4YkefULiKX3Ev7sjoOnsySW9iOaDZuvnS7qe2YYvbnLOmPlcqd9dnBBdfnui4SQcfbbuyA1bx89phTGEYf32BiPqhRoc3NYKLHwNH/TV4qd5WKe9jzKSQsXEcu5DIWK7TfwfSwdM3fkHxU94NXkiXkmoQ78XD5C/qTzZnP+0GQfG1q0QEK+/Eyesu2Qsdd7FT+hcvQ9sTGNPHkh+vXEAd0kKnEK/5W4W52Vb/ifAT8oo2ZmxVxNNnqk+GDg53J+knaJtpaIUUgg/zbevgPo727K8KBlY5gRVKuUMfj68Av2zVtm+c5PlrYbLK0ez8wkEvBoXov8Jqr5PjxKwsm7ZFcToHxdheFLS66l4d7RiJBot3EhZ3cBRL1TG+315TFZe+DEv9hPdnyNHWgJuZ8jbuskAp4LXVIc2Cqq2v9QE7XqGqngzp59MEcM2WbiPMm7TB+WK8e3uaaTvGyrQNwMll3N+uXgnvzXs1ORXLdh/fds+7CMhCG3hBGo3W/0f5/LROn24amKsH+MwDmMAxI+WruW1b7GjfPhXNQCDoxsfnsJnf2JHFgIiV4flUoImoEnFKdyXimjzH882Q8QGzKKTSFtSw9jImB7FgESFMZvECHy9oy8Z2I13bte1PKOnY73LFnoJ0LO5nKA5yyyKfGlyKBg1Ih1d/AFhwtf1EVr0eOlI5Oej4O/J1EALFjuMl/OdU98RkWoTH8ppcNgrTzmCdiOW7fSuZYySK5eEP3G9K3XM2sULJpEUvudG89r6azvSScm3XCMtkFIN4fb8jrFI2gT/lRJOP/Z8IBz4BRAWtqidU49Rhgl0YsH9wXkljISIzkXoCsUJJgemHus/kbErSIx0ECmbrbDc3eWUzAAYH84hvN+Yuqmf21OFzHZcNzcMXBmGTfPwcE7qGmLkByk8/hp9rMU6+MzRK591EpLWVdJL2ORVJMrS2S5Et++qbA603I6bRf4wCSLYJY+y7uKpMHFwDiN0BPQrV+jh33dKWQIsZJWpSI9qqnblWpH3b0HO+Cx5w4wh0WTjnbmapwd3E9uehNPE7XWi5i0WkpncQFqkQXzeBWxA/CvAbCXQEQjgDi2mSLGFqu/xWzuMvBShan6n6tqpjAz8LO/A9SX8IbeQRSyhRANLa91v27idc4huzqdaYyZFtxKsAoClmhM967Ov0eHNBTgGP7uYsLuMFuZ3Eg9uIt2o4yasR8Xbt2Tk9fL/gt5X6LEXvVxmDQhVDmsjrjGHzFosAOWoLIfmeY1kQ7zrDO1OPR+wzh0HvGaJMBYAgKcLrRzt9DhMTnniuUcU4OwDAdQHQMN2/6sLzXBHWh43Y/YvjxMb5KmIIn1ItgOOCJUzZDPNFMkFpJEFfEo7ne1T2z0Qor68b8hjj7rj/Vb0ywjhV7REhknZoGa9EG3f505xa4JEUFRfAive2RhjI3JMuyYrlQbx5QPy8Gu5JT33xLVtkE4yj9tmcFt2rvuhtA1e0ozOjlIwiJwx+C+Tj/vKWPUCUNj2lQ57tnghR4FHZOWvuheD5GYKzjBklwP1vQYVq98CvWko+6MoNm9BhI30Cp7fs4pHuT6QjwXgv4YwIM2l5NtZh+N73+4+g/vEFWqvwAC3fhBgcurNMCR7IRzxfX/xvAFxQHQ2wWuThDm15zC16JN2C8qMAqzfrGyV/a/Kk0m+Nay3wHyJBYINwtZ9cXeM2xuBQAqe9+45+H7hnBSRF/VVX1N7Wwzo3OgP3wkdFHaFy+dWb1jy9mW0sgjysQl3uXuW2XsVENQftr7m5fWM8vjyLGnNjGDH871g8Q+kPyufu8X86dbqhRPgdm71kbBeRX/Z1mpMPbhq9aPuUYH3jvyZeNKVW2A9nP9cg1tgj2v8/cTnrYz94xc/pVZopt0FcQmi8Zp03C1ad4gZKeuD5Q0UOcuN/IpZLuQCUylFscGQY2Op3Fd8ITMmxNqva9MuFauAz/02F7eiHnMYX3nJK5HR6CWvqTBOcAV4AaVHmVHH++LonfHm2cvQ0onAEFgPLpAbXKj2eOiMqwgDh4rpnPn4jLw1vfmgVVqdyVXOuXrasM4a5vY+aV6S8FsnEXvj/qrihLlmtxSmxSqnfdUvQ+DOHR4Ek8Ipe5YXmwa0OgyIxirlGPdNpRdQGwd3HC5e2ZBXNrB8YnQxUvFBmN9g/v/OYnAulSFNnLpoXRaNVXI4yKOudAoRuuWqNBQ9fYEJ6pNHDW6aUSnOHE3b2sKykpRESs1nNK+Pv9NTjiqU3CYcj2ZuDE5/xs6scBkmgSEPpXruGBodTEFonbClDGw4x8f30MnMCHXoSgbuDGvC7R/NF0R7G1os168VygR02DX7GWycmqlv6kutayL2SFU4R8AwG/upC8ktFrdeCXIJmNFvTNv1PiMJ2cVfdMaPs3P6AqiYL8t6THBHLoACVamQM75l+XioQWirK/BBP4dN7U+w4a6gH3TM8U333vGLnKZkGqGoFo81VYFfSsaNkFrhXElNMvGJUuGPq/6S2Mb745vPluMugwAKFwWtvrYK3tRUZNHp2Nnq7v9ykUB1cXtc4VBLXaCRuIf/NAbhDqR2KwTSjuRqemfdfOsG6bjua8/ew8NRkMHTWHRBnMfrSyyoNGGpCx6w0KC/0tIW9KYtA+BcCJnypAZIV+51+kMw4/QYPjvVrLy2n4y25N1AmGmXZKMBcDjHf7TfealcgTpEhdj4NNwsox4etMcGliK+Ld11Bp4qWM/BcLkr62YZk/qP6WksFxIycpxvNYDXq3HOcsEZRYv2aLz3QpmCL2CeMr+tDXLegMyuC7DRkNoFlXMq+vdGkbGZgryBYNVNtBCWQfU3yH+riIgyEDuxwkurchs4PM1t0d9O6OGUAOpj3bpH40RbqDzjkCMcu+ZtefDHXUFZ8AWK6qnlsBeEKRUMcBufO4v/xUbmgGRXCq1umVMr+UWIvxzJHL8QZAtLMk1+/gVQWfSue5yPK7CC0J/BPEkUFjj5GLKQvuCcQwSDRZtCEBxD+W6jO4bdyUn+NZzUGxFbZ0JUjfnMLNx2lIX3Df3BnXyD+EmdfyHGdqjT+sPLp8x8lxMTEoXq6VtpvnTcc4ZaMi2tz7FmIg4knAU//SoULwt2nJQubl8+Zgz9jsk4Zn7rTxar7PzQmuK+dP0YUxEatC2OzBOjzF0AjHuE86DF05y4maAYiWqttdAAGh3zgYMZ7iljGH/Lza/J3wPjLvdf7uEYWGidbLB4Tsh241AowGLDwfjjwh78xw/Ut94aqNmB/oAytj6SXMA1hnNV3aF3CC/7IhDXJaxh/tsr+S1BDPq6NEo19zBcAC0yrs5MITZByjjSbUrpLJSuqOZrOYGpq4q2+fEj2s7LftdvAh3hWFeYZ83zqgpOAiExo5xypGvdeOM0BSYzBE1prNvUPzIxRovTo20ihl58dKgcNG+TIXOfvNNLiRsnxXfyhuEDGtHWgk2hSfm5Yaeef2kbHEqK63B3vJDPuau3Ko9l3XFWbCslWeHMu5c0jrED5EOOX45XQdN7nH20zQ7zIfiipIOuHSA/nrqgZcQZKcTipLyoZUIVAghVel3I1tr649s7zrl3A8QzLJfuFn/H56mNGQylplBIE6dIsU+MOqH9D7cJC3LJESlvkmepQyW5yG7xJ6ZAT8o47yuhPpt7Kl1FE92DIZzPjOBf/KiR48+DOMgn9jxJH76fl/mAtY1EOKTOo1E4c5v7ERNovsnTS2Tw8owhLALEvzJaiWh5vkSJ/PZSAixHHZciPXBIWEcrrclXd/kRRB7O3DrZE5QHyL3q1YqziGMDnnrOwA3kwbIleEQRk5+H3FFMKTW+Abt0M49nZTEnjurLBrUi9+IKjtkuf+rhwJqKM4DTcOmF8L5c7fLDUqgwzr2bcWc9M2URGttpwtpI+Z1wKBiJxDpFOlFeT/0QhexbjnpCoAn4oNP2OSMfPCSLIbdd3dhsqI1MW2W0AO3xFwGEKbk5woXSXq5p0vqyuP0B210/bLSTY5EoUR0NdolBGFz4d+O253Szjtq/4y7P5ehcWeTr7DOv8TkdxTjMhveApSLRGSNd4ilRDE51eblHbqk4uJk5LHINr2aQNEiva8AnSHtIlIrkUHOExUVJ3PEPwq+x1pJArbV+Dw5yHrU1P5QGaFKPVBR0J9vyB10Ng0PjGQlFKzvp7CciQYFJVHBuLDzDO9ANDyMKHD6OC5lYjkSFRIi7hsVHCFgdf9Vw+4Os9CTkG6qWALmLQGGIrqzglABW2+swlEvmlFmVIlwW0aZw3U2kHUrgEeMu5CchOohlLzr9PpBi5yhX7Zf0JLAtaUhLYvQ8+8fepA1PZBmTzac80A7KEyKcD3hVCGC+ZnLmr5tlqQx7cJv+/WeZtipd5s72SfRiL0ue+1RUna6HVJEyyNjjJ5yrP2nrlyrNtWz8mZXDmScOFjrBd6a6sotyCtORzwglPdK3nYPzdqeJGZJ7VQXiJlG2LV7dlr653KNh7NSDhELtbQdap7fV1ZH+f1WOm3PUE+ElApZ24OWFyNsRfLWwrJAa9ULCfE0mFFATRYlx1OvYBBucjvLZoiTuxsdqlYFW7frTXUKqhc8sXuTPZPQZywKC/8VvPBEqk9nOHx1DTmTO4Wc4R8i27OF3Ug68uNBn85s4ogb6rjleAi1YpoXw/QZczErpoSX5FV2SHuYLpW2CiYEbcWL7eHxiSKlY2dqEUCGDt5SZo7qP/RYrckHjc7Ep5nPpwxv9RvZd7HU5O+APh6WaYxkxpaUIRHl6amyFauUBsE0MKyZv14M1CV4V0YgcD68GZSunIecVm9J3yrNvqrFrG9tbjhhZxaRmc984iB6YZLJFHHowBqqK7oEI15EWhcBBCryIlr59KR+BWiL9Yp1PUAdZDqzHgLo7gK19uWihjT+Yd7mSlOV1sz1gSDlgOJeKHwBlx3e5B1EappxtKpxpy6qDRayZ/ypJRdotPi41+TxWL+izlU6NYJIgwM0tbL8J33zE2+jIr+73zIqWjXJ2/TU791DTw2fyfM+fTqi04Ps+c0oFINrAVbzmWzi3HJhq9ZnBehPbu6zZRqmasvB4O53J3uPnIyWur3M3HZ3oz1FwND/Da0UDWhnQr8GUwKtdiG4/6wYYdqPZVdcS93peAJzGr1wk4GEAQJ+S7EChNVi/mpjpavYKyGx4qxpklyMhXAdWgIBfWStnvCVqdV1ah3gxYzeW84O9y7IGEEFD3hgoiwoY0zZpeJAscBCW+Vkmlk1U9ZY1R8gTTWR2+98TLvx3Ix5t8e7xe6kS5e8U5O3DaMSDSaj9vUQWD19OjBe/3vLM2aZxC4cioZSC+FKD9inqP2h995e3epxKBi1MokcJnAklmysoczTHaaeFWQzFJKVY2UcII+ly69YVWBGz54I7WtScYCa0LAyrXjxFcWSJktNeGLlTVqJAoB0dFfGynxFvkihcfUq82BviI5LAOUfIZRXigky8ZZyFmYCjjG6CquLHiZscjiU3hU+fQyHIBjI6j5M0ieZ0HgeebogKWfKt2Fv2ktJikZJs5f8xxhBW8xVDmHO4fzbKLzvN5BZ13ENk49uhtpoHcRetSPuwjMUxDSL9qHHQRA+xwJTgR2OiGzUD+KcoelgxUFpkpAodov/rBrncOQpYioHt+nfm1g6lS2V5vzZbrfP+4nIVIrATV6f2DpTq6KDR/lv50PwszESLnH48yemETHM67cCwDAAayFBBZ9dZwVKXJEbRytS1bNAZ+ZxTgdJMECkj2tiDOzCwpksbkNFj45XShjz/ELK34GsC3mIJTuqjVEoTyS72BKbqWxTMkX1RJXzq84nD0T5iQMprfIb0+cj7dmjmQKkC8QXGUOW5UoE2YwA8uJJql+ZWAGTBSl/AfFBmRxHx6g5roOCUoz1cSEYGc3rJGdY7FcbHh9fWFSuv8qyB2G45ZMm3uffXEZIC8L+0ZTBve8J6+qNikMXBHTScHya4KYnqZGQJwdBUhCOqVmob7cRXKX9jUAMUgs3g9AgkKwhVPkd/N+OLki3yGBrr4Pm1GFCKvMlJ/tLHUuLFcDvm9jF/uAqn1obZV7gDNhz9PE18MhJ02lCdkU8RNGE7IVmYkDrhxVTzreJMFlw3wwkqlACpevmtOz3njhfmm9CCArmBWrWsr40Yc6nXQdnTMOu/x514d6jujmB20qeQLZGQa5lMFX1wqtsPg9mpfPkd7iiJmbxHedPxvfNhFb5ou0RDun+dRnhnxIbwgBKafd60SyvbMCTADDJ9LeC27IaeUvnMe1+OFlXiaNxK6qXAW7D4SwpnMbrAmMJFZSfRQHy3xoW/zz0pmZXvT780PrCrG7EvQbmB1Qcfdj96/Zd7GcHX/hg4VK1Fz7z43H2Ka+FuIgoGNaaFqFGhNE+8rIKuOjGwFeAJ20/M31wIdO3edGXgax9lbOBrmM1o0Ej3k9KtXD0DnihjMFHNrCiB5mZ07KVtX9nJ9j4LG+zPOfEVXUrtySlMStcwfMsgQ7kbEtQboUjV/E09Cr/3EThKpZeBfuWBvOzSP5zzrZ/OQhJZ1bfztTibm3Y+2fEPAbFgTr96BwvBw94MRR5ktDo2X/wlJfAp1qVIYLE3FSSeFc0TCxQLj3ViOrjqjb+pamOqEQWOUGj+UFMzb7ieHlQZierQrFuXhjYy+x2viFKlKpJkMZRd4BIHhVOlJzz9ROW7T69XEOZObJH+njr41TzBBH5huGDL0EhbTue3nkpnDi0RlAWIl8QFDFDqG4XIpddkOphMbC7TcDUwj1V0DLyP539ix3/4iLanvazCIjbQdoEy5efJxMI3L0hQMun/45bfn0WMKw5iTBoyFcbYtrGw0xIY1IZPn0/38DrDEC+Atojz1weV4B7Ax/5uKrURnDmyj58xtzUSB0Wc19ZK29fGcOXaTKBu1mtdSQCNPQ3w9Qk2+2SP54M=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZBbRI-vLFGPASeYxh_KgLGJAGhxxxQHaAFUowMEJ38zbzJMIHhOPM0QVtz7ClVSrJw2&amp;t=639202794265548063" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1HoTsDJCIwegf7-cSVNQxKlxqJplUAag2gjZMR_ctGyeKzMDbl61mq8CG1bXK2cKIO5F_d_eACHU7rvEovdRsHjPwMxL_2RbhdHxnXThSzdTd55hY37B50zmwPwIsJ1FnQ2&amp;t=4623e90" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvqBoWBYTDUGuawA_2GYbNQlKfMSt2G6fTRv2v_CvkMQC-NDKOxcBHZBsr4m43UZoWnDElLWlfRSMae7wFN5-j848Bfbquym3Qmm_a4KPTP8MlNJWDtdRKeoXno9ND71Mj-dmT4RATMPqWph8tRm5et41&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OAh7tEdde-lvG3-30egxXz8aAgw_K6hDRuGQnL44pJNvGX0k88IpkhwtBpf_hp5FI_xl-S6IOzDAoSwTftgBkdwIVbozv2itakdYRoj6lyvW2iAmc3lxcxcAsYCLcWBMdMG64QNAlb5JWK1NKm4PkKk1&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=eE6V8nDbUVn0gtG6hKNX_FhBCrEodp5vWm_YmsPN6L6kd8QLjOqCyZgy7R07cf_-q6jt6CUudI9DljzC2TdIySTnrKddg3RKYGaYn4SUdM3lZcSR2HeYBRZYoT1mfgRe0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=mcAASOSteirJeuV-3by3Udl0BXtV-9r3zqXldfMmh4nMyRrfOyOUzm9PjtxhXMnCb3u1w9Bl8xQwuZ3vJQhQk5K_jbJ7TUVZSafdbK767TU1&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=jwf4VSQi7LeShc44FJ-gAeDpDtsq5KMQ8v0UGSwL0n57o9DwezYikDFx_PyigWyXj_0OxQaznPKYQt6DlIveEltbNvWSF7tPucSRMMT0SDIeemWSUwY9H6muRTmCFq5y0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=nai7mGcYyE2dix_TwveLDUh5s-4A2YxYW54tIrkM_TUunAGPTDDQIgTi7_jF0ZDsXQf2DAdig0qNTG97Zho5rt0FlKu4f2urbVFVmxpi95du0q96Rm7avCmT7YWIJACc0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=yDT7ulzE00Yqzs5zd38bJ9uYK0mE0NQaZIaf-pwWkJgWYgpXpMmyr9X13OsEF0tAmtivqF1lykUd9zGXXG_12HtYlW9Y5ThEGbuS1bPsUkjRauDlH9wZ-Gg0tVnmDj270&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=HEFpVKbnoeQjkjHkFKu3MFt9ri5W5MnThyWIA17NLksVbAMJb3b4J6FUWFjTqfhe62vQzBBryc0D7vtVE9sCvRaBkQXkkFQdNC1ak54UhzYYY35kSK400VtcrgLyqWDD0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=5ib3lCcyinHeLQmkwMF7EsGoPbLcoTPc-cgtukLJYPUZaLkkgAnENQdSi8NDc4l_BKxYZA1H9k0706BHQRpedGJsNRjKTrwz8gPmzzA-oap0ysiJ6VwrD01uCYx37kM30&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=iON9Jxe8QCRam1nkdNLgkffrRZCMCj6iq7qHWPZc_e3jKeMk_XnmxshFxNhoGH9SwE5Oz8w4xs83YnQN2PvBuUDeB4qmPOBf6C6AjLMoHrEWhVT0hkNgKR3X5v1OCzxI0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=xGmPTKfsNy0_1Sr5I58kO5DASLN2udyuv-7sLUq5_rfvt0h0nqG8q3lnLwCBbElWqxPrkky3q5vq3pg0VXsmEcTWWXMOeG7FgMUlD16VLKssIvRudHPE5Dua6R6EOhY40&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=LQ1q2RBSthBAZhliMjtG_6LMhlQH2DbcQYgRKlCVjFIh5IZ7GFZUyt66Y_m4cqI1Qb8Rf2oM6HCIJJLQ9rSBDT1GrsRxo5ZypZQOZ1maIbKPmaC4yLryG1OCPsyASQdm0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=VOYD8Xe7kQA0lniBYXVpAuKo3oFKAyHWpDt0JH4amXNlZ9J7vLHsxoqoc15eTAjA6oglPYd0zwAK4QpQdtZv0jvkOUq5Z5is2nQki9YITO0skfivF47CJZD_3wdgAEY50&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=hOeJu0xhC-uW6Gf8ooKdXldiqMjTwkMrPiRL7tfxCMAYgx7LQGO2FKVjBYyeRQsczHJO8YrvOhmAf48uwtZEnO4Mu9oj9tlaZBV6uinaXInS4irYgdmuHH1_fMK8aVI10&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=XlV9GqTk6b5uqDuL38kZ4M4-D19lMtmt0Nfm-OaIfmfKZXxxdkEy0_fz8Rb50xJiOME7ruSlDELDwr_q88n93Z8DbpgP-PrvolSTi43wrxjzmVSKMK-250V1wOfusJzQ0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/WebResource.axd?d=JoBkLzP19aTuxbWOhHobYndLm8rB8C7w5JAGcozHelAi0yxlDEHXqwBJPZODPDVe3kynVZnW81KTBhLcr2IKvw2&amp;t=639202794265548063" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="570DA575" />
	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0" />
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="pxiWaMuELDAMsw6/S4kIrXPk/rXj0H07o3peZVmybo1bbHzmQxkHdYMH2DvUHLSTJgz9lEFFaLaprdad5ATK8+E+YnYiqpzfxLi8Ip34Uui5uBsaBG0TlabpxfMwBLdHG9n4jH7+M7E8/l/TMZemFkJEFuTny1BTwTeG0oKxJvDckZegHyi8ztomLO0JILcRhYW5xarloSetEr8r/0mWMy9xx231i92eMT5otQtg3kJLVh1eUrjHL94HNWpuulp6Eigr37yjbo1SVRBgS5vkdC7daFXIkcMCthAQkQdHUAvWemiuyQfjwDUiaz+vDxWo5R+iEvTbahIHAtfd56JWNzfIs6Z0hYg+5hIEPYwfZCLoP+l6c/pgTC0o4D5uGEt0UF8teVeOCcD6UBhwzyYiAWk+qCDNxv8Xfl04pnKXb2ThN/ob9ZELQv4eplgQeKMW3WzvMF/sNoxt++PlxC8CTP+x0066/1akgRSOnwYCt8tHafsX3xzSLZMKm1L36U9tRrAU4GLdbzBi+vSHwZTcBoIVEFgAb5NE9/um6Nn1lq5MffbXimHbuxqFKW9acwSukU1GgJWfP4TS0SbOsjqAa/c4j25b3HbRGGtbroNRh2vFnCD/jRzHZ0KckStsAJqHAZ5wFjkBtjN1J5CHcbQCwF2hQ38/ahHwOnZjl816IlNyEbo5+66G6IXL72yRsQ1d1TwEx9FBeQZVIx3YpmqcxtiKys803JpBExERvkzag2XofEGhhEay80QS/YeBQVeuaNtenPIpZj2YA/IBD5nbtjPIJpFaVv0keWUxyzmer1rgjdUgxRaTpVvppt/U+qwCf6vDeap+jOtGkop7eBOEybCDRiw9ert8esLDs9wyhSlNAwRcj+fdFUZZJczBYI1Mz9tO1FIbjQvC3eKC8DTrNOqq1WO7p9WRLMc/4E23PaI=" />
</div>
           
        <div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', ['tctl00$SelectRegion$updChangeRegion','SelectRegion_updChangeRegion','tctl00$UpdRegion','UpdRegion','tctl00$ContentPlaceHolder1$UpdatePanel111','ContentPlaceHolder1_UpdatePanel111','tctl00$ContentPlaceHolder1$updtApplicant','ContentPlaceHolder1_updtApplicant','tctl00$ContentPlaceHolder1$updtForm','ContentPlaceHolder1_updtForm'], ['ctl00$ContentPlaceHolder1$btnGetOtp','ContentPlaceHolder1_btnGetOtp','ctl00$ContentPlaceHolder1$btnOTPVerify','ContentPlaceHolder1_btnOTPVerify'], [], 600, 'ctl00');
//]]>
</script>

            <button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-topD">
                <i class="fas fa-arrow-up"></i>
</button>
<!-- Simple splash screen-->
<div class="splash">
 <div class="color-line"></div>
 <div class="splash-title">
 <h1>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h1>
 <p>ਕਿਰਪਾ ਕਰਕੇ ਉਡੀਕ ਕਰੋ ਜਦੋਂ ਤੱਕ ਅਸੀਂ ਤੁਹਾਡੇ ਲਈ ਖੋਜ ਮੋਡੀਊਲ ਨੂੰ ਸੈਟਅਪ ਕਰਦੇ ਹਾਂ./Please wait while we setup the search module for you. </p>
 <img src="ui-assets/images/loading-bars.svg" width="64" height="64" alt="Loading.."/>
  </div>
   </div>
		<div id="updWebsite" style="display:none;">
	
				<div class="loadingContainer">
					<div class="loading">
						<img src="ui-assets/images/loading-bars.svg" alt="Loading.." width="64" height="64" />
						&nbsp;
					&nbsp;
					</div>
				</div>
			
</div>
<!-- Header -->
	
        
        <div id="header">
            <div id="plrs-header">
                 
    <div class="plrs-header-row">
     
        <!-- LOGO -->
        <div class="plrs-left">
        <div class="plrs-logo">
            <img src="ui-assets/images/logo.png" alt="Punjab Land Records" />
            <div class="plrs-logo-text">
                ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼
                <span>Punjab Land Records</span>
            </div>
        </div>
        <div class="plrs-menu header-link hide-menu"><i class="fa fa-bars"></i></div>
            </div>
        <!-- REGION -->
        <div class="plrs-region">
               
             

<div id="dvChangeRegion" class="modal fade">

	<div class="modal-dialog modal-lg" style="min-width:80%">
		<div class="modal-content">

			<div id="SelectRegion_updChangeRegion">
	

					<div class="modal-body">
						<div class="row">
                            <div class="col-md-12 m-t-sm">
                                <fieldset id="SelectRegion_fsSelectRegion" class="form_ font-resize-scope">
										<legend id="SelectRegion_lgSelectRegion" class="lg p-sm head-legend">
											<i class="fa fa-map-marker"></i>
											<span id="SelectRegion_lbllgRegionInfo">ਖੇਤਰ ਚੁਣੋ/Select the Region</span>
										</legend>
							   <div class="dvSelectRegion m-t-sm m-b-sm">
                                   <div class="row form-group">
                                                    <div class="col-md-12" >
                                                		<span id="SelectRegion_Label2" class="label label-lg-font-size">ਜਮਬੰਦੀ ਪੀਰੀਅਡ/Jamabandi Period</span>
														<table id="SelectRegion_rdPeriod" class="form-control smedium m-t-sm">
		<tr>
			<td><span class="radiobtn"><input id="SelectRegion_rdPeriod_0" type="radio" name="ctl00$SelectRegion$rdPeriod" value="1" checked="checked" tabindex="1" /><label for="SelectRegion_rdPeriod_0">ਮੌਜੂਦਾ/Current</label></span></td><td><span class="radiobtn"><input id="SelectRegion_rdPeriod_1" type="radio" name="ctl00$SelectRegion$rdPeriod" value="2" onclick="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$rdPeriod$1\&#39;,\&#39;\&#39;)&#39;, 0)" tabindex="1" /><label for="SelectRegion_rdPeriod_1">ਪਿਛਲਾ/Previous</label></span></td>
		</tr>
	</table>
                                                        </div>
                                                </div>
                                <div class="row form-group">
								    <div class="col-sm-3 district-dropdown" style="position:relative; z-index:9">
									    <span id="SelectRegion_lblddlDistrict" class="label  label-lg-font-size">ਜ਼ਿਲ੍ਹਾ/District</span>
									    <select name="ctl00$SelectRegion$ddlDistrict" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlDistrict\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlDistrict" tabindex="2" class="form-control">
		<option selected="selected" value="">ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Choose District</option>
		<option value="7">ਅੰਮ੍ਰਿਤਸਰ/Amritsar</option>
		<option value="8">ਬਰਨਾਲਾ/Barnala</option>
		<option value="9">ਬਠਿੰਡਾ/Bathinda</option>
		<option value="10">ਫਰੀਦਕੋਟ/Faridkot</option>
		<option value="11">ਫਤਿਹਗੜ੍ਹ ਸਾਹਿਬ/Fatehgarh Sahib</option>
		<option value="12">ਫ਼ਾਜ਼ਿਲਕਾ/Fazilka</option>
		<option value="13">ਫਿਰੋਜਪੁਰ/Ferozepur</option>
		<option value="14">ਗੁਰਦਾਸਪੁਰ/Gurdaspur</option>
		<option value="15">ਹੁਸ਼ਿਆਰਪੁਰ/Hoshiarpur</option>
		<option value="16">ਜਲੰਧਰ/Jalandhar</option>
		<option value="17">ਕਪੂਰਥਲਾ/Kapurthala</option>
		<option value="18">ਲੁਧਿਆਣਾ/Ludhiana</option>
		<option value="18953">ਮਲੇਰਕੋਟਲਾ/Malerkotla</option>
		<option value="19">ਮਾਨਸਾ/Mansa</option>
		<option value="20">ਮੋਗਾ/Moga</option>
		<option value="21">ਪਠਾਨਕੋਟ/Pathankot</option>
		<option value="22">ਪਟਿਆਲਾ/Patiala</option>
		<option value="23">ਰੂਪਨਗਰ/Rupnagar</option>
		<option value="24">ਐਸ. ਏ. ਐਸ ਨਗਰ/S.A.S. Nagar</option>
		<option value="25">ਸੰਗਰੂਰ/Sangrur</option>
		<option value="26">ਸ਼ਹੀਦ ਭਗਤ ਸਿੰਘ ਨਗਰ (ਨਵਾਂਸ਼ਹਿਰ)/Shahid Bhagat Singh Nagar(Nawanshahr)</option>
		<option value="27">ਸ਼੍ਰੀ ਮੁਕੱਤਸਰ ਸਾਹਿਬ/Sri Muktsar Sahib</option>
		<option value="28">ਤਰਨ ਤਾਰਨ/Tarn Taran</option>

	</select>
                                        <span id="SelectRegion_RFVDistrict" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District</span>
								    </div>
                                    <div class="col-sm-3 m-b-md tehsil-dropdown" style="position:relative; z-index:8">
									    <span id="SelectRegion_lblddlTehsil" class="label label-lg-font-size">ਤਹਿਸੀਲ/Tehsil</span>
									    <select name="ctl00$SelectRegion$ddlTehsil" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlTehsil\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlTehsil" disabled="disabled" tabindex="3" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਤਹਿਸੀਲ ਚੁਣੋ/Choose Tehsil</option>

	</select>
                                        <span id="SelectRegion_RFVTehsil" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil</span>
								    </div>
                                    <div class="col-sm-3 village-dropdown" style="position:relative; z-index:7">
									    <span id="SelectRegion_lblddlVillage" class="label label-lg-font-size">ਪਿੰਡ/Village</span>
									    <select name="ctl00$SelectRegion$ddlVillage" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlVillage\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlVillage" disabled="disabled" tabindex="4" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਪਿੰਡ ਚੁਣੋ/Choose Village</option>

	</select>
                                        <span id="SelectRegion_RFVVillage" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village</span>
								    </div>
                                    <div class="col-sm-3 m-b-md year-dropdown" style="position:relative; z-index:6">
									    <span id="SelectRegion_lblddlYear" class="label label-lg-font-size">ਸਾਲ/Year</span>
									    <select name="ctl00$SelectRegion$ddlYear" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlYear\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlYear" disabled="disabled" tabindex="5" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਸਾਲ ਚੁਣੋ/Choose Year</option>

	</select>
                                        <span id="SelectRegion_RFVYear" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year</span>
								    </div>
                                </div>
							</div>
                                    </fieldset>
                            </div>

						</div>
					</div>
					<div class="modal-footer">
						<!-- Submit Button-->
						<input type="submit" name="ctl00$SelectRegion$btnSearch" value="ਖੇਤਰ ਬਦਲੋ/Change Region" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$SelectRegion$btnSearch&quot;, &quot;&quot;, true, &quot;ChangeRegion&quot;, &quot;&quot;, false, false))" id="SelectRegion_btnSearch" tabindex="6" class="btn btn-pimary submit-custom-btn" />
						<button id="SelectRegion_btnCancel" class="btn btn-danger btn-no" data-dismiss="modal" TabIndex="7">ਰੱਦ ਕਰੋ/Cancel</button>
					</div>
				
</div>
			
			

		</div>
	</div>
</div>

            <div id="UpdRegion">
	
                    







                
</div>
        </div>

        <!-- ACTIONS -->
        <div class="plrs-actions">
            <div class="plrs-font">
                 <input type="button" id="btnincreasefonts"  value=" A+ " />
                 <input type="button" id="btndecreasefonts"  value=" A- " />
                 <input type="button" id="btnresetfonts" value=" A= " />
            </div>

            <a href="Login.aspx" class="plrs-login">
                <i class="fa fa-lock"></i>
                Official Login
            </a>
        </div>

    </div>
            
</div>

</div>


        <div id="divBackground" class="modal"></div>
		
        
<link href="../ui-assets/Pgstyles/uc_navugatonmenu.css" rel="stylesheet" />
<!-- Navigation -->
<aside id="menu">
	<div id="navigation">
		<nav class="nav-primary">
			<ul class="nav">
				
				
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl00_liItem">
							<a href="Default.aspx?itemPID=1">
								    
                                    <i class='fa-solid fa-house'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl00_bBG" class="bg-info"></b>
								</i>
								
								<span>ਮੁੱਖ ਪੰਨਾ/Home</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl01_liItem">
							<a href="OnlineRequestStatus.aspx?itemPID=77">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl01_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਟਰੈਕ ਐਪਲੀਕੇਸ਼ਨ/Track Application</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_liItem">
							<a href="./?itemPID=82">
								    
                                    <i class='fa-solid fa-file-export'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl02_bBG" class="bg-primary2"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl02_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਸ਼ਿਕਾਇਤ ਨਿਵਾਰਨ/Grievance Redressal</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl02_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Grievance.aspx?RefNo=1&itemID=83&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦਾਖਲ ਕਰੋ/Submit Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_liItem">
											<a href="GrievanceTrack.aspx?RefNo=2&itemID=84&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦੀ ਜਾਂਚ ਕਰੋ/Track Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_liItem">
							<a href="Jamabandi.aspx?itemPID=3">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl03_bBG" class="bg-success"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl03_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਜਮ੍ਹਾਂਬੰਦੀ ਵੇਖੋ/View Jamabandi</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl03_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Jamabandi.aspx?section=Owner-Name-Wise&itemID=7&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਮਾਲਕ ਦੇ ਨਾਮ ਮੁਤਾਬਕ/Owner Name Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Jamabandi.aspx?section=Khewat-Number-Wise&itemID=8&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖੇਵਟ ਨੰ: ਮੁਤਾਬਕ/Khewat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_liItem">
											<a href="Jamabandi.aspx?section=Khasra-Number-Wise&itemID=9&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਸਰਾ ਨੰ: ਮੁਤਾਬਕ/Khasra No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_liItem">
											<a href="Jamabandi.aspx?section=Khatouni-Number-Wise&itemID=10&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਤੌਨੀ ਨੰ: ਮੁਤਾਬਕ/Khatouni No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_liItem">
							<a href="Mutation.aspx?itemPID=4">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl04_bBG" class="bg-danger"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl04_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਇੰਤਕਾਲ ਵੇਖੋ/View Mutation</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl04_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Mutation.aspx?section=Mutation-Number-Wise&itemID=13&itemPID=4">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਇੰਤਕਾਲ ਨੰ: ਮੁਤਾਬਕ/Mutation No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_liItem">
							<a href="Roznamcha.aspx?itemPID=5">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl05_bBG" class="bg-info"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl05_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਰੋਜਨਾਮਚਾ ਵੇਖੋ/View Roznamcha</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl05_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Roznamcha.aspx?section=Rapat-Number-Wise&itemID=11&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਰਿਪੋਰਟ ਨੰਬਰ ਮੁਤਾਬਕ/Rapat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Roznamcha.aspx?section=Waqiati-Number-Wise&itemID=12&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਵਾਕਿਆਤੀ ਮੁਤਾਬਕ/Waqiati No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl06_liItem">
							<a href="RegistryDeed.aspx?itemPID=21">
								    
                                    <i class='fa-regular fa-copy'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl06_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਰਜਿਸਟਰਡ ਡੀਡ ਵੇਖੋ/View Registered Deed</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl07_liItem">
							<a href="FardStatus.aspx?itemPID=29">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl07_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਫਰਦ ਬੇਨਤੀ ਸਥਿਤੀ/Fard Request Status</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl08_liItem">
							<a href="GroundTruthingDataMap2.aspx?itemPID=85">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl08_bBG" class="bg-success"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-2 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-2 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl09_liItem">
							<a href="GroundTruthingDataMap3.aspx?itemPID=86">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl09_bBG" class="bg-danger"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-3 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-3 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl10_liItem">
							<a href="IPWTD.aspx?itemPID=15">
								    
                                    <i class='fa fa-university'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl10_bBG" class="bg-info"></b>
								</i>
								
								<span>ਇਨਟੈਗਰੇਟਿਡ ਜਾਇਦਾਦ/Integrated Property</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl11_liItem">
							<a href="faq.aspx?itemPID=33">
								    
                                    <i class='fa fa-question-circle'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl11_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਐੱਫ ਏ ਕਿਊ/FAQ</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl12_liItem">
							<a href="UserManual.aspx?itemPID=35">
								    
                                    <i class='fa fa-user'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl12_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਉਪਯੋਗ ਪੁਸਤਕ/User Manual</span>
                                 
							</a>
							
							
							
                            
						</li>
					
                				
			</ul>
		</nav>
	</div>
</aside>


	    
		<div id="wrapper" >
            <div class="page-body">
                <div class="normalheader transition animated fadeIn small-header hide-mob hidden-xs hidden-sm">
				<div class="hpanel">
					<div class="panel-body">
						<div class="row">
							<div class="col-sm-12">
                                <div class="nav-pills bg-light breadcrumbs">
                                    <span id="SiteMapPath1"><a href="#SiteMapPath1_SkipLink" style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;">Skip Navigation Links</a><span><a href="/Default.aspx">ਔਨਲਾਈਨ ਸੇਵਾਵਾਂ/Online Services</a></span><span> &gt; </span><span>ਵਿਰਾਸਤ ਮਿਊਟੇਸ਼ਨ ਦੀ ਬੇਨਤੀ/Request For Virasat Mutation</span><a id="SiteMapPath1_SkipLink"></a></span>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>

		<div class="content animate-panel">
            
    <div id="ContentPlaceHolder1_UpdatePanel111">
	
            <input type="hidden" name="ctl00$ContentPlaceHolder1$hiddenFocusTarget" id="ContentPlaceHolder1_hiddenFocusTarget" />
            <input type="submit" name="ctl00$ContentPlaceHolder1$btnShowPopup" value="" id="ContentPlaceHolder1_btnShowPopup" style="display: none" />
            <div class="content transition animated fadeIn">
                <div class="panel hpanel dblue">
                    <div class="panel-heading">
                        <div class="form-horizontal text-center ">
                            <h3 class="font-resize-heading"><b>ਵਿਰਾਸਤ ਦੇ ਆਧਾਰ ਤੇ ਇੰਤਕਾਲ ਲਈ ਬੇਨਤੀ<br />
                                Request for Mutation on the basis of Inheritance</b></h3>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="form-horizontal">



                            

                            <fieldset id="ContentPlaceHolder1_FieldsetApplicantDetail" class="form_ font-resize-scope" style="background-color: white">
                                <legend id="ContentPlaceHolder1_legendApplication" class="lg p-sm text-left head-legend">
                                    <i class="fa fa-info-circle hidden"></i>
                                    <span id="ContentPlaceHolder1_lblApplicantDetailH2">1. ਬਿਨੈਕਾਰ ਦਾ ਵੇਰਵਾ/Details of Applicant</span>
                                </legend>
                                <div id="ContentPlaceHolder1_updtApplicant">
		


                                        <div id="ContentPlaceHolder1_pnlApplicantInfo">
			
                                            <div class="row form-group">
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਨਾਮ/Name of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Name</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtName" type="text" maxlength="200" id="ContentPlaceHolder1_txtName" tabindex="1" class="form-control label-lg-font-size" />

                                                </div>
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblFatherNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦੇ ਪਿਤਾ ਜੀ ਦਾ ਨਾਮName of Father of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVFatherName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Father Name</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtFatherName" type="text" maxlength="200" id="ContentPlaceHolder1_txtFatherName" tabindex="2" class="form-control label-lg-font-size" />

                                                </div>


                                                <div class="col-sm-4 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblMobileNumberH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਮੋਬਾਈਲ ਨੰ./Mobile No. of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Mobile number</span>
                                                    <span id="ContentPlaceHolder1_REVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter a valid 10-digit mobile number.</span>
                                                    <input name="ctl00$ContentPlaceHolder1$txtMobileNumber" type="text" maxlength="10" id="ContentPlaceHolder1_txtMobileNumber" tabindex="3" class="form-control label-lg-font-size" />


                                                </div>

                                                <div id="ContentPlaceHolder1_pnlOTP">
				
                                                    <div class="col-sm-2 m-t-sm" style="margin-top: 30px">

                                                        
                                                        <a id="ContentPlaceHolder1_btnGetOtp" tabindex="4" class="btn btn-primary" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ContentPlaceHolder1$btnGetOtp&quot;, &quot;&quot;, true, &quot;GrpRequestotp&quot;, &quot;&quot;, false, true))">
                                                         <i class="fas fa-mobile"></i> ਓਟੀਪੀ ਭੇਜੋ/Send OTP
                                                        </a>

                                                    </div>
                                                    <div class="col-sm-2 m-t-sm">
                                                        
                                                    </div>
                                                    <div class="col-sm-2 m-t-sm">
                                                        <span id="ContentPlaceHolder1_lblVerifyOTP" class="label-lg-font-size">ਓ ਟੀ ਪੀ/OTP<span class="text-danger">*</span>
											        </span>

                                                        <span id="ContentPlaceHolder1_RequiredFieldValidator2" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the OTP number</span>
                                                        <input name="ctl00$ContentPlaceHolder1$txtOTP" type="text" maxlength="10" id="ContentPlaceHolder1_txtOTP" tabindex="5" class="form-control label-lg-font-size" />
                                                    </div>
                                                    <div class="col-sm-2 m-t-sm" style="margin-top: 30px">
                                                        
                                                        

                                                        <a id="ContentPlaceHolder1_btnOTPVerify" tabindex="6" class="aspNetDisabled btn btn-primary">
                                                         <i class="fas fa-check-circle"></i>ਓਟੀਪੀ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ/Verify OTP

                                                        </a>

                                                    </div>
                                                
			</div>
                                            </div>
                                        
		</div>
                                    
	</div>
                            </fieldset>
                            <div id="ContentPlaceHolder1_updtForm">
		
                                    
                                    
                                
	</div>
                            
                            
                            
                            
                            
                            



                            <div id="ContentPlaceHolder1_pnlmsgConfirm" class="sweet-modal" style="display: none;">
		
                                <div class="sweet-modal-header">
                                    Alert
                                </div>
                                <div class="sweet-modal-body">
                                    
                                </div>
                                <div class="sweet-modal-footer">
                                    <input type="submit" name="ctl00$ContentPlaceHolder1$btnOK" value="OK" id="ContentPlaceHolder1_btnOK" class="btn" />
                                </div>
                            
	</div>
                            


                            
                        </div>
                    </div>
                </div>
            </div>

        
</div>


            
			
			
			
			
			
			
		</div>

    </div>
    <!-- Footer-->
    <footer class="footer footer-font">

    <!-- Govt -->
    <div class="digi-topBoderThickDis">
        <div class="container-fluid text-center">
            <span>ਮਾਲ, ਮੁੜ ਵਸੇਬਾ ਅਤੇ ਆਪਦਾ ਪ੍ਰਬੰਧਨ ਵਿਭਾਗ,ਪੰਜਾਬ ਸਰਕਾਰ, ਭਾਰਤ / Department of Revenue, Rehabilitation and Disaster Management, Government of Punjab, India.
            </span>
        </div>
    </div>

    <!-- Copyright -->
    <div class="digi-topBoder">
        <div class="container-fluid text-center">
            <span>ਕਾਪੀਰਾਈਟ © 2025 ਪੰਜਾਬ। ਸਾਰੇ ਹੱਕ ਰਾਖਵੇਂ ਹਨ। / Copyright © 2025  Punjab. All rights reserved.
            </span>
        </div>
    </div>

    <!-- Stats -->
    <div class="digi-topBottomBoder footer-stats">
        <div class="container-fluid">
            <div class="footer-stats-row">
                <span class="badge-pill">
                    ਕੁੱਲ ਵਿਜ਼ਿਟਰ/Total Visitors :
                    <span id="lblv">2380020</span>
                </span>

                <span class="badge-pill">
                    ਆਖਰੀ ਵਾਰ ਅੱਪਡੇਟ ਕੀਤਾ/Last Updated :
                    <span id="lblud">12/10/2026</span>
                </span>
            </div>
        </div>
    </div>

</footer>

</div>	          
    <script src="ui-assets/vendor/bootstrap/dist/js/bootstrap.min.js" nonce="WkJ+eIw8/3K8i6BTDgyNiA"></script>
	<script src="ui-assets/vendor/datatables_with_buttons/datatables.min.js" nonce="WkJ+eIw8/3K8i6BTDgyNiA"></script>
	<script src="ui-assets/vendor/virtual-keyboard/js/keyboard.js" type="text/javascript" nonce="WkJ+eIw8/3K8i6BTDgyNiA"></script>
 <!-- App scripts -->
    <script src="ui-assets/scripts/homer.js" nonce="WkJ+eIw8/3K8i6BTDgyNiA"></script>
    <script src="ui-assets/Pgscript/masterpg.js" nonce="WkJ+eIw8/3K8i6BTDgyNiA"></script>
    <script src="ui-assets/scripts/select2.min.js" nonce="WkJ+eIw8/3K8i6BTDgyNiA" > </script>
    <script src="ui-assets/scripts/BackToTopN.js" nonce="WkJ+eIw8/3K8i6BTDgyNiA" > </script>              
</div>

<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("SelectRegion_RFVDistrict"), document.getElementById("SelectRegion_RFVTehsil"), document.getElementById("SelectRegion_RFVVillage"), document.getElementById("SelectRegion_RFVYear"), document.getElementById("ContentPlaceHolder1_RFVName"), document.getElementById("ContentPlaceHolder1_RFVFatherName"), document.getElementById("ContentPlaceHolder1_RFVMobileNumber"), document.getElementById("ContentPlaceHolder1_REVMobileNumber"), document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var SelectRegion_RFVDistrict = document.all ? document.all["SelectRegion_RFVDistrict"] : document.getElementById("SelectRegion_RFVDistrict");
SelectRegion_RFVDistrict.controltovalidate = "SelectRegion_ddlDistrict";
SelectRegion_RFVDistrict.focusOnError = "t";
SelectRegion_RFVDistrict.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District";
SelectRegion_RFVDistrict.display = "Dynamic";
SelectRegion_RFVDistrict.validationGroup = "ChangeRegion";
SelectRegion_RFVDistrict.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVDistrict.initialvalue = "";
var SelectRegion_RFVTehsil = document.all ? document.all["SelectRegion_RFVTehsil"] : document.getElementById("SelectRegion_RFVTehsil");
SelectRegion_RFVTehsil.controltovalidate = "SelectRegion_ddlTehsil";
SelectRegion_RFVTehsil.focusOnError = "t";
SelectRegion_RFVTehsil.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil";
SelectRegion_RFVTehsil.display = "Dynamic";
SelectRegion_RFVTehsil.validationGroup = "ChangeRegion";
SelectRegion_RFVTehsil.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVTehsil.initialvalue = "";
var SelectRegion_RFVVillage = document.all ? document.all["SelectRegion_RFVVillage"] : document.getElementById("SelectRegion_RFVVillage");
SelectRegion_RFVVillage.controltovalidate = "SelectRegion_ddlVillage";
SelectRegion_RFVVillage.focusOnError = "t";
SelectRegion_RFVVillage.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village";
SelectRegion_RFVVillage.display = "Dynamic";
SelectRegion_RFVVillage.validationGroup = "ChangeRegion";
SelectRegion_RFVVillage.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVVillage.initialvalue = "";
var SelectRegion_RFVYear = document.all ? document.all["SelectRegion_RFVYear"] : document.getElementById("SelectRegion_RFVYear");
SelectRegion_RFVYear.controltovalidate = "SelectRegion_ddlYear";
SelectRegion_RFVYear.focusOnError = "t";
SelectRegion_RFVYear.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year";
SelectRegion_RFVYear.display = "Dynamic";
SelectRegion_RFVYear.validationGroup = "ChangeRegion";
SelectRegion_RFVYear.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVYear.initialvalue = "";
var ContentPlaceHolder1_RFVName = document.all ? document.all["ContentPlaceHolder1_RFVName"] : document.getElementById("ContentPlaceHolder1_RFVName");
ContentPlaceHolder1_RFVName.controltovalidate = "ContentPlaceHolder1_txtName";
ContentPlaceHolder1_RFVName.focusOnError = "t";
ContentPlaceHolder1_RFVName.errormessage = "Please enter the Name";
ContentPlaceHolder1_RFVName.display = "Dynamic";
ContentPlaceHolder1_RFVName.validationGroup = "GrpRequest";
ContentPlaceHolder1_RFVName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVName.initialvalue = "";
var ContentPlaceHolder1_RFVFatherName = document.all ? document.all["ContentPlaceHolder1_RFVFatherName"] : document.getElementById("ContentPlaceHolder1_RFVFatherName");
ContentPlaceHolder1_RFVFatherName.controltovalidate = "ContentPlaceHolder1_txtFatherName";
ContentPlaceHolder1_RFVFatherName.focusOnError = "t";
ContentPlaceHolder1_RFVFatherName.errormessage = "Please enter the Father Name";
ContentPlaceHolder1_RFVFatherName.display = "Dynamic";
ContentPlaceHolder1_RFVFatherName.validationGroup = "GrpReques";
ContentPlaceHolder1_RFVFatherName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVFatherName.initialvalue = "";
var ContentPlaceHolder1_RFVMobileNumber = document.all ? document.all["ContentPlaceHolder1_RFVMobileNumber"] : document.getElementById("ContentPlaceHolder1_RFVMobileNumber");
ContentPlaceHolder1_RFVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
ContentPlaceHolder1_RFVMobileNumber.focusOnError = "t";
ContentPlaceHolder1_RFVMobileNumber.errormessage = "Please enter the Mobile number";
ContentPlaceHolder1_RFVMobileNumber.display = "Dynamic";
ContentPlaceHolder1_RFVMobileNumber.validationGroup = "GrpRequestotp";
ContentPlaceHolder1_RFVMobileNumber.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVMobileNumber.initialvalue = "";
var ContentPlaceHolder1_REVMobileNumber = document.all ? document.all["ContentPlaceHolder1_REVMobileNumber"] : document.getElementById("ContentPlaceHolder1_REVMobileNumber");
ContentPlaceHolder1_REVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
ContentPlaceHolder1_REVMobileNumber.focusOnError = "t";
ContentPlaceHolder1_REVMobileNumber.errormessage = "Please enter a valid 10-digit mobile number.";
ContentPlaceHolder1_REVMobileNumber.display = "Dynamic";
ContentPlaceHolder1_REVMobileNumber.validationGroup = "GrpRequestotp";
ContentPlaceHolder1_REVMobileNumber.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ContentPlaceHolder1_REVMobileNumber.validationexpression = "^[6-9]\\d{9}$";
var ContentPlaceHolder1_RequiredFieldValidator2 = document.all ? document.all["ContentPlaceHolder1_RequiredFieldValidator2"] : document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2");
ContentPlaceHolder1_RequiredFieldValidator2.controltovalidate = "ContentPlaceHolder1_txtOTP";
ContentPlaceHolder1_RequiredFieldValidator2.focusOnError = "t";
ContentPlaceHolder1_RequiredFieldValidator2.errormessage = "Please enter the OTP number";
ContentPlaceHolder1_RequiredFieldValidator2.display = "Dynamic";
ContentPlaceHolder1_RequiredFieldValidator2.validationGroup = "GrpRequestVOTP";
ContentPlaceHolder1_RequiredFieldValidator2.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RequiredFieldValidator2.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        
theForm.oldSubmit = theForm.submit;
theForm.submit = WebForm_SaveScrollPositionSubmit;

theForm.oldOnSubmit = theForm.onsubmit;
theForm.onsubmit = WebForm_SaveScrollPositionOnSubmit;
WebForm_AutoFocus('ContentPlaceHolder1_txtName');Sys.Application.add_init(function() {
    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":500,"dynamicLayout":true}, null, null, $get("updWebsite"));
});

document.getElementById('SelectRegion_RFVDistrict').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVDistrict'));
}

document.getElementById('SelectRegion_RFVTehsil').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVTehsil'));
}

document.getElementById('SelectRegion_RFVVillage').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVVillage'));
}

document.getElementById('SelectRegion_RFVYear').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVYear'));
}

document.getElementById('ContentPlaceHolder1_RFVName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVName'));
}

document.getElementById('ContentPlaceHolder1_RFVFatherName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVFatherName'));
}

document.getElementById('ContentPlaceHolder1_RFVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVMobileNumber'));
}

document.getElementById('ContentPlaceHolder1_REVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_REVMobileNumber'));
}

document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2'));
}
Sys.Application.add_init(function() {
    $create(Sys.Extended.UI.ModalPopupBehavior, {"backgroundCssClass":"modalBackground","cancelControlID":"ContentPlaceHolder1_btnOK","dynamicServicePath":"/RequestForVirasatMutation.aspx","id":"ModalPopupExtenderAlert","popupControlID":"ContentPlaceHolder1_pnlmsgConfirm"}, null, null, $get("ContentPlaceHolder1_btnShowPopup"));
});
//]]>
</script>
</form>

</body>

</html>
