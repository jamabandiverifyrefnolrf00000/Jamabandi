
<!DOCTYPE html>
<html lang="en">


<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="google" content="notranslate" /><title>
	Home
</title><link rel="stylesheet" href="ui-assets/fontawesome/css/fontawesome.css" /><link rel="stylesheet" href="ui-assets/fontawesome/css/solid.css" /><link rel="stylesheet" href="ui-assets/vendor/bootstrap/dist/css/bootstrap.css" /><link href="ui-assets/sweetalert/sweetalert2.min.css" rel="stylesheet" /><link rel="stylesheet" href="ui-assets/vendor/datatables_with_buttons/datatables.min.css" />
    <!-- pe-icon-7-stroke styles -->
	<link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" /><link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/helper.css" />
	 <!-- Custom styles -->
    
    <link rel="stylesheet" href="ui-assets/vendor/virtual-keyboard/css/keyboard.css" /><link rel="stylesheet" href="ui-assets/styles/style.css" /><link rel="stylesheet" href="ui-assets/styles/responsive.css" /><link rel="stylesheet" href="ui-assets/styles/plrs-custom-v1.0.css" /><link rel="stylesheet" href="ui-assets/styles/CardStyle.css" /><link rel="stylesheet" href="ui-assets/styles/custom.css" /><link href="ui-assets/landingPage/css/style.css" rel="stylesheet" type="text/css" /><link href="ui-assets/landingPage/css/flexslider.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="ui-assets/styles/select2.min.css" /><link rel="stylesheet" href="ui-assets/styles/selectStyle.css" /><link rel="stylesheet" href="ui-assets/styles/backToTop.css" /> 
<style>
    .d-flex{
        display:flex;
    }

    .margin-left-right-auto{
        margin-left:auto;
        margin-right:auto;
    }

    .margin-left-right-auto h3 {
      color: #ffffff;/*#126f00*/
    }

    .head-legend {
      padding: 20px 0;
    }

    .head-legend span {
      font-size: 20px;
    }

    .digi-pub-footer-top{
        padding: 25px 0 10px;
    }
</style>
    <style>
#SelectRegion_rdPeriod {
  height: auto;
}
</style>
    
    <link href="ui-assets/styles/plrsheader.css" rel="stylesheet" />

     <script   src="ui-assets/jquery/jquery.min.js" nonce="FefuU0I4eluwimIkPYloOw">
	</script>
	
    <script   src="ui-assets/jquery-ui/jquery-ui.min.js" nonce="FefuU0I4eluwimIkPYloOw" >
    </script>
       
     <script src="ui-assets/sweetalert/sweetalert2.all.min.js" 
        nonce="FefuU0I4eluwimIkPYloOw" ></script> 
           
    <script src="ui-assets/scripts/plrs-custom-v1.0.js" nonce="FefuU0I4eluwimIkPYloOw">
	    </script>

    <link href="ui-assets/Pgstyles/defaultpg.css" rel="stylesheet" />

</head>
<body class="bg">
  
	<form method="post" action="./DigitalFard.aspx" onsubmit="javascript:return WebForm_OnSubmit();" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="Xo65HDzT0pDZKOny2eFnajo3kM4d5EOsdgo5874Rf8U5na4nGYSdm5uggbTNCROiMSa7I1ZkdFWKaClmtr+g10u3sUb/Hw8Z/EwT6aBJyL/oxNNY08JUwKfqfiCIdisIlB7t/ZhTVwQnOExFasls6w0dDDMNAv3/ZqkR+TEDdY/7wLd2RHFwYmlyPhP8tK+jcA2xxhLet8ED7onkLyGeaHWkFM5947R7+B2TJlwL+kY/o+BfmSOnWVm9dWsnSIJ4MZ6f250CXFmT3R+LXn/qg+VNd5AcMQ+nZlHTg4e1imQVd0RbNy1fWhG6+XTIwzWRpG8ys7KUtXm4sHyI0bIQs14OUc7BW55WvGKDdHD9Pp3hKvsQUA4RAUFubyRmBSRufs4/ZfZ9AGJIltJB9IL/2e5E0NBW8iIGjnZd28aPbqvwC/EWsSF3GvUckErtrFotTcuNrMVbLeIfnNxaOUStIcQ+zOWoWi3ERUDVMdbhnRIWCiqD892Gzxv7ZjjRJwNLnODMxJ6gM031boPw2t7Ym5yEuzt2VHb+556KoFelNhA0vTIi9atW13bbA9NQMecA14Ia8t0niP++7ieftqHxhJLwSZJSyIfWNwSzQGsDHxhD0Kw3CSR1RkJo5EzI3aXA+/+Q97iCQODcHarVEube61EKOodYa64ErIpkS/C8rPp8jjt8+8SGvqMY6748SQFtQ1kSwS/RBuP0KEkwvrm7YgnwxDwwxvLZp0s8Lqj+VxFeiJnEKD6rP5Sxr3GK4IulLnnZ6wrIt96hI9NH1zQfA2+fI83ZF1LIiv2rIf6SEnwhPVwwfxtuSb3yMTVQ7KaXtihr/rm0jHaiN4d07RxdDhdymIawHiCd7ErsKGMQvZJi3WsO6rieGZ+N56A9DS3XsWZksy+t18l/NiEyjPXYTJtWEWuEcUC38+2xp+3ski2V3HXhr+Zawe3cHGNwc/fJmNqoMZrUBKLjtL8AJDmgPmlLZ7c6RnFPVPiJg0R87fRtANdfBffzn9KJ57V+aOWDHcafwtNSS/960f6PaOW38iufP6voec+2+PN5f3ZtCN7Tq8go19Z/LjhN6p5VtALzofiHD8TUwkrTjyA8Rg484bz2N20NyhMYXcZ5kG3LhojH+t/V6FfhxI8w8B9BLfM+KprIGGZ82dXxQBrTxkZ0iihmpARKF8A+yUffnkRSypoN+dO8UbcGL8o+k0n7/N864GazY5GINsYSbF4aYxFlzfhqqmZnFKOtfAnKEGJEZPbAfAsZBAGyEGg3KMUSC7mCVRHwzjevn+ho5wd3t83nTkWuwxWGNXS9C2qdC4mD2D/w6A/0cNDx6bzUOFuhoVMLb8ZTfMBVXQy8MW/fzzZQsBR2WRV47fkbVnHnGJ58UaE8CSJ7I+YDWeDMG9a4tDb2qLJt0L62SE/B5VFrvxkI2AbxQsNLFJ0+hF5RqVw9r596or6hpZVkIy6O5vHQC/KcB9B55cB6KZfa91XbwdQ10aJJeSp6JZf6t945yDV4SMkdzcNXkSheKp5CzK6SXXFn4+oXfKOlB+bS/kTFve8WHI+4AyGFQunHszCrBNmG2cHhrWrZhA9Ra39qzLUkm/RcoZ+KM5MTupbaRI+Ah93TjI0mrtr6U80/1TaNaVjNsP20kdCeSOgDUPA7GigE4p+yeVxWs2JCnEHxruZkY4Ohc12JU5ZlJ9NvxcM+fqyx/sr0IurzJasEhmY1Udb+7/mNtnCpNWXjyBZMYb4V2jjJ3nUJVBlsOYoprUA7VN1w1PAS8XpWQkklRxhIvdC7YLy0OqbOdJRuMwf7Onj7+1qTSf8uzTngUCKFBzQxv12Aua5PoNG4B/yCJV+oi1FawfnlM5MfaeAPUe9VkJ7CN2gTICXEWDmwpzQmCac5d7bPoQDf+20tBAcd7Fd2k8LnvO2WoAhBdGLrNsQdrTSPjjdbWhaWY3Gna3wreR8lhHtFsaPG6mP5VW8wrpKlAelz77tZFM7Gy5omoYd3T9j5w/Gev+B15IrpKD4t3GuChS0Nx3nAInSxkVWnXpumXd0Ri7KWYfc1uziHzkibB20w4QCFzPpfuQ0c1QiX9TXh2IDFV6+7GQZ8Bi7laFICpWQV9y5KoO1w+wNfrvFjI45Gk6GUBKEVImDz+BupfDCz1DvuKQubNc/n9wVwrBsSzCn2XtPw7eYo1wTSiT4IxBSr0AHAnkrl06m82fRQ9HF4VtJOobAjkk2a+m5TIW9ycWudCloHwi5OnrOXcLcc7bq29CIclX8MUBO8XLQt+Wu9iqFR9y50f9wBbTeb9Toh2UM8Q0jvqRPeg7cr7Dl6kkKbGohTY/2gsfTI3wJSY1IMV6b3l+vtyp7RbgIDgbrBWJkWvp6yBFEIVN7ERuwXvZ55Phmnd0uO3ApvDBQR1DUcXT9IfwMR8VoNyTx55k59QVHyLYYLq6zuNWv7017B7qxj2QHLMHiq0LG1/tqlyvSymsYRmcKVmGjVzW8Ent1HBGO0bMd3TXF44tgS3cE7khVrV+qgjM/s1fapioMkm8yc/2lzOJISUtbTak86pf1wcT3703VFVWnscciMnT1M6NrfgT1iDWp+D2nePfKBRfo5tNuJraqDkqMhBMMolHrtVc29RwCwjtD8H3R7YAC1ea2bVaok/EemIcy94CZLEbCXOk4xuzGTuEpUzEvIWqmoaYO+z8Bc4siKN4rq1bOmp7bsvwfyuM4Tuha9caumjguxtD6cBMOgQmTi4x4aRTMcO4pnJbi1HwSvdGreZAoAfYQH5xGFFVA00i4IqYRlaK6voFZtb4z9JJNart/l8/oADdvdTfnmTvnowRMO6i58T94ZjmNfPJvQewzK75Gp3Aaq7nA7LQwe0T5PFffz3PLM+NlQ+mLB+VRiTYaC8xrZSxCtSzJsSx31YhJDzI3Zr8hj7bEM9rHSo+Alz0aGskwZZssmvOxyAQT20BAXKiJsxz0LR3esUC10VGp1akygW/fMeW8c1CVRlOyD4bpr77n09RXaSZnyOUD8fno9qxIYcZg2723sT5qoFWqHdA7q6C9asXUg9ZtPl2a19bwqWqXH+fG7MkUV9n+Vz/Oe+2McN6aQhsxDSacJ4O77x+Ud8rAwT2Fhcuv9wMzGawedB1jPxZaMm+meGQ5LgeTy4A5lVJoK3NQfE8nYJwAg0moJO+MMG4tkOqGiq23pJ1eWrmOBdQdw2wJy4PAyjleCHywsrhDswJFIznxiAaV+iYmZqoWaGAU5lS4vm7ULgxFHL42w5aApMdc7iZkfkAYziCm7rQAiE4yTXGj1UWFXT52tO2g0h9zvoddwi6vXDovbv3q2ypWFB4m+CDe3wo6cMJLx2eXjdvQVMkt+qLQI1woo9j5X1OWenxiUvMtPyrL+Izux4AYEx2ZiFfseK/5bDxEQYXd8oZwjk1ZCXd9EAxEmH36CPBePLTEve2N3KjUbyQaaXJJh9PMISmyHVkAaNprE8qw3X1FKLduvxF0wZ5+NbA5l7xW1Uxc/02lTWmGBrN5W84s4w9BEYfQBNm53mVvlRwAs17prQJAZS8ZgdSFbooKYCYj9reoCUPkgApvP3zITUkF2Po7GuPEoL0pmsTvfjTaCwgER4ZvFP47azkPvfxxVIYIQ/kuDaXRy7UjfkTtSIubwAhJ/R4nh5cRDrxL6IDIvKlovYqLExfb8ZCtJySr/XTIXFPAEDSk0TC3856AQ7Se9nVIB7rypkQCCdNVhSglB/CTSKYw4k2qbxGSUWDW/MlEr74TPv4AJph08S2yxpQcPRaHj0IGbU96lTvTlHp7HBXI5hR3YN+gtkUq+CMnqXDUGGFGjUagwaOHXp8l20jGuLP2M7o7U5+Tq3HzSjBEQEeALvseheYsW+OP8PAnHPBVcYnsVZJOzf2E4a8my+tn3C/aq/lO4wXdBSWcwdTn/4pS2+RDlrKyPxQAU/87ksucvcJJROcnhQYWh1cqAU6Q2aVsx4dOu1dk81oF7l2PVl8Sexn9PoxuANeYanyaLhe/f6zQlOGZa8sf/Y3JFTLioNXf423ZiSDsd84nN+3cj0sNqnfIcgXxOJsf6gasC8k+dmQ43bhnUut/S3d1AIqpIG+gDY02M7b4MWBFjKBshWZArIReYWH4jPXyWPdcC46/KMRKVH0UXsXEzVaKD3T6mt7wEPCrgRf32OsrG3bij4dgkorzbG1XrIRV+5blhv3uzUU1BvR8S5r2rPqvaXHM0NWK6uc/B7Vmei5Fpw0ac77s29aTUrF1um5GI3NeRPzTuwNvuC4k+Hg0Y5xBKZPe/p2XP8kRd7nXVuL0s3i2aF4CY7ioB2YN1qE087Xv45GO8AHgupGed/Jkr1PgwljtWiZt3WMwlfmXqyYezvvqPuxWzUyZGXl57fgJbgVYy8xKO+b1GW2L3YhL7/V12tFySK5YlUYGkYlwDHHJ93u7HqDb/3k9fA5xQIzycQN/D8NuvTq5iPFjcyeKS3beGCmhezkj83nk78OY0BgtEUOo1bArCg9IIHxseeYKLf2+i2Zxm0wVuszfyXkgVZo68DJX6LkewWbq3RBS5PyckeFtHXNbkmO/9z81htWWyhz5k/QWF0kLgPWpvtnD9PK21vfOPiZwmNZXy6GlWR0elHsUOH+Sjx/R+TE/a57f143r/AYIQBNNlBuiRKBdY+sAjvd6d7u2alxSnWEAgxF+PjHhNMGh0LHEbQLPvjQYyE6v5hWasrxbSSie5mhDdlcvgdB5HxshiTf3gP0xlzor6FvLZ9uaXZvILiHv/QTUYURN5MdFfFVCwCnI+ambKV8oYNceZ1vOgnVghCY0h6mNgCJmzxQ2Q9cseTYjpb6BdU+Rr5E+otxnPhlyh1gKeSU0BKXtFgfIFwSt5k/1vVFDKbipZ5NqbzcpaoiNG1Mhb4d/bH7DBL8RtGlxiUzV58ejq1ytZ9w6Le/0/cyC12d64L1TuDX83GRectgZhE5dhiJHxV7NWN7WeD2WcGHwmPUsxE6aCJptqj2hQ+N1fnw1Pk186j0ZtFp4k9UI6DfyQiFz9YEbwS796wNPAMcL6FPsJc5nrcb3PWs0zle7UtAngkA6TJiSn9woa2KqgSUoqhC85GOobE9M2LMuFrtFZ92BhMDHz4EBv5RgReU43kjYlDhXDxVfmarX/ZMAeTNTE9kv4QtJrHTM9DKWLuvC7Ia4R08nmcpSImQkoGcs2RA6qCvuLfFWUvyHN5KnaDJ5exILkvIhDSY0phZPbeU6DGrvnlWBExszSpuQWHAMfzpl9/O2wXsG+yrQy9tNXt7szO3zVXroLqAd5OwgryJA5pwDMQBdURRb1SgiBZxXWnqhL9nNMZLM5Yhy9+JrUoM+Wr0W/Jvvayltf1PaLjXC5ZGREoCm1vNUE9BHdzwUaRxMBBdurMWL/LsIt5Vif7KSyoHn4S1wGvJZfgKR7wHVq6MlrKVDzbGBAf/UGFmgOjs4WIzJx5S62r8O0X/vsdfpwbS5pr9RPQuccYmA/vsf6n4dUuPfCmOhSG9/Z37cYnoWNH0GrsqgA1ydne8I+1LoH4G/YAebvoHZBvOrVJvzL3DhQpJq+TakV6WVPNHScHexC5ab9VdpHead3AqSLr7ejuDYUl/vQ8OLU2zsizv1jsEhfqEsTikFp/StbNrjfL4lENERGd4Zzj4dEtZWLIz5cCWZqAXFHTuGHtn4/9eoq1VxvVVtKmqGS4KHPWCXzQKzGBQdLQB17hKui9zasSvmwveyw4adtdBDsNC6Onj+zlTrp8Vq552Zb9Z/AViy5jNlfBRs2mOpQ2GyhIObTKcbuOUzvYYdFJN7KZ5QfkZXmvhobxg4abi8OHAF7Cc6IRvW35e7LO3hXgNSgMi7cNkzn/1KWi2ip6QY4bSPAOJR+F1+nHZHPy9gt4OnTWlbUk67fByX6Kb7urqzK5hT3+BO606Yd5TKkaGkpLznmwj7fJcSWs41VCmeXOgl7QW1ttiiORRVjBa5Orf4AGCSt+vELCi3y1dlEXoZrB9hOZWXBZjvYX0+6ov3AR0uR8S4drPSk9gqNI64Luz16N2oYZ9fS1k+u5gjcTs+q5vEMleMlnT7RU2+TYTk2jP1DkKzZFYmz3hwvWLPZfsyZLTpGtb68fJ5C1X4JSieG8v2qAE97cGOIblvL3DiCopeLRRrtpQ4Ik77AHSOeGuFX7atAauOL46bGnAxN0H0lx2Zg78UIFqi04XIAW0Ju2SJMHMPbK9vOdO7zJrRy9KVTwtPFdC0wMFb6i5d4i/++CPXGo78VsElliNjHxws+lAiT93bCCWNl3LxV7rz5bfX+kWXqKP3Jb375s9+QWxOte4KvsPKEGFtntwO9NM8LV1laDVbkcBXbwkkTkqgdkzHWIBtKj1lDLrAm42qGmLulgON5BwaaABH4CA31ObcWWgJxXx2ama8rOMwZYI6z2xUcGr9fjzfcwogUYSTCbap5+hFbjrSvZ2LR1yd3SEfaZg4B4nriDcdTKO0kBVCixqS+CsXBj4fSSsaK/fESfokM9RdjFFuMUo9MR0EIDmgb6/h4CwuZF8kwwSXsB9IP9MKLlEW3OkHJsP61+K+xbNPTyXKBH0Pf3D973AKfRb2Rx3JcjAIxH0Qy2l1IK3oQRPggUc4ZfhPq2NXmz1s2fAK+9Dj0KEmuSKZijsFP5tTYrlch41b8B7cp8jHqLwRFkR4MF+kN/DLzRmIWRAtrm6ojc+QZYKimOdekX8PaFHz/FK/gEzmq9otbBUCVWOpKC20FC9TWUFKD4J6oLYBE0D9oNjIWFD4oVwqLc+y9pNoUIHKcNlblCoKqE7CzmP+gSzQJ7yYsjrEu+MLHzwSwcPZo+lmjHzpfW2R/1MP/efjsLX3Pw618gEHrPOWlxGOIZbGHvEh8vH/M7dNUEc0qMOS75rH0upSzPyUUtlgtBbr6rrdaFz8yTkNz8bNdpP086L22zGo40lCBIZXMWEgMT0YpNR/tPTeBCOpwhsFLLPPNu8CDi690Tz59fdqJ1JHWqKzwp8Bv8AHps7+9si81z2tYRe8deXaxCWtv5hq3+ZT9ai01+p7LtZ8r/aFLZvJ5kdWp7I9v4wRhzBWOv1N4so8bsEAJDcm4BiNtyj1hq/mzOaE0uPZmtWehacfdI1yPB/KyvvGAL7MnSQ7mj7s9SIPuu4RYlEIYP75m3r8APrYWJlWIa3vZsBTtcAic9XjE5MWx6hMXATtkJPpetTdTbT/o4VHgAaKmw23Le3w2TOP67VNd5sxmNpcBQdUyncVt3pQtin01EtLbe2Qmq8TKQPRiVUtXLU253lwZ/E5iHaejn36KBjP3xnHagxS3kKfDLlSOxSWSIkLh8vfR/6Q9/QYgySasPIYUj0kfKTAuAOtRBfVKe9OySC67An7L/dij38YQl5uBTPjgLWrBlzFk3W2bfY56/BHvDYYIsRgWOFidVukR+sEAU2rsnaSzJgU/F16DPavg9Et5H61TS80m2zfbuPO8PsvHdYTKz79EqXNWL0OR8VQmAABTtHBJ2aA8GjNw2oPHGG/znkLL6uhOkKAxeK9mHPf1LEt/6JBIH5LXXmW+5HHl6iFl+nBCmye2H8jZPzk1NrmH1D5ApySMWiYTfDiQxezp9QfoDbJ309zNDQX2Dy2AazK4vb0Kjcy9vLaSOabrNGW7PpDbYUVTuNJefhUIxSvchQar6wzPGPcHJ5lIx/BDc9ueBUCxjiNs+CzaPPVuzx3ptU1aKL2JASCEjGQXRzRY9+qV+nz7WsqX21oFZhDksGe3lONZLbTVM6b0D3zl7rRQapMnL0+a0dEUpu3Rc/TKSv9eJ6R+/J/IODAEiHkIQQzhby5Osumwhyc6M4vQvzpzWuTl6CQQdG3Q4wklAlv92ph/Mq9zh3nI5cv54H8iGdzZI/JjiajV3IwSs/n1KsOhvyS7RX0ii7qs5B7QnI+O6OReAwQEYYTh5mP/WSkQDC+tzWH557b8S1WfJyu3eGmE2899K/zpOfCmQeziw4g7mti3+PIsUCGVdBmqtzA+S7srO/hLkxLF4LYDVSKPLwGWhUSsgiDTpfqcPxX7mrjiIrg8FkiCsMbWkAHSZRvYW4MVmxXFTdIlHYrngtAY/Ol9K+r02F/prmirdkfsxMznpyMNouGwYT6W5jNCXUWCd8O9ndDbmwV+Lateyb57rjWe0lB4kWTBe9y0mH81VzGHlsE7WIdI7ngsviZuDqPtXRmDJiwgdcPVLpMMdy3XvXLY8hBw7geXUUrQnany5wS5Ax7Ad5O9GAJjZgBZidPaE3EK4axXg2re0QTD3b+v33X4JznBSs0UsXDrHmTPsa2SCBfQWshLw6dEmEPFUPdLqSBlTKqwrG8LxGh5mex0zdPgQWdL4Sf8qHn5M8SbyXerdAMfPPmHV8ij9a4oU9MZ019+2yQ7hJ1B3URIuAcNwWEy36oIOiSJ678Ym5AjlJjTzAxudMcaUtxH47OlPMBv5fzGQa2rGFspTAOWoDNKrBfoHvgk9E6P6wVzkUuayyDBLS7LyJ5kBqwJhu3ZvyJ6PyLNPDBekQx64hk8BGL5xG/41olR5Qi//HUJhnqx8/3miYjihu4Ppuk+e74c4QnmRQpjqIk0NI7R7dsespfuSY2gjn1B9EIZAbKEkb97fy1ZmUugzOpFv/qGRFtRO3OQUelGd+gvBZRQSeV/aXUd5TfJdY5zqcCqhHbEo8pIyKkNESes8f4hBnQEQNY6YoTA1PkcQ/gIDRj/pmjMJpJJNuKxNTH6XciZYLosvq5IgemWzgbbHFxYLizt/lyvoJCHYK+4KOXeJSi9RYAgP0ckdN2rC9ZoUyEqftLAvZaVvQl8w2xEHjnk5y0pLoqH1ehswveeOr4lftBU6zjPwzbN/Jd0KSKBCn8M1jGR8TVE1zKq7iKLcoi4MwNEfc6qoeisgWQvfaC5lRi4x+P3cVHEwJ7iDkMpzp4DujpUPoKxwLdo6z8cul8kiMwD1eR4zKvUyYmIMEK4BgD2h3ukFa0BSNXbWsL8fHArRgf9zbJdvdMDlEJGu8tWx/JiP1bo9JINnfT1UqoUPBpVsjkGY0uWzwqGIUjAK7BnVj9U1aew1ZOFkL4yzVsrwCGelyDfJMd8/zw1Eslq2XJqrWKl/dLGnEZK1dYyrQEQ8HIVu/GZEKIXNRuNxAAe0iXs0Xeyu4qQDyMz3QcO0jnoGDGAGsFBCxVkrmH46JUeWyw8U0WOoGnYWtbSgfTmiBPA+zlLON/u3ZhUMmia5o/LLMo6GLPjiWvAR6gIdvS7gNJYyTezOXwU0iw+05R3Tur6azzauVroj/Bl5L5xQsnsTu2mis9BwWQtPwoGrytKkAgw3h85JGuFBc8TI2WhTF73vvfYpmzhqefvYuJYUjiX7b5nJOwKvsYCA/zzz0G7Cz/POmJSVTqTgNNdyhlUkzvdnkUcpOUBg50SIa98RXflH90cijpGvIK1W8RfAOTVAFG9tM+kVULYqFjXo9sWTj3LElf0jObXoihextgJJCcRahQsKriMTg0iTiK40UqTvtxsTqiwzjYWFU+3RZkJzA23NPEDL3kGyWkFbeqroHLUDBSLWqjlO4bt3jSfdzqwghkHuduECvzIedFhIc53gUbTqdY3iQHK5NMTQFryg6D9Ovt8q7XAIviUziITMaaNASgdkUgHB1VjuNd9daW9w0FQ9vrqAJu1VldE94jXVF3RkS0MGOKM22gKQ9GsSUJuKz0p2ci8wWzMtkWwjo4r6hd5bYPBLc7Sef9J2n+JZrYYGa89RZrW7pR6u5L8lOJXxgfr07AtIBQ/AGfGCPLvBLMvgJ9W8M2+nsM4YHUuA4ymmMP626bFio9Va4thpX05TUT9jIhYhWFUzZRK3Yn1R45T8jD6gjo7QsagoX2cxiuJw7qWqicugsyE7By31HqETutS3impGppCwdsD7k0C/ksEu0nlvj8SaNiu2+LDOM+foMCzygOVCj8QY2hodMbmEub7PeqEGkITvgxqyjWsL9nIj7fmA4Kt9VhiavUSWLaKIJAk1AXbEY5vIG6Z5h13jgJAtIvLzqo0/vb44nEaH4hrMqNoBKBILNAolQC+dFPJyvj1VFPdJ8kLuOdicq+EIIxEYetIW/hUbdd9qEq7aV5BrCjCYxskMRI0sTBPb5w/XK9F74eOaZNVxmEDW3UQ3JeYRye0DK0dSyMR8IKnr2Uznt0QVEK1BHKwAxUVaiCtGZSDKKR9mEpwOm1GKgbvvz/U8dPOBvmiSlg89S9mzHKI49lpPo2NJRBZqr/mTARyosVJoUjeezD1RoKA/54LBQCnwmaHzkLvLZGpr/fqv95U2VJNUdnmhKeMWN0vbkB7lyu5UvbgWSy9kLZDI7rBk5TIMSPR7HvVAeTg/BXDKkEKExVs8vG9/zXYNO5Y23eMiu4cVT6GfB3UN4lcQ5RuJ4vov1tWrPjbFt1/vRQDXD1xFbA520ccUlcF+nm8+REF9fO57bvXE8D7+lLayVKNS3MmnChk9ESSyApcrdp2OJr1Iv/7k2myA/Nf2Il5bC5TSSMECPw/XsLvj8A/adyZRo8dlbWHqVhq2C0x6XfvrWg/YFXZIaaVpwSxxHCBUE/fXUhp0LkP64ll00U3X+B8P2tRiIk4vYMC1IM1lI5A29rpod5ANMikm/sgFVWGBghxtHj/F7hBHngfGEgm0s1DxhpA3Kq156+Wrg4DkeuLaQTueVvsBfUDrBwjTm3g5mUAgT3JBovDt8zAR7bNLfkjUT4jGsn0HUM18kfrougWyTKGk/2q0dnWbvGFHvLoKCzxrGsjOSpWd46NkR/onO6dtbyy+ovb5bma64Xo0ZqvK39vziKg/oVxdNzBVaIhSzv7YzneeN3i5PurUlZNdJ6O4Akrky77lK4E6rNrknyqJNftWG4inlcmoAL66AqTFtcchFKWEleD2oXDXhWfFRg++ZvCBRX4XppqyYKGh5GFwULSkso62WRnSxGtg/WXv819Lw+XRUgcuHiRKYnLUw6oba5mNSXMJRENMkRwEfddmFW1/mYzQx2e9pTUpaQRonSf1nAlErOotfwOnx3u3szqwo27v/4vGhc9/T8iuAWoQRQhy7Qia3wJ308BZOjVtqBDelh59AWGigTCUx05+pYb5fr1LsAVYedvevtFUlqEArfT2ZENRO7RQVaEzxFU+VeKnFOPr+qUvjm2/f3zjGxbLS2DSTdDBWP4vnuMHPN3w2YagXHQzKCz9IWp/gh6fhMf0JD9srrlRk5SR2xpqk1tbfY=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZBbRI-vLFGPASeYxh_KgLGJAGhxxxQHaAFUowMEJ38zbzJMIHhOPM0QVtz7ClVSrJw2&amp;t=639202794265548063" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1HoTsDJCIwegf7-cSVNQxKlxqJplUAag2gjZMR_ctGyeKzMDbl61mq8CG1bXK2cKIO5F_d_eACHU7rvEovdRsHjPwMxL_2RbhdHxnXThSzdTd55hY37B50zmwPwIsJ1FnQ2&amp;t=4623e90" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvqBoWBYTDUGuawA_2GYbNQlKfMSt2G6fTRv2v_CvkMQC-NDKOxcBHZBsr4m43UZoWnDElLWlfRSMae7wFN5-j848Bfbquym3Qmm_a4KPTP8MlNJWDtdRKeoXno9ND71Mj-dmT4RATMPqWph8tRm5et41&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OAh7tEdde-lvG3-30egxXz8aAgw_K6hDRuGQnL44pJNvGX0k88IpkhwtBpf_hp5FI_xl-S6IOzDAoSwTftgBkdwIVbozv2itakdYRoj6lyvW2iAmc3lxcxcAsYCLcWBMdMG64QNAlb5JWK1NKm4PkKk1&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="F93C7351" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="ZupUn+XhZzmmY76aWkRK+LkJtJwgyVBznTcetdt4TEOWN0kG0TDWfzlLNJSv87LsUSpXct6KtE3QXj4f/v5V2RSiHD2ISa3pdaIpHRvQaN1LLQkuPdFXEKOVWittlBlyLjLDPgDAW6STl8MQSA4BRrjNoih8FM4XHDga7Hlz0f/ZFKOk1gDtavXIPGLD7dOWaDq20MtEtxaaSMPc8eygljnUL8DcM5+TYgPajHStkBOUeoyLAkvRkwBJ1BQz/EigXevoCi9Odx5RKjmGm22CCzHlrmU2HD5JtrqegpA4/UAXS2n4ZGhzb603B4rcahjGbzu3ItIx0yORGi8GG44Pv+D/m66k/4CHkiny5RgE5khGQNMItz+CiEq56ioS8Fo1AHfIa3bY2N1hJDrK1jOprJ7maXAjip1GlOLJV/iN3HJdMEVZtWAOE/2QUHk8whNPYr1B/6PCXKqJ0CAiZywi2Oj+3UaXO9ma0lI7TNXfAvgOSPX/0yr2hdqwCoNQZNCcbd5I8WnlHwrt5FQGJD8d3NCXRt/XQ3yV/2c7WR37Yk6jrWpzfyDOmL6oBD7VB9hc2eQB3QMF3WhVXzNs3mFZ2OeJVFhkJFpgoltS2wiThWgls3KUdiSwDzTlFfkHLU7TiiC0rtxMEp0z+fnvGroT1R1gJvKQFp5K4lqjG2CkSs0KDTvjSgAS07h0vf2/4Y0UDwluLTl+jDth/DckbbDjT4HIW6Ef7LwV3GrEv7ecaqWPUDSjScG4sz8zUlWtVdyD" />
</div>
           
        <div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', ['tctl00$SelectRegion$updChangeRegion','SelectRegion_updChangeRegion','tctl00$UpdRegion','UpdRegion','tctl00$ContentPlaceHolder1$updRegionSelector','ContentPlaceHolder1_updRegionSelector'], [], [], 600, 'ctl00');
//]]>
</script>

            <button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-topD">
                <i class="fas fa-arrow-up"></i>
</button>
<!-- Simple splash screen-->
<div class="splash">
 <div class="color-line"></div>
 <div class="splash-title">
 <h1>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h1>
 <p>ਕਿਰਪਾ ਕਰਕੇ ਉਡੀਕ ਕਰੋ ਜਦੋਂ ਤੱਕ ਅਸੀਂ ਤੁਹਾਡੇ ਲਈ ਖੋਜ ਮੋਡੀਊਲ ਨੂੰ ਸੈਟਅਪ ਕਰਦੇ ਹਾਂ./Please wait while we setup the search module for you. </p>
 <img src="ui-assets/images/loading-bars.svg" width="64" height="64" alt="Loading.."/>
  </div>
   </div>
		<div id="updWebsite" style="display:none;">
	
				<div class="loadingContainer">
					<div class="loading">
						<img src="ui-assets/images/loading-bars.svg" alt="Loading.." width="64" height="64" />
						&nbsp;
					&nbsp;
					</div>
				</div>
			
</div>
<!-- Header -->
	
        
        <div id="header">
            <div id="plrs-header">
                 
    <div class="plrs-header-row">
     
        <!-- LOGO -->
        <div class="plrs-left">
        <div class="plrs-logo">
            <img src="ui-assets/images/logo.png" alt="Punjab Land Records" />
            <div class="plrs-logo-text">
                ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼
                <span>Punjab Land Records</span>
            </div>
        </div>
        <div class="plrs-menu header-link hide-menu"><i class="fa fa-bars"></i></div>
            </div>
        <!-- REGION -->
        <div class="plrs-region">
               
             

<div id="dvChangeRegion" class="modal fade">

	<div class="modal-dialog modal-lg" style="min-width:80%">
		<div class="modal-content">

			<div id="SelectRegion_updChangeRegion">
	

					<div class="modal-body">
						<div class="row">
                            <div class="col-md-12 m-t-sm">
                                <fieldset id="SelectRegion_fsSelectRegion" class="form_ font-resize-scope">
										<legend id="SelectRegion_lgSelectRegion" class="lg p-sm head-legend">
											<i class="fa fa-map-marker"></i>
											<span id="SelectRegion_lbllgRegionInfo">ਖੇਤਰ ਚੁਣੋ/Select the Region</span>
										</legend>
							   <div class="dvSelectRegion m-t-sm m-b-sm">
                                   <div class="row form-group">
                                                    <div class="col-md-12" >
                                                		<span id="SelectRegion_Label2" class="label label-lg-font-size">ਜਮਬੰਦੀ ਪੀਰੀਅਡ/Jamabandi Period</span>
														<table id="SelectRegion_rdPeriod" class="form-control smedium m-t-sm">
		<tr>
			<td><span class="radiobtn"><input id="SelectRegion_rdPeriod_0" type="radio" name="ctl00$SelectRegion$rdPeriod" value="1" checked="checked" tabindex="1" /><label for="SelectRegion_rdPeriod_0">ਮੌਜੂਦਾ/Current</label></span></td><td><span class="radiobtn"><input id="SelectRegion_rdPeriod_1" type="radio" name="ctl00$SelectRegion$rdPeriod" value="2" onclick="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$rdPeriod$1\&#39;,\&#39;\&#39;)&#39;, 0)" tabindex="1" /><label for="SelectRegion_rdPeriod_1">ਪਿਛਲਾ/Previous</label></span></td>
		</tr>
	</table>
                                                        </div>
                                                </div>
                                <div class="row form-group">
								    <div class="col-sm-3 district-dropdown" style="position:relative; z-index:9">
									    <span id="SelectRegion_lblddlDistrict" class="label  label-lg-font-size">ਜ਼ਿਲ੍ਹਾ/District</span>
									    <select name="ctl00$SelectRegion$ddlDistrict" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlDistrict\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlDistrict" tabindex="2" class="form-control">
		<option selected="selected" value="">ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Choose District</option>
		<option value="7">ਅੰਮ੍ਰਿਤਸਰ/Amritsar</option>
		<option value="8">ਬਰਨਾਲਾ/Barnala</option>
		<option value="9">ਬਠਿੰਡਾ/Bathinda</option>
		<option value="10">ਫਰੀਦਕੋਟ/Faridkot</option>
		<option value="11">ਫਤਿਹਗੜ੍ਹ ਸਾਹਿਬ/Fatehgarh Sahib</option>
		<option value="12">ਫ਼ਾਜ਼ਿਲਕਾ/Fazilka</option>
		<option value="13">ਫਿਰੋਜਪੁਰ/Ferozepur</option>
		<option value="14">ਗੁਰਦਾਸਪੁਰ/Gurdaspur</option>
		<option value="15">ਹੁਸ਼ਿਆਰਪੁਰ/Hoshiarpur</option>
		<option value="16">ਜਲੰਧਰ/Jalandhar</option>
		<option value="17">ਕਪੂਰਥਲਾ/Kapurthala</option>
		<option value="18">ਲੁਧਿਆਣਾ/Ludhiana</option>
		<option value="18953">ਮਲੇਰਕੋਟਲਾ/Malerkotla</option>
		<option value="19">ਮਾਨਸਾ/Mansa</option>
		<option value="20">ਮੋਗਾ/Moga</option>
		<option value="21">ਪਠਾਨਕੋਟ/Pathankot</option>
		<option value="22">ਪਟਿਆਲਾ/Patiala</option>
		<option value="23">ਰੂਪਨਗਰ/Rupnagar</option>
		<option value="24">ਐਸ. ਏ. ਐਸ ਨਗਰ/S.A.S. Nagar</option>
		<option value="25">ਸੰਗਰੂਰ/Sangrur</option>
		<option value="26">ਸ਼ਹੀਦ ਭਗਤ ਸਿੰਘ ਨਗਰ (ਨਵਾਂਸ਼ਹਿਰ)/Shahid Bhagat Singh Nagar(Nawanshahr)</option>
		<option value="27">ਸ਼੍ਰੀ ਮੁਕੱਤਸਰ ਸਾਹਿਬ/Sri Muktsar Sahib</option>
		<option value="28">ਤਰਨ ਤਾਰਨ/Tarn Taran</option>

	</select>
                                        <span id="SelectRegion_RFVDistrict" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District</span>
								    </div>
                                    <div class="col-sm-3 m-b-md tehsil-dropdown" style="position:relative; z-index:8">
									    <span id="SelectRegion_lblddlTehsil" class="label label-lg-font-size">ਤਹਿਸੀਲ/Tehsil</span>
									    <select name="ctl00$SelectRegion$ddlTehsil" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlTehsil\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlTehsil" disabled="disabled" tabindex="3" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਤਹਿਸੀਲ ਚੁਣੋ/Choose Tehsil</option>

	</select>
                                        <span id="SelectRegion_RFVTehsil" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil</span>
								    </div>
                                    <div class="col-sm-3 village-dropdown" style="position:relative; z-index:7">
									    <span id="SelectRegion_lblddlVillage" class="label label-lg-font-size">ਪਿੰਡ/Village</span>
									    <select name="ctl00$SelectRegion$ddlVillage" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlVillage\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlVillage" disabled="disabled" tabindex="4" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਪਿੰਡ ਚੁਣੋ/Choose Village</option>

	</select>
                                        <span id="SelectRegion_RFVVillage" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village</span>
								    </div>
                                    <div class="col-sm-3 m-b-md year-dropdown" style="position:relative; z-index:6">
									    <span id="SelectRegion_lblddlYear" class="label label-lg-font-size">ਸਾਲ/Year</span>
									    <select name="ctl00$SelectRegion$ddlYear" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlYear\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlYear" disabled="disabled" tabindex="5" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਸਾਲ ਚੁਣੋ/Choose Year</option>

	</select>
                                        <span id="SelectRegion_RFVYear" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year</span>
								    </div>
                                </div>
							</div>
                                    </fieldset>
                            </div>

						</div>
					</div>
					<div class="modal-footer">
						<!-- Submit Button-->
						<input type="submit" name="ctl00$SelectRegion$btnSearch" value="ਖੇਤਰ ਬਦਲੋ/Change Region" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$SelectRegion$btnSearch&quot;, &quot;&quot;, true, &quot;ChangeRegion&quot;, &quot;&quot;, false, false))" id="SelectRegion_btnSearch" tabindex="6" class="btn btn-pimary submit-custom-btn" />
						<button id="SelectRegion_btnCancel" class="btn btn-danger btn-no" data-dismiss="modal" TabIndex="7">ਰੱਦ ਕਰੋ/Cancel</button>
					</div>
				
</div>
			
			

		</div>
	</div>
</div>

            <div id="UpdRegion">
	
                    







                
</div>
        </div>

        <!-- ACTIONS -->
        <div class="plrs-actions">
            <div class="plrs-font">
                 <input type="button" id="btnincreasefonts"  value=" A+ " />
                 <input type="button" id="btndecreasefonts"  value=" A- " />
                 <input type="button" id="btnresetfonts" value=" A= " />
            </div>

            <a href="Login.aspx" class="plrs-login">
                <i class="fa fa-lock"></i>
                Official Login
            </a>
        </div>

    </div>
            
</div>

</div>


        <div id="divBackground" class="modal"></div>
		
        
<link href="../ui-assets/Pgstyles/uc_navugatonmenu.css" rel="stylesheet" />
<!-- Navigation -->
<aside id="menu">
	<div id="navigation">
		<nav class="nav-primary">
			<ul class="nav">
				
				
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl00_liItem">
							<a href="Default.aspx?itemPID=1">
								    
                                    <i class='fa-solid fa-house'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl00_bBG" class="bg-info"></b>
								</i>
								
								<span>ਮੁੱਖ ਪੰਨਾ/Home</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl01_liItem">
							<a href="OnlineRequestStatus.aspx?itemPID=77">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl01_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਟਰੈਕ ਐਪਲੀਕੇਸ਼ਨ/Track Application</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_liItem">
							<a href="./?itemPID=82">
								    
                                    <i class='fa-solid fa-file-export'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl02_bBG" class="bg-primary2"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl02_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਸ਼ਿਕਾਇਤ ਨਿਵਾਰਨ/Grievance Redressal</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl02_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Grievance.aspx?RefNo=1&itemID=83&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦਾਖਲ ਕਰੋ/Submit Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_liItem">
											<a href="GrievanceTrack.aspx?RefNo=2&itemID=84&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦੀ ਜਾਂਚ ਕਰੋ/Track Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_liItem">
							<a href="Jamabandi.aspx?itemPID=3">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl03_bBG" class="bg-success"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl03_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਜਮ੍ਹਾਂਬੰਦੀ ਵੇਖੋ/View Jamabandi</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl03_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Jamabandi.aspx?section=Owner-Name-Wise&itemID=7&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਮਾਲਕ ਦੇ ਨਾਮ ਮੁਤਾਬਕ/Owner Name Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Jamabandi.aspx?section=Khewat-Number-Wise&itemID=8&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖੇਵਟ ਨੰ: ਮੁਤਾਬਕ/Khewat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_liItem">
											<a href="Jamabandi.aspx?section=Khasra-Number-Wise&itemID=9&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਸਰਾ ਨੰ: ਮੁਤਾਬਕ/Khasra No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_liItem">
											<a href="Jamabandi.aspx?section=Khatouni-Number-Wise&itemID=10&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਤੌਨੀ ਨੰ: ਮੁਤਾਬਕ/Khatouni No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_liItem">
							<a href="Mutation.aspx?itemPID=4">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl04_bBG" class="bg-danger"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl04_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਇੰਤਕਾਲ ਵੇਖੋ/View Mutation</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl04_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Mutation.aspx?section=Mutation-Number-Wise&itemID=13&itemPID=4">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਇੰਤਕਾਲ ਨੰ: ਮੁਤਾਬਕ/Mutation No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_liItem">
							<a href="Roznamcha.aspx?itemPID=5">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl05_bBG" class="bg-info"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl05_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਰੋਜਨਾਮਚਾ ਵੇਖੋ/View Roznamcha</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl05_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Roznamcha.aspx?section=Rapat-Number-Wise&itemID=11&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਰਿਪੋਰਟ ਨੰਬਰ ਮੁਤਾਬਕ/Rapat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Roznamcha.aspx?section=Waqiati-Number-Wise&itemID=12&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਵਾਕਿਆਤੀ ਮੁਤਾਬਕ/Waqiati No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl06_liItem">
							<a href="RegistryDeed.aspx?itemPID=21">
								    
                                    <i class='fa-regular fa-copy'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl06_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਰਜਿਸਟਰਡ ਡੀਡ ਵੇਖੋ/View Registered Deed</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl07_liItem">
							<a href="FardStatus.aspx?itemPID=29">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl07_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਫਰਦ ਬੇਨਤੀ ਸਥਿਤੀ/Fard Request Status</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl08_liItem">
							<a href="GroundTruthingDataMap2.aspx?itemPID=85">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl08_bBG" class="bg-success"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-2 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-2 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl09_liItem">
							<a href="GroundTruthingDataMap3.aspx?itemPID=86">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl09_bBG" class="bg-danger"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-3 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-3 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl10_liItem">
							<a href="IPWTD.aspx?itemPID=15">
								    
                                    <i class='fa fa-university'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl10_bBG" class="bg-info"></b>
								</i>
								
								<span>ਇਨਟੈਗਰੇਟਿਡ ਜਾਇਦਾਦ/Integrated Property</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl11_liItem">
							<a href="faq.aspx?itemPID=33">
								    
                                    <i class='fa fa-question-circle'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl11_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਐੱਫ ਏ ਕਿਊ/FAQ</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl12_liItem">
							<a href="UserManual.aspx?itemPID=35">
								    
                                    <i class='fa fa-user'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl12_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਉਪਯੋਗ ਪੁਸਤਕ/User Manual</span>
                                 
							</a>
							
							
							
                            
						</li>
					
                				
			</ul>
		</nav>
	</div>
</aside>


	    
		<div id="wrapper" >
            <div class="page-body">
                <div class="normalheader transition animated fadeIn small-header hide-mob hidden-xs hidden-sm">
				<div class="hpanel">
					<div class="panel-body">
						<div class="row">
							<div class="col-sm-12">
                                <div class="nav-pills bg-light breadcrumbs">
                                    <span id="SiteMapPath1"><a href="#SiteMapPath1_SkipLink" style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;">Skip Navigation Links</a><span><a href="/Default.aspx">ਔਨਲਾਈਨ ਸੇਵਾਵਾਂ/Online Services</a></span><span> &gt; </span><span>ਡਿਜ਼ਿਟਲੀ ਦਸਤਖਤ ਕੀਤੀ ਫਰਦ ਦੀ ਕਾਪੀ/Digital Signed Copy of Fard</span><a id="SiteMapPath1_SkipLink"></a></span>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>

		<div class="content animate-panel">
            
	
	<div class="content transition animated fadeIn">
		<div class="panel hpanel dblue">

			<div class="panel-body">
				<div class="form-horizontal">

					<div id="ContentPlaceHolder1_updRegionSelector">
	
                     <div class="row">
                                 <div class="col-md-12 m-t-sm">
                                <fieldset id="ContentPlaceHolder1_fsOnlineFard">

										<legend id="ContentPlaceHolder1_Legend2" class="lg p-sm head-legend">
											<i class="fa fa-info-circle hidden"></i>
											<span id="ContentPlaceHolder1_lbllgFardIssueInfo">ਡਿਜੀਟਲ ਦਸਤਖਤ ਵਾਲੀ ਫਰਦ ਦੀ ਕਾਪੀ/Digital Signed Copy of Fard</span></legend>
    										
                                    <div class="dvNakalType" >

											<!-- Nakal Type Menus Section Start-->
                                            <div class="row">
											
                                              
                                                     <div class="col-md-3 mt-2">
                                                        <div class="Mutation-corner-col text-center">

														<a href="FardRequestQR.aspx?section=Owner-Name-Wise&itemID=39&itemPID=38" id="ContentPlaceHolder1_rptOnlineFard_alnkbtn_0" data-toggle="" data-target="">
                                                                <h3> <span class='fa-solid fa-user'></span></h3>
                                                               <h3> ਮਾਲਕ ਦੇ ਨਾਮ ਮੁਤਾਬਕ/Owner Name Wise</h3>
														</a>
													</div>
                                                    </div>




													
													
													
													
                                                    

                                                  
												
                                              
                                                     <div class="col-md-3 mt-2">
                                                        <div class="Mutation-corner-col text-center">

														<a href="FardRequestQR.aspx?section=Khewat-Number-Wise&itemID=40&itemPID=38" id="ContentPlaceHolder1_rptOnlineFard_alnkbtn_1" data-toggle="" data-target="">
                                                                <h3> <span class='fa-solid fa-map-marker'></span></h3>
                                                               <h3> ਖੇਵਟ ਨੰ: ਮੁਤਾਬਕ/Khewat No. Wise</h3>
														</a>
													</div>
                                                    </div>




													
													
													
													
                                                    

                                                  
												
                                              
                                                     <div class="col-md-3 mt-2">
                                                        <div class="Mutation-corner-col text-center">

														<a href="FardRequestQR.aspx?section=Khatouni-Number-Wise&itemID=41&itemPID=38" id="ContentPlaceHolder1_rptOnlineFard_alnkbtn_2" data-toggle="" data-target="">
                                                                <h3> <span class='fa-solid fa-map-marker'></span></h3>
                                                               <h3> ਖਤੌਨੀ ਨੰ: ਮੁਤਾਬਕ/Khatouni No. Wise</h3>
														</a>
													</div>
                                                    </div>




													
													
													
													
                                                    

                                                  
												
                                              
                                                     <div class="col-md-3 mt-2">
                                                        <div class="Mutation-corner-col text-center">

														<a href="FardRequestQR.aspx?section=Khasra-Number-Wise&itemID=42&itemPID=38" id="ContentPlaceHolder1_rptOnlineFard_alnkbtn_3" data-toggle="" data-target="">
                                                                <h3> <span class='fa-solid fa-map-marker'></span></h3>
                                                               <h3> ਖਸਰਾ ਨੰ: ਮੁਤਾਬਕ/Khasra No. Wise</h3>
														</a>
													</div>
                                                    </div>




													
													
													
													
                                                    

                                                  
												
                                            </div>
											<!-- Nakal Type Menus Section End-->

										</div>
									</fieldset>
                                </div>
                            </div>
                           
</div>

				</div>
			</div>
		</div>
	</div>



            
			
			
			
			
			
			
		</div>

    </div>
    <!-- Footer-->
    <footer class="footer footer-font">

    <!-- Govt -->
    <div class="digi-topBoderThickDis">
        <div class="container-fluid text-center">
            <span>ਮਾਲ, ਮੁੜ ਵਸੇਬਾ ਅਤੇ ਆਪਦਾ ਪ੍ਰਬੰਧਨ ਵਿਭਾਗ,ਪੰਜਾਬ ਸਰਕਾਰ, ਭਾਰਤ / Department of Revenue, Rehabilitation and Disaster Management, Government of Punjab, India.
            </span>
        </div>
    </div>

    <!-- Copyright -->
    <div class="digi-topBoder">
        <div class="container-fluid text-center">
            <span>ਕਾਪੀਰਾਈਟ © 2025 ਪੰਜਾਬ। ਸਾਰੇ ਹੱਕ ਰਾਖਵੇਂ ਹਨ। / Copyright © 2025  Punjab. All rights reserved.
            </span>
        </div>
    </div>

    <!-- Stats -->
    <div class="digi-topBottomBoder footer-stats">
        <div class="container-fluid">
            <div class="footer-stats-row">
                <span class="badge-pill">
                    ਕੁੱਲ ਵਿਜ਼ਿਟਰ/Total Visitors :
                    <span id="lblv">2380020</span>
                </span>

                <span class="badge-pill">
                    ਆਖਰੀ ਵਾਰ ਅੱਪਡੇਟ ਕੀਤਾ/Last Updated :
                    <span id="lblud">12/10/2026</span>
                </span>
            </div>
        </div>
    </div>

</footer>

</div>	          
    <script src="ui-assets/vendor/bootstrap/dist/js/bootstrap.min.js" nonce="FefuU0I4eluwimIkPYloOw"></script>
	<script src="ui-assets/vendor/datatables_with_buttons/datatables.min.js" nonce="FefuU0I4eluwimIkPYloOw"></script>
	<script src="ui-assets/vendor/virtual-keyboard/js/keyboard.js" type="text/javascript" nonce="FefuU0I4eluwimIkPYloOw"></script>
 <!-- App scripts -->
    <script src="ui-assets/scripts/homer.js" nonce="FefuU0I4eluwimIkPYloOw"></script>
    <script src="ui-assets/Pgscript/masterpg.js" nonce="FefuU0I4eluwimIkPYloOw"></script>
    <script src="ui-assets/scripts/select2.min.js" nonce="FefuU0I4eluwimIkPYloOw" > </script>
    <script src="ui-assets/scripts/BackToTopN.js" nonce="FefuU0I4eluwimIkPYloOw" > </script>              
</div>

<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("SelectRegion_RFVDistrict"), document.getElementById("SelectRegion_RFVTehsil"), document.getElementById("SelectRegion_RFVVillage"), document.getElementById("SelectRegion_RFVYear"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var SelectRegion_RFVDistrict = document.all ? document.all["SelectRegion_RFVDistrict"] : document.getElementById("SelectRegion_RFVDistrict");
SelectRegion_RFVDistrict.controltovalidate = "SelectRegion_ddlDistrict";
SelectRegion_RFVDistrict.focusOnError = "t";
SelectRegion_RFVDistrict.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District";
SelectRegion_RFVDistrict.display = "Dynamic";
SelectRegion_RFVDistrict.validationGroup = "ChangeRegion";
SelectRegion_RFVDistrict.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVDistrict.initialvalue = "";
var SelectRegion_RFVTehsil = document.all ? document.all["SelectRegion_RFVTehsil"] : document.getElementById("SelectRegion_RFVTehsil");
SelectRegion_RFVTehsil.controltovalidate = "SelectRegion_ddlTehsil";
SelectRegion_RFVTehsil.focusOnError = "t";
SelectRegion_RFVTehsil.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil";
SelectRegion_RFVTehsil.display = "Dynamic";
SelectRegion_RFVTehsil.validationGroup = "ChangeRegion";
SelectRegion_RFVTehsil.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVTehsil.initialvalue = "";
var SelectRegion_RFVVillage = document.all ? document.all["SelectRegion_RFVVillage"] : document.getElementById("SelectRegion_RFVVillage");
SelectRegion_RFVVillage.controltovalidate = "SelectRegion_ddlVillage";
SelectRegion_RFVVillage.focusOnError = "t";
SelectRegion_RFVVillage.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village";
SelectRegion_RFVVillage.display = "Dynamic";
SelectRegion_RFVVillage.validationGroup = "ChangeRegion";
SelectRegion_RFVVillage.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVVillage.initialvalue = "";
var SelectRegion_RFVYear = document.all ? document.all["SelectRegion_RFVYear"] : document.getElementById("SelectRegion_RFVYear");
SelectRegion_RFVYear.controltovalidate = "SelectRegion_ddlYear";
SelectRegion_RFVYear.focusOnError = "t";
SelectRegion_RFVYear.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year";
SelectRegion_RFVYear.display = "Dynamic";
SelectRegion_RFVYear.validationGroup = "ChangeRegion";
SelectRegion_RFVYear.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVYear.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        Sys.Application.add_init(function() {
    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":500,"dynamicLayout":true}, null, null, $get("updWebsite"));
});

document.getElementById('SelectRegion_RFVDistrict').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVDistrict'));
}

document.getElementById('SelectRegion_RFVTehsil').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVTehsil'));
}

document.getElementById('SelectRegion_RFVVillage').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVVillage'));
}

document.getElementById('SelectRegion_RFVYear').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVYear'));
}
//]]>
</script>
</form>

</body>

</html>
