
<!DOCTYPE html>
<html lang="en">


<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="google" content="notranslate" /><title>
	ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records
</title><link rel="stylesheet" href="ui-assets/fontawesome/css/fontawesome.css" /><link rel="stylesheet" href="ui-assets/fontawesome/css/solid.css" /><link rel="stylesheet" href="ui-assets/vendor/bootstrap/dist/css/bootstrap.css" /><link href="ui-assets/sweetalert/sweetalert2.min.css" rel="stylesheet" /><link rel="stylesheet" href="ui-assets/vendor/datatables_with_buttons/datatables.min.css" />
    <!-- pe-icon-7-stroke styles -->
	<link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" /><link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/helper.css" />
	 <!-- Custom styles -->
    
    <link rel="stylesheet" href="ui-assets/vendor/virtual-keyboard/css/keyboard.css" /><link rel="stylesheet" href="ui-assets/styles/style.css" /><link rel="stylesheet" href="ui-assets/styles/responsive.css" /><link rel="stylesheet" href="ui-assets/styles/plrs-custom-v1.0.css" /><link rel="stylesheet" href="ui-assets/styles/CardStyle.css" /><link rel="stylesheet" href="ui-assets/styles/custom.css" /><link href="ui-assets/landingPage/css/style.css" rel="stylesheet" type="text/css" /><link href="ui-assets/landingPage/css/flexslider.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="ui-assets/styles/select2.min.css" /><link rel="stylesheet" href="ui-assets/styles/selectStyle.css" /><link rel="stylesheet" href="ui-assets/styles/backToTop.css" /> 
<style>
    .d-flex{
        display:flex;
    }

    .margin-left-right-auto{
        margin-left:auto;
        margin-right:auto;
    }

    .margin-left-right-auto h3 {
      color: #ffffff;/*#126f00*/
    }

    .head-legend {
      padding: 20px 0;
    }

    .head-legend span {
      font-size: 20px;
    }

    .digi-pub-footer-top{
        padding: 25px 0 10px;
    }
</style>
    <style>
#SelectRegion_rdPeriod {
  height: auto;
}
</style>
    
    <link href="ui-assets/styles/plrsheader.css" rel="stylesheet" />

     <script   src="ui-assets/jquery/jquery.min.js" nonce="CunfbfwKh0FEGDlJ2wDAgA">
	</script>
	
    <script   src="ui-assets/jquery-ui/jquery-ui.min.js" nonce="CunfbfwKh0FEGDlJ2wDAgA" >
    </script>
       
     <script src="ui-assets/sweetalert/sweetalert2.all.min.js" 
        nonce="CunfbfwKh0FEGDlJ2wDAgA" ></script> 
           
    <script src="ui-assets/scripts/plrs-custom-v1.0.js" nonce="CunfbfwKh0FEGDlJ2wDAgA">
	    </script>


    <link href="ui-assets/fontawesome-free/css/all.min.css" rel="stylesheet" />
    <link href="ui-assets/styles/modalp.css" rel="stylesheet" />
    <link href="ui-assets/styles/HightLightFocus.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/reqFBD.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/tblbrder.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/lnkbtn.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/rdbtn.css" rel="stylesheet" />

    <script src="ui-assets/scripts/HightLightFocus.js"></script>
    <script src="ui-assets/Pgscript/reqFBD.js"></script>
    <script src="ui-assets/Pgscript/MaintaineScrollbarPosition.js"></script>

</head>
<body class="bg">
  
	<form method="post" action="./RequestForFardbadar.aspx" onsubmit="javascript:return WebForm_OnSubmit();" id="form1" enctype="multipart/form-data">
<div class="aspNetHidden">
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="5/1VgjX6i+4VZOkIBUSSREc29FSCAefVpA3mJsKjdcbJ84U/mX0mgziFrWlbGOSo2vgEdFEpWjz/KoodCZMXOQ7+74hPGtxW+pU44GIB5gE2hBC2rE9RyKp2K0+LDxFjEvEcFchpBz/nvc2E86xm/UqmfIBHfXTXbfP1aSt/sLPu7IrC6MtTkH/0BqInMHG4EGHENDBXxDJ2gVbyHxYh0JPvnsJWWbQlDL3Kt4aU/E3rBXzR9mrf+DqBH40f7zsAff6OiX2KCBqqyO3YfDTlcFMfZqs7nkTTpRgIUKQahkCGKRGQISzhDTyshif02n+avzaHY7/bLZS8zVkMwILNoUXpYagy9Q5+QY5X4M2l7yJDRYxJ24uivoEyBbcvmT6HTA+7QppWQ5MzTdI3pinnXRMcRWbiCyJyrsp/+wuCyTtFAVlcwoNN3cUHJg8A7iGs3jp/fJAGbWZsCs2bQN+sKF+SLwolyXwcKGMjr7OUIk2RwCa5nvRKPGeLQg67l4KpyqlqhwDUIIcFJoAFBNSLeUeVjav3zsvDFP6+wstYdhOBlkeKLWqPtuDQzOYuESirr2bjJLErXMPjjAGy4q6XnVVs6XoBnVdvOyhEEkXDBiyeyLBXJQsp010VQZnS+NWAyAksCfhKDKjTLq5I8U6kXQlqD13aHFge0CrLrTvHfJwkK8KjE247Agkd1XZjtICwjU8//iLF3WA6tNyLHq7zp9w7SHikio3THxji50sF8R6tuTaRLDQB0hXmqtYoYEZuG0M33+7zQxKpdzFnx8XbUQKPqnbMHF/baIyPPTypym3SXmDaThnGw6mSM+D2MRsZ3HH3QkEAoaaiPrNnafMri8uGcrYoKybkXzul9ckFJypf5dFV0GeGtDVeoVp5rf70ht/zvS6d/T+3NQrKosSe7iCP6zGDFaurVZ7QV+mmnCAWKYz8FpbqTWzA4LHXcyc33NdYH6XFwWN2iqa+Lkt7Mjc3nl9N0y5C1982HfuQMov0vX+NWwkQxCAPvEc92eCqtUBI0cHKhXdB7730Ty65oqaKsWwaBMOKtImPr1tKJTjJ98jSUSUH+HrhRAsr4e4aT7BsTrjUnwHvYVhVfi6rJGniMVCFUwe8X8NM6wb3kUhjHKBs/hpUoEHzNsV8m5s039CEIjL5/y02hgKLczLwFdp3q4KSR+o9wU1uGt37n3P7FRxTVCLcJf8juU6Azn2if9qWufq9ZIs5kOqbw7jXVnixR2GHsem96MZbeeovmfU6i0lLizRb8dRPqYbzigeuzCqyu7RHKvqwc5jfETEXzoIspThbINmz1E42jK6L4Hi4rIpMN32n8ErWK1Ap9zOUt0E+femmtAIWrKJT6EBZT3bqTV2IAsandeIq0BVC4Qh2zTtNTZW4S+xHuWVCU8Mqnqfo/8U6koIweQMg+KmudvgqrxbdEr7Tx+eWoak8pjoOwVYe3DgWL98qLbeoqcsMnGuIzwz4dRpbQb/1c8j2KZiH8NRL+Cz9pOr0MwggBGTBKwlnopzubyB/U1syrS7oAjRODBDMNkZdFlTxZGWQv/Z+hx8XnrIx+iMVcNpQKLzOMqbCFJVmoCRG+hsDm4iU2WlXc1ssi7UDirQqvu/BGd3uf8KxUBCE11TzdWXBBk8/GV/WCtch7o4E1p0ktRVG190WGGFYZFNSk5N3ROJc8g1+Q9qUVcSP2hd1Tooa5RAo4NGRoBo/td32MSGObnH4QohzcAjlirCToLPYMx628Z7YLa/8tuhuPYtldsM72fIJS4zEVeZwiUMsxjGY3dX3+s0I9QDrNt5C/31Dkuc3v4AJmcZUrgZ6lkXdSU1tKFloEIL6Vp0hivDmCTQgPNKAuptIvwZ+jug/S+KZOaEdT6jMvM9dP2Bea3CskiPq2pskQ84JKXBn0C3YouQKOmW4fSID7dgHj/yLIs6Y2q7eSRuDrufMT4YdKNX6dKMAakj10r3dOnqX4AO5XWcoZFlNGJne5Pz1ctwcCDFMHuhbvD9B8KLvs2ecKq/mis3WrHIP/pAB4PHNVdy+RAkwD3iMUKIZMR0l/yqyd7jkkrdfSrUOaT4VfazeP2yfyLb/jFOJpF9nxOHV8sRNMfI2eGH+8Ws5eph5mQlX9cFZ5mHD797Zcw28hLJKx2YeZI6SKIhSeFjEfc0tEOseWR4b3Lnm6hoWpRJZ+E74BkQ3cyotP40kHE18mmIT6WG3Wad1G1tuwxVKGIp8C4U4PLcBWGGZ/Ff5z/Rq0G4OdWkdBDYU0zDVyRMlU4OngAd1XU+uuvWF4nlMJKCjI4Qea79yzbfiZLyYoPmBhtaPu5zzdXLul1K2klnilc2PZ5/6au5JrmNMnS9lNg3iAS2xxXbHAVuolaafAQ71n/HJGWehoPYORWOJA+xuxca6l6QvMzfvzm0mtzFKNuoiOFua7r38FLTk+11pVV/PCS/smo9s2Ch7HDb4id9SinW5XJ9ZqN2P7XSMwWkjgfkKxpg9aqLVYg0FnkkASVawBNQRJg8R5NDuiFzyW10y7RJLugUYmTAumlof5+vV5F4Zv+lvHS1zFSv2WWUnNleXGoQTUPpQTW9Ih8p7qxa1TPJbJM/TA/EZzgh+TpHU+0PbdXZT1oPvMiIc2Fq4uoQ+qbu3JQI4FEJ0FLWUnTCPZksiU9qPP7vxb/JzevA/LKuYTy1kjPyZH1+l1hEkwIxjgo0NYIyWtXk+Wz7X1hT5kvT4s6XIeJsKs+P9/xiagO4vb4xEQn9B6xrlsM8HybabmSLcT6vi9VH2/rtwiFlX+sTWKyU7AZiY8E45omP9t5j60iG4OewymvF/3ll6pk/k4pXcqPfnNXPWGcA0tJYX9VsAuZHpEP7yUJvkNnC9em7lymIDMtrD0jG0FtOos90zoe/WZYzqCi7nyPLDCFmVbNpuJ8aqCTRdDV0wtHKL354IiBu9WqYVb8heHU9g5DVdC3qhXQYCnQ3FKRm0o84qUy21x0omRqY3PrsVc1GbIaIjMUALlwtsfz9iCfSxR3C1dS8PQwrp4Gf1RpnKExITkZth31a8278wVBU4jp/tIGy2ZigcbVqT0URA20XUh9h9UsnOf089XKmpZ39wnPIOnPSMPB/pbl0EIYPIgfqLGAyGOxBcGTO0XdFtuCi224XRnMxKQYEwdckJxJTX5czbD0jHS1ZQSheTo3D1fI8fTspwSaOegs/CrFguz/6Wlxxzgve212FfcvJhyI7A11k3d0SJ71R8PDVJYdQFfdpYtv5w7TkdjfTgGETcKR7fOGP5jzve9Dbw6YJ3z9HP39pHNULItU/pMcGZuuQtRcKmpHCxqMd0AagZGay9uoRZFqi+v39QWAglzjgQYEssVCplUI3gaTPtF483NnfNDZtvXEUqTipHPqxCbka+KWgyVy6NN7WQYXIqAoH4dFuawXw6Tjzn1SdYjj/vCPwgaeIc0KpsYOTV8zEherajOchjUN/lkmKQ/rqrmiDfMgyvFYNZqk9CZcS55jmcWUKNfFK3j24ykDUA8gQnldPYF6yiVkyMB1R/hgoJ0bxlNYCcuUgjJrSHHN+13gBB/c0/0ANxZCOAnUyGhsQPsvqDhL0yQzDPOKzKzY0cr1MNuL2/t+gyA0lzdWiOmPjLU0eRPAwW/W/GDBn4YJHeXF5PDMjJXFPsybByheoRdutoFN8JVv9AlLrWsNW+8gK/g4glzrAt8UnRcxSvqr2S+s96rWVnGzXVvPF6aJIVCAI/U9X24Gbt/4ZgcxOsJNYOz1hh1xVm2/thk6RcgQnb1utXme4YUUHYCbBpGz5u3nnxvFonZB2pEZt4SJtIFrEufNQNVVJphUb/UpEQVHyDmXaFSdgTO5Mm0Cy7Q8/WslcEDrm2eD30qOLL5Z7WjYN26vb7kV8+MAatSuLgTCYUZOTVolucC4pp/aMh05QjEYVIfaGs9vutOQ4eK8+ha+DF8kPVL1rIfVXaopCS9OEi/sjUlTIdT8LU9YP6v7xoRd2Ge/2Fw+xubP3T/9SAb/gGQAil8b0mwYtRI+pdMMBtpIzhB9wJG8J/3geBOzNMHyviRyuWLgT35QMplA7+RkedanJC8+mUgWK8wAdaZMcH+7nCYIGsRCUNqBGSC8iBpRIUsGHb2HC+o18sanbEwFFlzRFMq5PXKoO5cnuaZPH//y4JIeRI0c4tvTnBPtgHjf2/5XQgsqNW78uyErJM0wdmFIWoXZ+2oleWXyHNBTgqRhdjSzlWTQb2oeSPAPe38DcchQzrxp7/If5f0Q5w8kp4Neuh06TX6RmZkW1GYg7JX3Ak4InPpPP3zJ3acwfQzvTOc9iVV0bToyagZ7gRiboOJ2QS7Md7qRAByPq7FqZFSI+wo5o4gmV/mG0eFP5UkUuibu1Nd83js/uxRCIUfW9zwRtQqOWP9AjxZJtVDwY0BiVRXzVNRWYIi29/SreXWJ6Az2lSJfSpNyFJXKfvUzNbjpR58IHw6w9mMs45t9hKB2xtoblmsQjPC0cO+UD9HRU//D+L8w22IUoz8fWJxR9dpKV+psvWD2aliLpgmYmVVTSYOIN6WUrlcCg/SC8gJFAW7q7PCV5UOjtjluKIitP+4h1wPvI6xAZTCQfd9eMC3j9A2o4lsULmo8e/zjWmjGp8sP6X/4qztAH+pz1bPHZz0VEriqPZXvmkRbAc2ewm5hhDbHBWXi/oEdAfc1OfDDAMSUsYA21pw2a9MsShoc2g8RKswPLVFpLZx/D5eLSaz3G5ZDai9zHA/MvzmbD6C0ZSMNruCRd5NH/ItfpicsEe6G12orAG9keuvhsfe5YSuI5yYkG9yA6/rC5ZDTpQeRDiBXM7wc5dlcoIWWdI4IDIPDSAuMersjsnjmoQ0ws+4b/p8EeJ8lr8PCAp9GVS2Dv/QjJXZeFZeNd+jwJymEl8cCYp3f4E6fYkDP6lAx5kfb5CBAHM9HLGb0rENJL1ikWDzpcWi7KIDj6gjepctbn1jTZlgZ1vfDsMmkeVv8GbNVbJEO5MfQ7bzGtI6+a2nB+smN++0OtpYNweL6yHInN8LfP2hNDiGphplpn00av0IQxI7vHrpXdy2mXT6YaCM0RwH7aA3S9jQexUjt4lBR6gC6K5rZq9Y5vhqicX95x/XKlx4IkgxRd+Lm0Zox9UjCczTUb15XGEfthZi694ERNkC1zUPUE1f9B1uLWF3qGsv+6rj8fik2BJmQDMNtqqT0t1ImsaaRCwgdP62DpOlAR6znwjyVQg0zNyPjoOO0mGt04sOalq57HV4khJEXirnuUAe5aOQ31c/7kTIVxCQosF/bRg1mxeoS4N9UviPqOgAwKZIzI6mk6zGv152+K3Xc76OzM9FRAy6UA/MNbENx+4aHTd1+j4Q8G90m+XcphN82zX7Pu8n8yv34ucLPPJrmwuy1mE/vaZ2RsL+S0hYGXtb0UyAfhnC9PHI9bASO65KxoXu5bWXA5LgXYoj+M8JJOEHFN1PKTsgn7ao/Ls6S+r7FsqdmBmIudYZUW5kWrx3RkA5SvcKGKv2klq4Nsu2DG//pqQzCLFN+oloq5IgnfCA8Q5bo4SCH9VfcHn9g3z7U+DiaRAe4wThCZc18GP4LQMBVpyApA6SIzb8dSLeiCMvzu9rPxnp3qPHvUy7fptjjEEmsZeG46wk0q+km+8qwp11CDF2FtutePUvpP8K/yOwMIjJi2rJbKiNaZbS7dIcKwqEPH9Vdv2DDPfUFNi5s1Wgap/80M5+bVAYnR2QmWtTa3NtR6PL3NYkKbg/uxdMp2/eZH9o6yZZiNlmC5xL94P3Cw2PxqjubVDDXcFB+MjvBBh3+vpGE7aRW4ijf6aRaDEuR9kI3Gg/PdVWT+rNi1OWLpNwmAWnNco1c1HxMk1MWpB3uRLawyOlhpZ4OgCrZ0Md7l0KsBgXDiPOyX0NKmajE3gG/JVoDtFLUVVlpsTdH08+Td6aM9Dl+BkgurDGWm4Bu457i01eOcMpU9lGtbpHPX3E+qxao69o4wF/g9VlX/6meZKvA8iIhhFLMkx8PWTQvZA25/sY47WcpDulnrfZWusXc4ECBAKtITVEibwOvVj6KVbVDP4/06MnxW/Uv+RDfMgj2foIjHVme1z8vzKq2IfxB0w31LYWMMszNJdgpKhfkR/WYv3z1Fvy111xoEX5kDpXaMxGazBWDmm4SfA84ceMgpbaDRbSNmNyGAy7RzkZ0wg1VayK1OLJWD7SRhkYjEYXGM6Kz4uUU36LFSR98VQTvBiseQnXAbG5sk1vm/YAoK5w/Plqwo5TFb+LKRb9GKIrONdnZJm7cCXWyDWVEdsDUiBZ95uk1Ppb6RQHLW7Tjz5X2djkL4gVDwLJKB4kv/2vZtLbi/rCbd8ncbNDDAiznjuOi1Jkf76yLgAT0l4MjsrQwCr0WmPh08ddKWiLa2fJ2D9iTsRZ75CBekT9bgobLVLev56yPdGu6CN5h3Uk8gpVUZ5H236dv1GovuwMv5JPIka4q8nqvR9n7kqQSXeV4tTBcrSsMtVlZjTlSy1GUbzaRm/5l55pbmfaYYIZP0Hbq76dGNsm67ttSZzcle2PtEpnhC+eiYQRAMaJvKM7Mh55/v4WgFTBDSfEkgARIYORVw+/lnuvzqCqFWBALP210yVmaavqfEeNIcysWqd0HmgxKWU2cZXslS3L5ZR2v8mhUnXDsdTeqa3oRgdp5sqqTzh3ciHn6F+cXRh+0fVt6E0V/QvSLFBeAEx2oy3jDT8fdXU86v2kW3Za17yBPyKboJe6GGOH2XYRa64Wb1CzoQjWyrw8PSBlA2Dlo9ybSbVA1yFEjFiCcU6RZw4fdfaa/hipG4Q9xyqjPJBCwXSUeGEMlL919pcVw5L593uU7+GOIZhVdVaQJ+yLSXJ3ThwU71JWfS9sdQGsD/dMDwYUcCqBOQX0Yda4wB1JowfNHZKq6NDjoFI+8jgPDsGjwzX3GZpmYWMFwh0c6bLzVTIhL83vtKB2bSuxE8zf1t7WqUJ1QARzVIAk0Xq/oYTMBvS+iHWCAKrm0LiA2polbg7UKbg+yw935oZ+k2ZwyRd4ouXEIUw/9zHXlzXN4qY/Rdi1Mp/aODMPCPdOtU6BgU7D8cugtW77A4lngoNHjxYIc9Q86YL1onMVlcywIgxnlEp1ywaYaqGPfkPsb7npXhZjpYDmEcC6CdWdIqYczwW8ehQQiMOwHLi4oSiP2EFlSe8HiRxmCnojrgI5roUNh3bjDBBJxjicxnZCEP0Jmwsij+pmOaHgzQ4wsaCKC4JR1esp0seszfEoYZd8p4skt+YLNagqtlgAKOGPlqwlc+weX0G0o5NkJQqXKsX0f7fqYGBcEGHAnd5wgrw0a1FjWzQs4MZweWZp09J15xot6ZuuifcNVnuleaE7nDe5RcL6hX0BK8McsW/DHuZk6Ncen1BN5isbf9zubWyhQjCj3Mp6WJoR2O3FmXZDPc1C5+Aa554hQmGI4LNGuLWzsnA/J3M1ZF6dZAizyt3ytyOfOmwvATvINN8NUHridXwkfyv/W1iz2r95SQKj7enG4nRFzZYzuz6r/OSkOuD1y1invllJYEl9YZ83ekjWGzt8yp0WIOX9lsfJS+asL/QxhS8VEMmnWA5eObMgCoY9jtm0SNRe8fm7Cdz9t9ODSesjRCcyIbR/PiN255aJnFLwACS6LsWJeKjvXFl6YjnCOXZzRZDQkpFJmswWe6Pig7Sl1un+Rt04TrXtTN3sLBg0iVX/RAx+BMhbI/cX/BZaZjZkxnvL++tmzEP/cV3l4WDqP69xmZypw/YCG3iQNXx6d2rZCSeAiUcKg5827FHzVr76MfVWdhKLsaX5FvS2YKwIA/Pb1Pd+o5hjHfMBo08Rsr4tdpJxr4VEjr62QzxGR0FZwriqPndE4cNhpuaYkVbhjDFptuNUlxrlSgX2Tdnj2y1nFZI0anZRYj384vU/UsD9K5NJo5Mp61F8JWD2C6F51TKIQXRf8P27iGPCWYpW2lPW12f98EIfDhAcGz3dEfd6/FQtcWrwlfzd4lRranfOdyaaplcdac9V9aOznbIcqORZfgq9Futb1YDoEi1cpKqkhai886olwmHid9KZL1bKGMPT4/yd4CI9au/5/t/dG8LhVxajlcqG4HMoubIeuGzNRTfY9b5V9Q+rw7nLNF3Z3ZKLA9ocB2ZO9ftt7ebw0sCYitwW7yyFGBpT17uGFP1Nhd9yHudSoSX/cC0G7saxtYfDIzE8ss4sowvWzQcJs6JxrpdfCF2LiT8uDenq8isgMhVgBnJhCSNJ8PaQtg7b2nQ9Cy1VGgJvm7ObUFmnyMwf12ec8ClLNbR54W+EwbGCm71C/JGFjjvzmmopZeRN9a4vzmfg6isXobn9AZ0CaHmaAl67MevesH4m+1tGDd+dymSk0DV9PeZF8nX9u+c/JCHVykI0qnNL4+hONMDohVAnQT+RiqDpaiAoBxdw2wOKwaFZWpdrPjJBBW4gU/hFHHDfZUo41mR7BhErMm27o6z0TAcnEQxB4RIbxTlFWxyLHjQ5hFObaxdob2vbiRRyQCpl7+wK8J8hfn1fUHhyJqCUjuil0WJC0sCuL4U0H1OisUEY/jH5JGp7s8CxPe0WRd/j3u8DqDP6iyT7LjaipgE6eTOnYImqPyEqJdQtSbsPu6Vb2RQhsd7oIM0IPftnGlOGda47gK3EKVE49UDBNy5pWmZIOroorhmuVZf4/B+GAXUSTXoU6ZSh95eZXNZx9D8DrEh5t8lfp+ixBM0wOAg9WglVcyoeM958OTLYVDVGmQ0it3cIZ+cGP8dK9g+5RJxwcEdzaO7HZz2Hy4L+xCnLR4IePtSRwGYZ+H9JcZ85q9CA/ivQl5MokphgTlElsUKT+UqVqta6NZFdgcqZK8qvNDDn3XbDuGt4FgVrPn4TsPwqNUGmUN8RAQkYGlJDCBrMqtaZcdvzsmAuWzxcSKrSzbEVCAoRlURPdF0nkJ9ExFXPUaUt+lEMvD/5mTcm+qhzeykNqIKMmPNJjGr4HtRbyU3+tW7swf0tg56JUvgazQlzYmlJYlPeiMOFp6fO4nF91Qlke9hmPyZvfkQGKBT8LuV5Gxom+xsSjHM5z5yMfifSFS5ylY6N2yVXHokHIUdlY95dgCr5hR1tZo0y5EXVS35owwJqHVt8GPk14yUVWZwgYSZZkUUElWQTeC4V4RwOUuqaFrlAUNbxhLks7OBbiAaNC6pFOt/MzHIfB/KR+wn4ZqTYq8Fo747Vk6Cbo+7XzMpeBuajcexPQeQZK9WZpNf9TtlX1vpf66yMmVsabKRXveVF2VQOODVFVvnuO/CXjlQfaFNcAAxmyWbbkh1FQyiGpdN4tzs3w2viQSSD7cittkZew/awGA8vWZKwZibJBbPYoNQ7a/YDSNPmeaVca0wnQgeUulJVIYSqVqS/oYT6x2cKKhdU7ZrF7F5NLk2kzjO8i0oBsRlUw9xf0VQDIdrLpyKXemj9y/il4W+KN4bngkvM404xmIU7guWUKQ9D0OCh3It43vvUnT/exXho8tQxeNhZ8d4oCjRUcu64MP+6ftgJTSsBNbqKFYaV2+hZfJ8WvY8APO3Bb0Pi4VtXrBe8H1hOFIKidc9sSsree5+wG9enujupD0UHGOhvHA1cKiv9rDKTNe32RsIWLWEDS2KTIqdKyu7sefA4KWYhihhOxyfDlZPCUi6vjWHiY1yOH/gxvBD48XxOuSUgnosyfVVI79t1i1CcDCp1OEIAVu/bYYxSkpJUMRH7mxdChCf0CcEA5XEEEQ2RcZGjn30it98/Pucfeb4nW7JHV14+YeLRnc6I2EIAo+Ak3SrgWRRBkD7/2tzkp0203KiSg86WaVZFwJoXHV3tx6/5Lme/ysg5WSpt8ZPcqs5THyZhBXhtBqwZOlWC5xEXN8QfplfbTz6v2YFCyD5BnOnyu+F81rC8p8t2XRa/Gm5asUYUj8pkEmzkx3l3qrYDHvQp22MF9a+bPnafD3v4+xhAttbqQzgbPeid41KlotFLNyam3h4xAM7yySTAvkbX/irokc7gnG0IBZFy29vVx4O0AGIu9Kx5X6aG9R2GVrX1WdmT2sF4Ui2jMRqspzTUvAjE5MNJKi6hvCTh/eaJvWrtEMm6M5gOopOKdWt2X9dFcTCyykj1Pk2OrziwDmkSmGhXvmCPUKyDV0BnhDxeFs9Z1ifIJZoek27jQ3pIapKTPhl3QLH3tl06ExtNwsKoUXzBVEjnt2xfzPWhw4XvNqi/7/Km/2I1x2K5SHwPDuA7TRNJjGkLPlZ25Wu1+N41HuPY4iwKiD1Fszpvj12JoCf8Y/kxHIpjEPKfcUHcYQbUbzrnQyJ26FOYyZ1Occabr8acQHrhSr1nUzJBNQIbSdYgMz9c/jO8UXxF1MhAlkqpOaMyubQ58GORVT90eEJ1ozA0vt3FXkSlLpWONp5idfUcWR95Zmih6uFyefisdwmkjErmW7Qh/3/SApBrueokHcDVd14HsgGY/34prCxPFp0fR1SLFjk4Pc3hg96uWW1zO7ZzCxrb1P3CqtJ7j6VQUs3lEhA1STw+8xf6YCz4JU87n9SdXbp+7+HOK4RsdVPl7OSKG0GxGZH2CvjzEavDhgrrbpeCawYQFgNhq6Tm9TOm6a4DjavdyQiC4JHbdu1yIWRq38qE/j8eVyhoi9iw5NVwKwwlKdSzwoSbzTKyGclXTyr6yyt0dRVOFypV0zG1cDZu1n3MKUeOLCa9xfYzbirfS7njUeX76aOts9xtqHWR9h5BZpsbOAJGU7lKXWzTb5jR9NSgJgel6oU8mRWkbO90W+Wmdl5k3lfQDUr93ODW9YTKdSSy0J0LY3PwSdkuipxZoXfz0wQjETtNexZfKf66GHGOpLAVJjfGCOaXogqCJUUp4KPkJnnNOOLngcRZdq3NwoUH2ZoXO+6Qtlw62mHMOlLJ3qjWQyDNHr1ppJ9foZNIljqCp0sI8lxJe2lwQZSbYHmMpgCEh0jBASxUWyjicM5aNoAzd72cLkcA6pIQeD4tTp1d6FEr7qREN2EQcI2nfiMTWF22TEMIFAcWJO2L6Cn0w6hajy8EZMZNmMLGay8OihujlzFbKiRqiswW+oQdLnzD7lNIR0/vqyfg9RaQpbp578N0BSXVtHPt2/6WL2RhYZMp/eHiu/RuSUNtDF7DEs46rSHJKdJryn69gkRa18cEEQ4OAmvtQVeAUMGAYXyNRMIsoeFi+VOkLe/S5gZ9LJxa/gdc9UwlSMALJL3hdYCxTQxmq2xfBcEdPpmkmPs5G24YfNutq9OoT/77P8xJtItn62GvWVZmoD21Tntr2wCo07h9EsoQPih+99IV+/LRIPZtTgHIun6/6VAYbhudVoznxe/arxvoC7zdfd7w1Rq5sfdSLtJEpOrapTlXG8vAuGPEXpxH/+k+1OZxnf795POj5K4D70CihH58kJu/2smbnZy8rPsjvSfIjRw0YAKnHr+omAOzOSvGQUGwiruiKBsZ569S1AIvS9MN8pSfnLyn6BWn+ALh1jci/zkYM7XKLFRhA7kFcyaVcO9z8UZMjIDZA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZBbRI-vLFGPASeYxh_KgLGJAGhxxxQHaAFUowMEJ38zbzJMIHhOPM0QVtz7ClVSrJw2&amp;t=639202794265548063" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1HoTsDJCIwegf7-cSVNQxKlxqJplUAag2gjZMR_ctGyeKzMDbl61mq8CG1bXK2cKIO5F_d_eACHU7rvEovdRsHjPwMxL_2RbhdHxnXThSzdTd55hY37B50zmwPwIsJ1FnQ2&amp;t=4623e90" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvqBoWBYTDUGuawA_2GYbNQlKfMSt2G6fTRv2v_CvkMQC-NDKOxcBHZBsr4m43UZoWnDElLWlfRSMae7wFN5-j848Bfbquym3Qmm_a4KPTP8MlNJWDtdRKeoXno9ND71Mj-dmT4RATMPqWph8tRm5et41&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OAh7tEdde-lvG3-30egxXz8aAgw_K6hDRuGQnL44pJNvGX0k88IpkhwtBpf_hp5FI_xl-S6IOzDAoSwTftgBkdwIVbozv2itakdYRoj6lyvW2iAmc3lxcxcAsYCLcWBMdMG64QNAlb5JWK1NKm4PkKk1&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=eE6V8nDbUVn0gtG6hKNX_FhBCrEodp5vWm_YmsPN6L6kd8QLjOqCyZgy7R07cf_-q6jt6CUudI9DljzC2TdIySTnrKddg3RKYGaYn4SUdM3lZcSR2HeYBRZYoT1mfgRe0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=mcAASOSteirJeuV-3by3Udl0BXtV-9r3zqXldfMmh4nMyRrfOyOUzm9PjtxhXMnCb3u1w9Bl8xQwuZ3vJQhQk5K_jbJ7TUVZSafdbK767TU1&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=jwf4VSQi7LeShc44FJ-gAeDpDtsq5KMQ8v0UGSwL0n57o9DwezYikDFx_PyigWyXj_0OxQaznPKYQt6DlIveEltbNvWSF7tPucSRMMT0SDIeemWSUwY9H6muRTmCFq5y0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=nai7mGcYyE2dix_TwveLDUh5s-4A2YxYW54tIrkM_TUunAGPTDDQIgTi7_jF0ZDsXQf2DAdig0qNTG97Zho5rt0FlKu4f2urbVFVmxpi95du0q96Rm7avCmT7YWIJACc0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=yDT7ulzE00Yqzs5zd38bJ9uYK0mE0NQaZIaf-pwWkJgWYgpXpMmyr9X13OsEF0tAmtivqF1lykUd9zGXXG_12HtYlW9Y5ThEGbuS1bPsUkjRauDlH9wZ-Gg0tVnmDj270&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=HEFpVKbnoeQjkjHkFKu3MFt9ri5W5MnThyWIA17NLksVbAMJb3b4J6FUWFjTqfhe62vQzBBryc0D7vtVE9sCvRaBkQXkkFQdNC1ak54UhzYYY35kSK400VtcrgLyqWDD0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=5ib3lCcyinHeLQmkwMF7EsGoPbLcoTPc-cgtukLJYPUZaLkkgAnENQdSi8NDc4l_BKxYZA1H9k0706BHQRpedGJsNRjKTrwz8gPmzzA-oap0ysiJ6VwrD01uCYx37kM30&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=iON9Jxe8QCRam1nkdNLgkffrRZCMCj6iq7qHWPZc_e3jKeMk_XnmxshFxNhoGH9SwE5Oz8w4xs83YnQN2PvBuUDeB4qmPOBf6C6AjLMoHrEWhVT0hkNgKR3X5v1OCzxI0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=xGmPTKfsNy0_1Sr5I58kO5DASLN2udyuv-7sLUq5_rfvt0h0nqG8q3lnLwCBbElWqxPrkky3q5vq3pg0VXsmEcTWWXMOeG7FgMUlD16VLKssIvRudHPE5Dua6R6EOhY40&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=LQ1q2RBSthBAZhliMjtG_6LMhlQH2DbcQYgRKlCVjFIh5IZ7GFZUyt66Y_m4cqI1Qb8Rf2oM6HCIJJLQ9rSBDT1GrsRxo5ZypZQOZ1maIbKPmaC4yLryG1OCPsyASQdm0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=VOYD8Xe7kQA0lniBYXVpAuKo3oFKAyHWpDt0JH4amXNlZ9J7vLHsxoqoc15eTAjA6oglPYd0zwAK4QpQdtZv0jvkOUq5Z5is2nQki9YITO0skfivF47CJZD_3wdgAEY50&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=hOeJu0xhC-uW6Gf8ooKdXldiqMjTwkMrPiRL7tfxCMAYgx7LQGO2FKVjBYyeRQsczHJO8YrvOhmAf48uwtZEnO4Mu9oj9tlaZBV6uinaXInS4irYgdmuHH1_fMK8aVI10&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=XlV9GqTk6b5uqDuL38kZ4M4-D19lMtmt0Nfm-OaIfmfKZXxxdkEy0_fz8Rb50xJiOME7ruSlDELDwr_q88n93Z8DbpgP-PrvolSTi43wrxjzmVSKMK-250V1wOfusJzQ0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/WebResource.axd?d=JoBkLzP19aTuxbWOhHobYndLm8rB8C7w5JAGcozHelAi0yxlDEHXqwBJPZODPDVe3kynVZnW81KTBhLcr2IKvw2&amp;t=639202794265548063" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="94E54D6D" />
	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0" />
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="h559Q3peno6orsLxu9zAuuArK5WBkwhrKLWyBQxiHX7Bv5HYlP2aeuuxXCvFQ46lhFkvkBgOWWjkzMuLoQ7mrTrdwx4TgCioEY2esfUfrBVECKCQf1BxOhrg26gDWlLC2X18YUuzdgV4FfZpXsxyRPQSCSJy3Fg0ehFcLPH0gx/7EVXTeJjvph4QFQUiEI/WPZsuXcWnUwzT8PUsnPU2J6hSWLdTjP7qgLD8OThJwdwgKA83KpOiUmYBZn14B2EYN1aeM8/9TlEwJtlJ8YAoKKaUJuvxu3mGw8LrSQy2nyCLmheBnagDQqnGPw8RxSUHpnC1XCFU4XvIk4nLBngdxQxH0YFI/nof5FHP4YOUX400YnHfccKvKre7d9Zfm+XaX7NhRprQ+xSPRsdTNUGib0bfXTiyqhY44wkqpYSB6KkNl5H4LZtJhpXEPiZ/d7jc2H7YHWU/OdntE5IvtqtD7cd3Cpj9rdR2ybg8fVXGH9fxFPB0lMNtYs5YelN48Wz9F6a80xhOhsmrY1+o16blLuKnaUFgWzb63AqekCCK7TCSIDPnkQTgARu3ZxkgIwf/vbU8BPRLlA6vrSXDWwAjAqm0kcg6Sw3uU5yldmhlkFODsLhAePUpS+DO5H7oge4krUtNcdaKAz3L3Rck7QHwPlopVo93sk3SX1t+JSxtWTYJI7H3zJQhzlkjLKrA2UNgr68WcdUj/lt0f4MFNyDI6ukpoxC6A9GGnXJsjAdEQX/4yh4ikMURPd1hR9FFQES13p6Ki/J7Z+7askoCSEGlnByGg7e9TwnpUKyt2cBCxVj9UIfPBQknVAICd0ZEwO27iAcz5AgQ4ARdjEcoYqVmUvIyHX+ZfkoXxE9ZDHmvLbJREmhRpZqsvjaKKv9y5AOjj82il26/ZQW3Po+5VXEES7BkslW9au6NtgqU4in2bnQ=" />
</div>
           
        <div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', ['tctl00$SelectRegion$updChangeRegion','SelectRegion_updChangeRegion','tctl00$UpdRegion','UpdRegion','tctl00$ContentPlaceHolder1$UpdatePanel111','ContentPlaceHolder1_UpdatePanel111','tctl00$ContentPlaceHolder1$updtApplicant','ContentPlaceHolder1_updtApplicant','tctl00$ContentPlaceHolder1$updtForm','ContentPlaceHolder1_updtForm'], ['ctl00$ContentPlaceHolder1$btnGetOtp','ContentPlaceHolder1_btnGetOtp','ctl00$ContentPlaceHolder1$btnOTPVerify','ContentPlaceHolder1_btnOTPVerify'], [], 600, 'ctl00');
//]]>
</script>

            <button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-topD">
                <i class="fas fa-arrow-up"></i>
</button>
<!-- Simple splash screen-->
<div class="splash">
 <div class="color-line"></div>
 <div class="splash-title">
 <h1>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h1>
 <p>ਕਿਰਪਾ ਕਰਕੇ ਉਡੀਕ ਕਰੋ ਜਦੋਂ ਤੱਕ ਅਸੀਂ ਤੁਹਾਡੇ ਲਈ ਖੋਜ ਮੋਡੀਊਲ ਨੂੰ ਸੈਟਅਪ ਕਰਦੇ ਹਾਂ./Please wait while we setup the search module for you. </p>
 <img src="ui-assets/images/loading-bars.svg" width="64" height="64" alt="Loading.."/>
  </div>
   </div>
		<div id="updWebsite" style="display:none;">
	
				<div class="loadingContainer">
					<div class="loading">
						<img src="ui-assets/images/loading-bars.svg" alt="Loading.." width="64" height="64" />
						&nbsp;
					&nbsp;
					</div>
				</div>
			
</div>
<!-- Header -->
	
        
        <div id="header">
            <div id="plrs-header">
                 
    <div class="plrs-header-row">
     
        <!-- LOGO -->
        <div class="plrs-left">
        <div class="plrs-logo">
            <img src="ui-assets/images/logo.png" alt="Punjab Land Records" />
            <div class="plrs-logo-text">
                ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼
                <span>Punjab Land Records</span>
            </div>
        </div>
        <div class="plrs-menu header-link hide-menu"><i class="fa fa-bars"></i></div>
            </div>
        <!-- REGION -->
        <div class="plrs-region">
               
             

<div id="dvChangeRegion" class="modal fade">

	<div class="modal-dialog modal-lg" style="min-width:80%">
		<div class="modal-content">

			<div id="SelectRegion_updChangeRegion">
	

					<div class="modal-body">
						<div class="row">
                            <div class="col-md-12 m-t-sm">
                                <fieldset id="SelectRegion_fsSelectRegion" class="form_ font-resize-scope">
										<legend id="SelectRegion_lgSelectRegion" class="lg p-sm head-legend">
											<i class="fa fa-map-marker"></i>
											<span id="SelectRegion_lbllgRegionInfo">ਖੇਤਰ ਚੁਣੋ/Select the Region</span>
										</legend>
							   <div class="dvSelectRegion m-t-sm m-b-sm">
                                   <div class="row form-group">
                                                    <div class="col-md-12" >
                                                		<span id="SelectRegion_Label2" class="label label-lg-font-size">ਜਮਬੰਦੀ ਪੀਰੀਅਡ/Jamabandi Period</span>
														<table id="SelectRegion_rdPeriod" class="form-control smedium m-t-sm">
		<tr>
			<td><span class="radiobtn"><input id="SelectRegion_rdPeriod_0" type="radio" name="ctl00$SelectRegion$rdPeriod" value="1" checked="checked" tabindex="1" /><label for="SelectRegion_rdPeriod_0">ਮੌਜੂਦਾ/Current</label></span></td><td><span class="radiobtn"><input id="SelectRegion_rdPeriod_1" type="radio" name="ctl00$SelectRegion$rdPeriod" value="2" onclick="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$rdPeriod$1\&#39;,\&#39;\&#39;)&#39;, 0)" tabindex="1" /><label for="SelectRegion_rdPeriod_1">ਪਿਛਲਾ/Previous</label></span></td>
		</tr>
	</table>
                                                        </div>
                                                </div>
                                <div class="row form-group">
								    <div class="col-sm-3 district-dropdown" style="position:relative; z-index:9">
									    <span id="SelectRegion_lblddlDistrict" class="label  label-lg-font-size">ਜ਼ਿਲ੍ਹਾ/District</span>
									    <select name="ctl00$SelectRegion$ddlDistrict" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlDistrict\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlDistrict" tabindex="2" class="form-control">
		<option selected="selected" value="">ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Choose District</option>
		<option value="7">ਅੰਮ੍ਰਿਤਸਰ/Amritsar</option>
		<option value="8">ਬਰਨਾਲਾ/Barnala</option>
		<option value="9">ਬਠਿੰਡਾ/Bathinda</option>
		<option value="10">ਫਰੀਦਕੋਟ/Faridkot</option>
		<option value="11">ਫਤਿਹਗੜ੍ਹ ਸਾਹਿਬ/Fatehgarh Sahib</option>
		<option value="12">ਫ਼ਾਜ਼ਿਲਕਾ/Fazilka</option>
		<option value="13">ਫਿਰੋਜਪੁਰ/Ferozepur</option>
		<option value="14">ਗੁਰਦਾਸਪੁਰ/Gurdaspur</option>
		<option value="15">ਹੁਸ਼ਿਆਰਪੁਰ/Hoshiarpur</option>
		<option value="16">ਜਲੰਧਰ/Jalandhar</option>
		<option value="17">ਕਪੂਰਥਲਾ/Kapurthala</option>
		<option value="18">ਲੁਧਿਆਣਾ/Ludhiana</option>
		<option value="18953">ਮਲੇਰਕੋਟਲਾ/Malerkotla</option>
		<option value="19">ਮਾਨਸਾ/Mansa</option>
		<option value="20">ਮੋਗਾ/Moga</option>
		<option value="21">ਪਠਾਨਕੋਟ/Pathankot</option>
		<option value="22">ਪਟਿਆਲਾ/Patiala</option>
		<option value="23">ਰੂਪਨਗਰ/Rupnagar</option>
		<option value="24">ਐਸ. ਏ. ਐਸ ਨਗਰ/S.A.S. Nagar</option>
		<option value="25">ਸੰਗਰੂਰ/Sangrur</option>
		<option value="26">ਸ਼ਹੀਦ ਭਗਤ ਸਿੰਘ ਨਗਰ (ਨਵਾਂਸ਼ਹਿਰ)/Shahid Bhagat Singh Nagar(Nawanshahr)</option>
		<option value="27">ਸ਼੍ਰੀ ਮੁਕੱਤਸਰ ਸਾਹਿਬ/Sri Muktsar Sahib</option>
		<option value="28">ਤਰਨ ਤਾਰਨ/Tarn Taran</option>

	</select>
                                        <span id="SelectRegion_RFVDistrict" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District</span>
								    </div>
                                    <div class="col-sm-3 m-b-md tehsil-dropdown" style="position:relative; z-index:8">
									    <span id="SelectRegion_lblddlTehsil" class="label label-lg-font-size">ਤਹਿਸੀਲ/Tehsil</span>
									    <select name="ctl00$SelectRegion$ddlTehsil" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlTehsil\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlTehsil" disabled="disabled" tabindex="3" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਤਹਿਸੀਲ ਚੁਣੋ/Choose Tehsil</option>

	</select>
                                        <span id="SelectRegion_RFVTehsil" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil</span>
								    </div>
                                    <div class="col-sm-3 village-dropdown" style="position:relative; z-index:7">
									    <span id="SelectRegion_lblddlVillage" class="label label-lg-font-size">ਪਿੰਡ/Village</span>
									    <select name="ctl00$SelectRegion$ddlVillage" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlVillage\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlVillage" disabled="disabled" tabindex="4" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਪਿੰਡ ਚੁਣੋ/Choose Village</option>

	</select>
                                        <span id="SelectRegion_RFVVillage" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village</span>
								    </div>
                                    <div class="col-sm-3 m-b-md year-dropdown" style="position:relative; z-index:6">
									    <span id="SelectRegion_lblddlYear" class="label label-lg-font-size">ਸਾਲ/Year</span>
									    <select name="ctl00$SelectRegion$ddlYear" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlYear\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlYear" disabled="disabled" tabindex="5" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਸਾਲ ਚੁਣੋ/Choose Year</option>

	</select>
                                        <span id="SelectRegion_RFVYear" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year</span>
								    </div>
                                </div>
							</div>
                                    </fieldset>
                            </div>

						</div>
					</div>
					<div class="modal-footer">
						<!-- Submit Button-->
						<input type="submit" name="ctl00$SelectRegion$btnSearch" value="ਖੇਤਰ ਬਦਲੋ/Change Region" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$SelectRegion$btnSearch&quot;, &quot;&quot;, true, &quot;ChangeRegion&quot;, &quot;&quot;, false, false))" id="SelectRegion_btnSearch" tabindex="6" class="btn btn-pimary submit-custom-btn" />
						<button id="SelectRegion_btnCancel" class="btn btn-danger btn-no" data-dismiss="modal" TabIndex="7">ਰੱਦ ਕਰੋ/Cancel</button>
					</div>
				
</div>
			
			

		</div>
	</div>
</div>

            <div id="UpdRegion">
	
                    







                
</div>
        </div>

        <!-- ACTIONS -->
        <div class="plrs-actions">
            <div class="plrs-font">
                 <input type="button" id="btnincreasefonts"  value=" A+ " />
                 <input type="button" id="btndecreasefonts"  value=" A- " />
                 <input type="button" id="btnresetfonts" value=" A= " />
            </div>

            <a href="Login.aspx" class="plrs-login">
                <i class="fa fa-lock"></i>
                Official Login
            </a>
        </div>

    </div>
            
</div>

</div>


        <div id="divBackground" class="modal"></div>
		
        
<link href="../ui-assets/Pgstyles/uc_navugatonmenu.css" rel="stylesheet" />
<!-- Navigation -->
<aside id="menu">
	<div id="navigation">
		<nav class="nav-primary">
			<ul class="nav">
				
				
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl00_liItem">
							<a href="Default.aspx?itemPID=1">
								    
                                    <i class='fa-solid fa-house'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl00_bBG" class="bg-info"></b>
								</i>
								
								<span>ਮੁੱਖ ਪੰਨਾ/Home</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl01_liItem">
							<a href="OnlineRequestStatus.aspx?itemPID=77">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl01_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਟਰੈਕ ਐਪਲੀਕੇਸ਼ਨ/Track Application</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_liItem">
							<a href="./?itemPID=82">
								    
                                    <i class='fa-solid fa-file-export'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl02_bBG" class="bg-primary2"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl02_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਸ਼ਿਕਾਇਤ ਨਿਵਾਰਨ/Grievance Redressal</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl02_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Grievance.aspx?RefNo=1&itemID=83&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦਾਖਲ ਕਰੋ/Submit Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_liItem">
											<a href="GrievanceTrack.aspx?RefNo=2&itemID=84&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦੀ ਜਾਂਚ ਕਰੋ/Track Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_liItem">
							<a href="Jamabandi.aspx?itemPID=3">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl03_bBG" class="bg-success"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl03_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਜਮ੍ਹਾਂਬੰਦੀ ਵੇਖੋ/View Jamabandi</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl03_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Jamabandi.aspx?section=Owner-Name-Wise&itemID=7&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਮਾਲਕ ਦੇ ਨਾਮ ਮੁਤਾਬਕ/Owner Name Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Jamabandi.aspx?section=Khewat-Number-Wise&itemID=8&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖੇਵਟ ਨੰ: ਮੁਤਾਬਕ/Khewat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_liItem">
											<a href="Jamabandi.aspx?section=Khasra-Number-Wise&itemID=9&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਸਰਾ ਨੰ: ਮੁਤਾਬਕ/Khasra No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_liItem">
											<a href="Jamabandi.aspx?section=Khatouni-Number-Wise&itemID=10&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਤੌਨੀ ਨੰ: ਮੁਤਾਬਕ/Khatouni No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_liItem">
							<a href="Mutation.aspx?itemPID=4">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl04_bBG" class="bg-danger"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl04_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਇੰਤਕਾਲ ਵੇਖੋ/View Mutation</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl04_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Mutation.aspx?section=Mutation-Number-Wise&itemID=13&itemPID=4">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਇੰਤਕਾਲ ਨੰ: ਮੁਤਾਬਕ/Mutation No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_liItem">
							<a href="Roznamcha.aspx?itemPID=5">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl05_bBG" class="bg-info"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl05_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਰੋਜਨਾਮਚਾ ਵੇਖੋ/View Roznamcha</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl05_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Roznamcha.aspx?section=Rapat-Number-Wise&itemID=11&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਰਿਪੋਰਟ ਨੰਬਰ ਮੁਤਾਬਕ/Rapat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Roznamcha.aspx?section=Waqiati-Number-Wise&itemID=12&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਵਾਕਿਆਤੀ ਮੁਤਾਬਕ/Waqiati No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl06_liItem">
							<a href="RegistryDeed.aspx?itemPID=21">
								    
                                    <i class='fa-regular fa-copy'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl06_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਰਜਿਸਟਰਡ ਡੀਡ ਵੇਖੋ/View Registered Deed</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl07_liItem">
							<a href="FardStatus.aspx?itemPID=29">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl07_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਫਰਦ ਬੇਨਤੀ ਸਥਿਤੀ/Fard Request Status</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl08_liItem">
							<a href="GroundTruthingDataMap2.aspx?itemPID=85">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl08_bBG" class="bg-success"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-2 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-2 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl09_liItem">
							<a href="GroundTruthingDataMap3.aspx?itemPID=86">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl09_bBG" class="bg-danger"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-3 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-3 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl10_liItem">
							<a href="IPWTD.aspx?itemPID=15">
								    
                                    <i class='fa fa-university'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl10_bBG" class="bg-info"></b>
								</i>
								
								<span>ਇਨਟੈਗਰੇਟਿਡ ਜਾਇਦਾਦ/Integrated Property</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl11_liItem">
							<a href="faq.aspx?itemPID=33">
								    
                                    <i class='fa fa-question-circle'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl11_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਐੱਫ ਏ ਕਿਊ/FAQ</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl12_liItem">
							<a href="UserManual.aspx?itemPID=35">
								    
                                    <i class='fa fa-user'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl12_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਉਪਯੋਗ ਪੁਸਤਕ/User Manual</span>
                                 
							</a>
							
							
							
                            
						</li>
					
                				
			</ul>
		</nav>
	</div>
</aside>


	    
		<div id="wrapper" >
            <div class="page-body">
                <div class="normalheader transition animated fadeIn small-header hide-mob hidden-xs hidden-sm">
				<div class="hpanel">
					<div class="panel-body">
						<div class="row">
							<div class="col-sm-12">
                                <div class="nav-pills bg-light breadcrumbs">
                                    <span id="SiteMapPath1"><a href="#SiteMapPath1_SkipLink" style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;">Skip Navigation Links</a><span><a href="/Default.aspx">ਔਨਲਾਈਨ ਸੇਵਾਵਾਂ/Online Services</a></span><span> &gt; </span><span>ਫਰਦ ਬਦਰ ਲਈ ਬੇਨਤੀ/Request For Fardbadar</span><a id="SiteMapPath1_SkipLink"></a></span>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>

		<div class="content animate-panel">
            

    <div id="ContentPlaceHolder1_UpdatePanel111">
	

            <input type="submit" name="ctl00$ContentPlaceHolder1$btnShowPopup" value="" id="ContentPlaceHolder1_btnShowPopup" style="display: none" />
            <div class="content transition animated fadeIn">
                <div class="panel hpanel dblue">
                    <div class="panel-heading">
                        <div class="form-horizontal text-center ">
                            <h3 class="font-resize-heading"><b>ਫਰਦਬਦਰ ਲਈ ਬੇਨਤੀ (ਰਿਕਾਰਡ ਵਿੱਚ ਦਰੁਸਤੀ)<br />
                                Request for Fardbadar(Correction in Records)</b></h3>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="form-horizontal">

                            
                            <fieldset id="ContentPlaceHolder1_FieldsetApplicantDetail" class="form_ font-resize-scope" style="background-color: white">
                                <legend id="ContentPlaceHolder1_legendApplication" class="lg p-sm text-left head-legend">
                                    <i class="fa fa-info-circle hidden"></i>
                                    <span id="ContentPlaceHolder1_lblApplicantDetailH2">1. ਬਿਨੈਕਾਰ ਦਾ ਵੇਰਵਾ/Details of Applicant</span>
                                </legend>
                                <div id="ContentPlaceHolder1_updtApplicant">
		
                                        <div id="ContentPlaceHolder1_pnlApplicantInfo">
			
                                            <div class="row form-group">
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਨਾਮ/Name of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter your name.</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtName" type="text" maxlength="200" id="ContentPlaceHolder1_txtName" tabindex="1" class="form-control label-lg-font-size" />

                                                </div>
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblFatherNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦੇ ਪਿਤਾ ਦਾ ਨਾਮ/Name of Father of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVFatherName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter your father's name.</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtFatherName" type="text" maxlength="200" id="ContentPlaceHolder1_txtFatherName" tabindex="2" class="form-control label-lg-font-size" />

                                                </div>


                                                <div class="col-sm-4 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblMobileNumberH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਮੋਬਾਈਲ ਨੰ./Mobile No. of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Mobile number</span>
                                                    <span id="ContentPlaceHolder1_REVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter a valid 10-digit mobile number.</span>
                                                    <input name="ctl00$ContentPlaceHolder1$txtMobileNumber" type="text" maxlength="10" id="ContentPlaceHolder1_txtMobileNumber" tabindex="3" class="form-control label-lg-font-size" />


                                                </div>

                                                <div id="ContentPlaceHolder1_pnlOTP">
				
                                                    <div class="col-sm-2 m-t-sm" style="margin-top: 30px">

                                                        <a id="ContentPlaceHolder1_btnGetOtp" tabindex="4" class="btn btn-primary" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ContentPlaceHolder1$btnGetOtp&quot;, &quot;&quot;, true, &quot;GrpRequestotp&quot;, &quot;&quot;, false, true))">
                                                         <i class="fas fa-mobile"></i> ਓਟੀਪੀ ਭੇਜੋ/Send OTP
                                                        </a>

                                                    </div>
                                                    <div class="col-sm-2 m-t-sm">
                                                        
                                                    </div>
                                                    <div class="col-sm-2 m-t-sm">
                                                        <span id="ContentPlaceHolder1_lblVerifyOTP" class="label-lg-font-size">ਓਟੀਪੀ/OTP<span class="text-danger">*</span>
											        </span>

                                                        <span id="ContentPlaceHolder1_RequiredFieldValidator2" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the OTP number</span>
                                                        <input name="ctl00$ContentPlaceHolder1$txtOTP" type="text" maxlength="10" id="ContentPlaceHolder1_txtOTP" tabindex="5" class="form-control label-lg-font-size" />
                                                    </div>
                                                    <div class="col-sm-2 m-t-sm" style="margin-top: 30px">
                                                        
                                                        <a id="ContentPlaceHolder1_btnOTPVerify" tabindex="6" class="btn btn-primary" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ContentPlaceHolder1$btnOTPVerify&quot;, &quot;&quot;, true, &quot;GrpRequestVOTP&quot;, &quot;&quot;, false, true))">
                                                         <i class="fas fa-check-circle"></i> ਓਟੀਪੀ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ/Verify OTP

                                                        </a>


                                                    </div>
                                                
			</div>
                                            </div>
                                        
		</div>
                                    
	</div>
                            </fieldset>
                            <div id="ContentPlaceHolder1_updtForm">
		
                                    
                                    
                                
	</div>


                            
                            
                            
                            
                            
                            
                            
                            


                            <div id="ContentPlaceHolder1_pnlmsgConfirm" class="sweet-modal" style="display: none;">
		
                                <div class="sweet-modal-header">
                                    Alert
                                </div>
                                <div class="sweet-modal-body">
                                    
                                </div>
                                <div class="sweet-modal-footer">
                                    <input type="submit" name="ctl00$ContentPlaceHolder1$btnOK" value="OK" id="ContentPlaceHolder1_btnOK" class="btn" />
                                </div>
                            
	</div>
                            


                            
                        </div>
                    </div>
                </div>
            </div>
        
</div>


            
			
			
			
			
			
			
		</div>

    </div>
    <!-- Footer-->
    <footer class="footer footer-font">

    <!-- Govt -->
    <div class="digi-topBoderThickDis">
        <div class="container-fluid text-center">
            <span>ਮਾਲ, ਮੁੜ ਵਸੇਬਾ ਅਤੇ ਆਪਦਾ ਪ੍ਰਬੰਧਨ ਵਿਭਾਗ,ਪੰਜਾਬ ਸਰਕਾਰ, ਭਾਰਤ / Department of Revenue, Rehabilitation and Disaster Management, Government of Punjab, India.
            </span>
        </div>
    </div>

    <!-- Copyright -->
    <div class="digi-topBoder">
        <div class="container-fluid text-center">
            <span>ਕਾਪੀਰਾਈਟ © 2025 ਪੰਜਾਬ। ਸਾਰੇ ਹੱਕ ਰਾਖਵੇਂ ਹਨ। / Copyright © 2025  Punjab. All rights reserved.
            </span>
        </div>
    </div>

    <!-- Stats -->
    <div class="digi-topBottomBoder footer-stats">
        <div class="container-fluid">
            <div class="footer-stats-row">
                <span class="badge-pill">
                    ਕੁੱਲ ਵਿਜ਼ਿਟਰ/Total Visitors :
                    <span id="lblv">2380020</span>
                </span>

                <span class="badge-pill">
                    ਆਖਰੀ ਵਾਰ ਅੱਪਡੇਟ ਕੀਤਾ/Last Updated :
                    <span id="lblud">12/10/2026</span>
                </span>
            </div>
        </div>
    </div>

</footer>

</div>	          
    <script src="ui-assets/vendor/bootstrap/dist/js/bootstrap.min.js" nonce="CunfbfwKh0FEGDlJ2wDAgA"></script>
	<script src="ui-assets/vendor/datatables_with_buttons/datatables.min.js" nonce="CunfbfwKh0FEGDlJ2wDAgA"></script>
	<script src="ui-assets/vendor/virtual-keyboard/js/keyboard.js" type="text/javascript" nonce="CunfbfwKh0FEGDlJ2wDAgA"></script>
 <!-- App scripts -->
    <script src="ui-assets/scripts/homer.js" nonce="CunfbfwKh0FEGDlJ2wDAgA"></script>
    <script src="ui-assets/Pgscript/masterpg.js" nonce="CunfbfwKh0FEGDlJ2wDAgA"></script>
    <script src="ui-assets/scripts/select2.min.js" nonce="CunfbfwKh0FEGDlJ2wDAgA" > </script>
    <script src="ui-assets/scripts/BackToTopN.js" nonce="CunfbfwKh0FEGDlJ2wDAgA" > </script>              
</div>

<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("SelectRegion_RFVDistrict"), document.getElementById("SelectRegion_RFVTehsil"), document.getElementById("SelectRegion_RFVVillage"), document.getElementById("SelectRegion_RFVYear"), document.getElementById("ContentPlaceHolder1_RFVName"), document.getElementById("ContentPlaceHolder1_RFVFatherName"), document.getElementById("ContentPlaceHolder1_RFVMobileNumber"), document.getElementById("ContentPlaceHolder1_REVMobileNumber"), document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var SelectRegion_RFVDistrict = document.all ? document.all["SelectRegion_RFVDistrict"] : document.getElementById("SelectRegion_RFVDistrict");
SelectRegion_RFVDistrict.controltovalidate = "SelectRegion_ddlDistrict";
SelectRegion_RFVDistrict.focusOnError = "t";
SelectRegion_RFVDistrict.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District";
SelectRegion_RFVDistrict.display = "Dynamic";
SelectRegion_RFVDistrict.validationGroup = "ChangeRegion";
SelectRegion_RFVDistrict.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVDistrict.initialvalue = "";
var SelectRegion_RFVTehsil = document.all ? document.all["SelectRegion_RFVTehsil"] : document.getElementById("SelectRegion_RFVTehsil");
SelectRegion_RFVTehsil.controltovalidate = "SelectRegion_ddlTehsil";
SelectRegion_RFVTehsil.focusOnError = "t";
SelectRegion_RFVTehsil.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil";
SelectRegion_RFVTehsil.display = "Dynamic";
SelectRegion_RFVTehsil.validationGroup = "ChangeRegion";
SelectRegion_RFVTehsil.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVTehsil.initialvalue = "";
var SelectRegion_RFVVillage = document.all ? document.all["SelectRegion_RFVVillage"] : document.getElementById("SelectRegion_RFVVillage");
SelectRegion_RFVVillage.controltovalidate = "SelectRegion_ddlVillage";
SelectRegion_RFVVillage.focusOnError = "t";
SelectRegion_RFVVillage.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village";
SelectRegion_RFVVillage.display = "Dynamic";
SelectRegion_RFVVillage.validationGroup = "ChangeRegion";
SelectRegion_RFVVillage.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVVillage.initialvalue = "";
var SelectRegion_RFVYear = document.all ? document.all["SelectRegion_RFVYear"] : document.getElementById("SelectRegion_RFVYear");
SelectRegion_RFVYear.controltovalidate = "SelectRegion_ddlYear";
SelectRegion_RFVYear.focusOnError = "t";
SelectRegion_RFVYear.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year";
SelectRegion_RFVYear.display = "Dynamic";
SelectRegion_RFVYear.validationGroup = "ChangeRegion";
SelectRegion_RFVYear.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVYear.initialvalue = "";
var ContentPlaceHolder1_RFVName = document.all ? document.all["ContentPlaceHolder1_RFVName"] : document.getElementById("ContentPlaceHolder1_RFVName");
ContentPlaceHolder1_RFVName.controltovalidate = "ContentPlaceHolder1_txtName";
ContentPlaceHolder1_RFVName.focusOnError = "t";
ContentPlaceHolder1_RFVName.errormessage = "Please enter your name.";
ContentPlaceHolder1_RFVName.display = "Dynamic";
ContentPlaceHolder1_RFVName.validationGroup = "GrpRequest";
ContentPlaceHolder1_RFVName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVName.initialvalue = "";
var ContentPlaceHolder1_RFVFatherName = document.all ? document.all["ContentPlaceHolder1_RFVFatherName"] : document.getElementById("ContentPlaceHolder1_RFVFatherName");
ContentPlaceHolder1_RFVFatherName.controltovalidate = "ContentPlaceHolder1_txtFatherName";
ContentPlaceHolder1_RFVFatherName.focusOnError = "t";
ContentPlaceHolder1_RFVFatherName.errormessage = "Please enter your father\'s name.";
ContentPlaceHolder1_RFVFatherName.display = "Dynamic";
ContentPlaceHolder1_RFVFatherName.validationGroup = "GrpReques";
ContentPlaceHolder1_RFVFatherName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVFatherName.initialvalue = "";
var ContentPlaceHolder1_RFVMobileNumber = document.all ? document.all["ContentPlaceHolder1_RFVMobileNumber"] : document.getElementById("ContentPlaceHolder1_RFVMobileNumber");
ContentPlaceHolder1_RFVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
ContentPlaceHolder1_RFVMobileNumber.focusOnError = "t";
ContentPlaceHolder1_RFVMobileNumber.errormessage = "Please enter the Mobile number";
ContentPlaceHolder1_RFVMobileNumber.display = "Dynamic";
ContentPlaceHolder1_RFVMobileNumber.validationGroup = "GrpRequestotp";
ContentPlaceHolder1_RFVMobileNumber.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVMobileNumber.initialvalue = "";
var ContentPlaceHolder1_REVMobileNumber = document.all ? document.all["ContentPlaceHolder1_REVMobileNumber"] : document.getElementById("ContentPlaceHolder1_REVMobileNumber");
ContentPlaceHolder1_REVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
ContentPlaceHolder1_REVMobileNumber.focusOnError = "t";
ContentPlaceHolder1_REVMobileNumber.errormessage = "Please enter a valid 10-digit mobile number.";
ContentPlaceHolder1_REVMobileNumber.display = "Dynamic";
ContentPlaceHolder1_REVMobileNumber.validationGroup = "GrpRequestotp";
ContentPlaceHolder1_REVMobileNumber.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ContentPlaceHolder1_REVMobileNumber.validationexpression = "^[6-9]\\d{9}$";
var ContentPlaceHolder1_RequiredFieldValidator2 = document.all ? document.all["ContentPlaceHolder1_RequiredFieldValidator2"] : document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2");
ContentPlaceHolder1_RequiredFieldValidator2.controltovalidate = "ContentPlaceHolder1_txtOTP";
ContentPlaceHolder1_RequiredFieldValidator2.focusOnError = "t";
ContentPlaceHolder1_RequiredFieldValidator2.errormessage = "Please enter the OTP number";
ContentPlaceHolder1_RequiredFieldValidator2.display = "Dynamic";
ContentPlaceHolder1_RequiredFieldValidator2.validationGroup = "GrpRequestVOTP";
ContentPlaceHolder1_RequiredFieldValidator2.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RequiredFieldValidator2.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        
theForm.oldSubmit = theForm.submit;
theForm.submit = WebForm_SaveScrollPositionSubmit;

theForm.oldOnSubmit = theForm.onsubmit;
theForm.onsubmit = WebForm_SaveScrollPositionOnSubmit;
WebForm_AutoFocus('ContentPlaceHolder1_txtName');Sys.Application.add_init(function() {
    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":500,"dynamicLayout":true}, null, null, $get("updWebsite"));
});

document.getElementById('SelectRegion_RFVDistrict').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVDistrict'));
}

document.getElementById('SelectRegion_RFVTehsil').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVTehsil'));
}

document.getElementById('SelectRegion_RFVVillage').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVVillage'));
}

document.getElementById('SelectRegion_RFVYear').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVYear'));
}

document.getElementById('ContentPlaceHolder1_RFVName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVName'));
}

document.getElementById('ContentPlaceHolder1_RFVFatherName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVFatherName'));
}

document.getElementById('ContentPlaceHolder1_RFVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVMobileNumber'));
}

document.getElementById('ContentPlaceHolder1_REVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_REVMobileNumber'));
}

document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2'));
}
Sys.Application.add_init(function() {
    $create(Sys.Extended.UI.ModalPopupBehavior, {"backgroundCssClass":"modalBackground","cancelControlID":"ContentPlaceHolder1_btnOK","dynamicServicePath":"/RequestForFardbadar.aspx","id":"ModalPopupExtenderAlert","popupControlID":"ContentPlaceHolder1_pnlmsgConfirm"}, null, null, $get("ContentPlaceHolder1_btnShowPopup"));
});
//]]>
</script>
</form>

</body>

</html>
