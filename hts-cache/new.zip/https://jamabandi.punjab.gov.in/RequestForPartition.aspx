
<!DOCTYPE html>
<html lang="en">


<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="google" content="notranslate" /><title>
	ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records
</title><link rel="stylesheet" href="ui-assets/fontawesome/css/fontawesome.css" /><link rel="stylesheet" href="ui-assets/fontawesome/css/solid.css" /><link rel="stylesheet" href="ui-assets/vendor/bootstrap/dist/css/bootstrap.css" /><link href="ui-assets/sweetalert/sweetalert2.min.css" rel="stylesheet" /><link rel="stylesheet" href="ui-assets/vendor/datatables_with_buttons/datatables.min.css" />
    <!-- pe-icon-7-stroke styles -->
	<link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" /><link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/helper.css" />
	 <!-- Custom styles -->
    
    <link rel="stylesheet" href="ui-assets/vendor/virtual-keyboard/css/keyboard.css" /><link rel="stylesheet" href="ui-assets/styles/style.css" /><link rel="stylesheet" href="ui-assets/styles/responsive.css" /><link rel="stylesheet" href="ui-assets/styles/plrs-custom-v1.0.css" /><link rel="stylesheet" href="ui-assets/styles/CardStyle.css" /><link rel="stylesheet" href="ui-assets/styles/custom.css" /><link href="ui-assets/landingPage/css/style.css" rel="stylesheet" type="text/css" /><link href="ui-assets/landingPage/css/flexslider.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="ui-assets/styles/select2.min.css" /><link rel="stylesheet" href="ui-assets/styles/selectStyle.css" /><link rel="stylesheet" href="ui-assets/styles/backToTop.css" /> 
<style>
    .d-flex{
        display:flex;
    }

    .margin-left-right-auto{
        margin-left:auto;
        margin-right:auto;
    }

    .margin-left-right-auto h3 {
      color: #ffffff;/*#126f00*/
    }

    .head-legend {
      padding: 20px 0;
    }

    .head-legend span {
      font-size: 20px;
    }

    .digi-pub-footer-top{
        padding: 25px 0 10px;
    }
</style>
    <style>
#SelectRegion_rdPeriod {
  height: auto;
}
</style>
    
    <link href="ui-assets/styles/plrsheader.css" rel="stylesheet" />

     <script   src="ui-assets/jquery/jquery.min.js" nonce="jW2m3XxhDx1VexjefAfLIg">
	</script>
	
    <script   src="ui-assets/jquery-ui/jquery-ui.min.js" nonce="jW2m3XxhDx1VexjefAfLIg" >
    </script>
       
     <script src="ui-assets/sweetalert/sweetalert2.all.min.js" 
        nonce="jW2m3XxhDx1VexjefAfLIg" ></script> 
           
    <script src="ui-assets/scripts/plrs-custom-v1.0.js" nonce="jW2m3XxhDx1VexjefAfLIg">
	    </script>

    <link href="ui-assets/fontawesome-free/css/all.min.css" rel="stylesheet" />
    <link href="ui-assets/styles/modalp.css" rel="stylesheet" />
    <link href="ui-assets/styles/HightLightFocus.css" rel="stylesheet" />
    <link href="ui-assets/jquery-ui/jquery-ui.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/reqRP.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/tblbrder.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/lnkbtn.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/rdbtn.css" rel="stylesheet" />

    <script src="ui-assets/Pgscript/MaintaineScrollbarPosition.js"></script>
    <script src="ui-assets/jquery/jquery.js"></script>
    <script src="ui-assets/jquery-ui/jquery-ui.min.js"></script>
    <script src="ui-assets/scripts/HightLightFocus.js"></script>
    <script src="ui-assets/Pgscript/reqRP.js"></script>





    <style>

</style>
</head>
<body class="bg">
  
	<form method="post" action="./RequestForPartition.aspx" onsubmit="javascript:return WebForm_OnSubmit();" id="form1" enctype="multipart/form-data">
<div class="aspNetHidden">
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="whlSRAbyTxFucQbB5OjFl7dvtEzbN0guxPj/LNugOuozfgVkaf1tEN7ufKqCQH9se1Tn16c7VQMfP5qZcz3bMgSeZlVzztumtBJBV07jlBrq/V54/y1bB0gAlTVFej6XSBg97A77yrGmeZfQ6d2pGEdMSO5ow3zADEHq+QoY97mgbscng+Xwm4pJtlIGaOslJnaD97Fh0Z2zDYwfdpRlo9PZa3SYy8fp3boMcC73oyJ4mSgOS8+p2nZFdQDf0Cw3E/TNsNxVgYAe4livSVq2YXnzL3VbrwvqsbL2Icp+lIkdOAgq/7yB42Dobk67UijFof5KauILb33Mt9sO7EUpAyDId1FzHTP3DhsBN+m5OvYvq+PAXyvqhzVlh87sFuU8OuobBbYlheST37HG9IX2IcNOJ/hJxcDbFgZrPZPZ3YV7aMuEQHnSfCgZT+nRllwmKJ8QVTbqkRF3GeLWqxhwiIesxmnmb7D9qawOT9AEGVdYllo0AP6BQOISFW9I0m/Lq0nrzZ1Y/XnPpYCiRY38+5ikkax5amTNTq+NhQ9INxCfaTBA7X12YeFB44du6OKf+DtSsxfZ1qFwP/0Za8snoC54R3jgGiT4GUO7zor7z51bgQanl72f5QFxM8DcEwRBUtYaYcg8Ed70AVERFGyrPY7NL5IxTuPw7zQdPlprTXcfeqsfGWRaDq+sxVAe45T6zxrgqkO3C6XJdziZMz9QWa8dBaFVMBYfLi21EmsbXLDvSp4loav+lYqZDE8YAxHCrq79v7qQxVTG3//SNr58X7HtQCcpbuJ1ugSMDS6d2Cmx/KiBN7AC4Q226ZlnW9gJnF8n4k2NLMUJ00XkbFv3LbvJ6gQGv9TOILLDLhrBYfNUm8LvVevwnB3NAG9FFV2JUC1BF3/KrPrKMVdkzxXiZS7zHFI+N1QxB0+gjkbRPmHJokgzxRc5HboNykPsat/PZoOJKWZZ3aWKYWqNRaZSc9IIueSJe4617Z7L8LdFmeYbGGUqcmBm1qzKjn51mfh+qWA8Bp/n7f0EjXZ9OtFK4SKVrEqUoc4bqkHSglFh4G/hbXtfBQYNhboq/mEXSJWqnlkhjJ6BTMFu3mJYeYUIq4V+SfRBG8L3/3ZIKWi6tni1syTWv9O7Mg3U8Rbq3x9wAV2np28Zmx3PUPeRbVHZN9eX0hDA653LADK6ppkVOM2EX0larJcjwUFD4GPhVvizA5Yes7djemYhR5NnxuCJWpp91TMutxYhKD8curgZcvD9Qa/pE47EP40lohaD3Y+GQEgJ0wpNOwBDOgCg5t/RI3bDEiKnmNFoDrLXQUo3gYEOj2aJNdFfKhE39MKFNuadEENUrlv0S/tLswJITQi08gWGUigzaIe1owVH1DH3GPCdY6MggPR9Z9VaDl0ukUr5P6tHiOxIc1rK19vOimHKlZLbflqG2fF05KUuycfBjgPPUhttGDuSI+9P7UpZrJpXTJsaRIYod6VjdLPY4exmelSR3iYqnSS7SymsTBsTmTsqWbU4WpP59P2zKPv8jQ6mdWAFIsEeJcf8rthiFRVbqUOOsh44aCFME35MYSKQnw7dl+KtdbnJRGMhtNO6MEV282izTFZa8ED2P3Utijj11xsCkb0MCowCY9gcbP0QJZvKgxEIS2C6+snoPsEfIRp2bG4MGEJZP93ooy5ewhRWobSaxPVNFzX7akV5XRoKuuoKtRZz+CZ4IwmoEA7wP8+g82S1It07xuHE0DXggatruYkwcnrYh6Dt2ibI8+//UIzDs/jVlx7Y1cV/UxjVnJlcy2/QFoEuk9WtTiN+GX5Uy95vTXzln9ai4VMnK8jdPy8/aLfBMOCiLoczmUl7xHTE0QTJEbBvxNf5jWXTB0BE43erPByh27gYXw5QR3r7sYZKdF7M9J/af3rVuMEnjGqek0mK1ZGOYPuEDAQB13e586+ei2FO3Abr/P6jslDl0DF6vt6IvmiqCiYR1KcHIpPwEhCaVD0xLVIYtzVG0w1ab3/TfCmpooqrfa/5jyivY2rmKqoLLQmdvEDRIo3EeM0rY9VAb4ME69KZUBmEe15Mgzz1FEHZg3/qyqSPJuY98ndjZj9hbbHQYAz5+cdfYF9AJPEfZ9PSekn/KDm8HoeVuGD5/OKC4voJ1HNaCo0Jl0w2Z5SY2i3WC7mL8XSUDhfzZ2M1MQ27QUdTTiNRNysCnrJd535U+NWnu5oN0FHJyQ5C3fd6R/AiMISiIwrmmVoUxiNRibpXh/dRm1Xny/vCEIzXXNPot66+tHqFL52NgpAUcNucojIu9qwm/ERARtXoYyo7JaVo1VMWtE7mT6pzarMLVdTaLzF/IpkbM8dfRSv1JyYmylYjtskDyKxq3yQQdKPQmsL1fxfROG+LhCrUEfgeQd7sJ5YRZY9+RM2tVfM4lmuhrnkpkcZ+cHfxHtspcX7Kf5xgRtMA3iO0foV6fM3/9UXx7ZyJqJN49XU6pXeardHIVDVY7b6XVQn+CO3b8ZEYCYd5jCmNemPa0YdEmm9c62SjHrswHtBAVnCPxz1bP6sVFm4TJYdDCvB71Kt2hTYl19EJE9gWCnA5tZV84hFuKyfAdXKVrUyJ2bhEojtcMpWddyPMBFdWFa3BhTWzA3FLNr0CWVKNDdh8KPbPiuD3HEFiEfee9T6i7jGL1S/21N4QWiNeYT9MMNGX6ozPSSHdZBOjhjFMmE1TZEptaqQ7HKhd7ZbEFYqrVkw400DrflC5QEs1qf1MYmKOtlk/PurHKcKcubwDveR+qKnTwJiwMwiB3JHeG3B3ddB5EZ0mMeqOlfKNTkSYHGFar0vJp7oGjFnzoQ2n0uPRTkZSk5MuRykrmOqoILtE1IYv6YzvqHT2uVV+9ddi9wtEBMMxvtR2gFFkEPvAUGv9aMvKozphvPrZMuHSKQfnNyi4WZ7jHJv+ZAnED7ulvVw2c/PPMhCUxItR/KzpA3DL2poj98VzxBUaLbcIvjwN1sArEV5MLW9+DUpLctNxe6U51S3C6ZrTXkYsSR5MAj4Nr2rF66ziP2FPZ60NziSVw/V4YfUirK57Irm+kieR2UeT0ZAxzi9QRxPeUW8246+8Fn/mcO+tFpj3958JJVw6Q/dwJz+tAzM8AkjFhRI0Fkz5b8INbgOKIAN7P0PHp8nDrJY0X7IGv59MUwDZ7+mfb6Q/n34fha/9RmusGbCG4quS3Yl1cHNk5LdO9WaFHkw6TD1LfW9YDgdZwIj3+g+jyhSkwZggkK+LjqmFCudDwzMAPlgRM46StWl6CZnS6XFS26INhIvJQAdRbXL8KkYa0KcE6TXThq2fImHIZPwB1DUG8dvJ9g8ijJek7v/PdCeow/tgwU3OW8aT1j4q4RpEodz1XykmQ5qYo6QjQhdZBfpnj6wIkKXQZAIkLICARLYOxf1c8ETo1qVjifSyH1qET/RFHp5Iwzzhaek6N46o40ssinhQKT/6pH2uPF1YGqsvE6CBWsib/GNVUW+8IbpyTYTZXBIFF4Ekdhv2P4M/5E/xTQ1XPxOAEH+pJrEVByMiPdFIEV67/QZDmqF8/NoXMemBZypUyKvJKSvECUDy6teJpY0WDggAPibyHnpGkKhXxnsh8FKoUolafvS8qm+ODOEVCD5gX7DEcI0eXso9OoKkTYkssE+XqO0iMibxhMq3TyXbui++Wc98g/vzDTQWG4IvEIDnkf9wPDg+fX5xcRL4cmLbs0ttHBL2WYLjLZa1WAwke2GMAz5FaQloZOVbB4nCPIE7P8Q8d6FVeC4JcFthAT6UGTQ5TBuGaYFgpkYf+PH91d4FAzvogDeujGS3ZVPSfX827lRp1FLqQA7oy2aWWrQdUHMhNUjANiWmcgdZ6T2VyOxY/2L/jJlv2yB6/dlKDOk19bQM5Py4FkW442XXKe36e0Dp96dcQHBCNyWFQKggCoOYQqxeSTeGo6Bqbr9dMbE36eq33WZimeBWMTDQ9r/8MDjw5MASnUZvu7MpRaCbUnjUdlTYtDXLj9CP+An78q/0uDQm1WW8haHMVKSQ37tNCCRh8tYLfVEtsWezFUzcbWpckItxMpGtXiHi5/l8oO48ZrQbr9Oe6d5Z8hfRZaiRm/Py0z+oKbvM95vHEY2UdJGrCCrAFXJq1LvdYsuKOAycVnCZco+R7un2Y0Ltz9G+DfsQoUW0qjgdH9ZMsWYHWgHDTGrsanwgXBsV7KDjnrceayVltXEXLaomxQJwpNbdCjaJH7i26N0Ukw1Rxl4kJ3Pqfa+ARhFBxxheJNu3gW9fg1odwkRu0W+aDeimCT1pN6cPXFfXLeJL20fg5UUkv9PQ1HufwbD0PZzAZBwML0NLmeUbSYvOoKk8HpL1uebWxLFSMYp/NZXHl21MiQFoqRl5dCitoosHhY5R9QAtZKJk8MCWMTQnraL2cyPXcvtdp9YzPF9WHQw6ygUMEE1qf6tzEPo8GmdLJrriU91vhfWlzvjwzeEp737iLRi49VUvJkynAMcCgc0XdDXg5P0AnFiW5S2hwg1iz7+SjHF4J/Pj56jTgreRCIzUpMrwbkjBXkln+3cdrtBo4MBZBUt5ZKNb364aRozi4QnVFrkNlPmrAGhsT4KpLmW74hCf70o+MnHzcnMclGSL3b2k2jxWGjGgd1oFIMkmIT144dPKj7R8bf30PvsQuf5itbgUWzbQI0eD/jIHryP6JjdD6q47H3PXoFsRdttA8yzXTC2WqAT0OjFTgKc+s5jVtl5/B1KHTZCym3pBQmMnAPMgQjOMqvCT5XVUhjOhEeoLAGJGLeR4Oq/3q1O85imCHkIVac3s8mkT4OP5cSnqkw7NObbnENo2idNw/1g+7iDEyuCtXMQiYOOgVT8Mp68Ptfxu7jXMpCsJh4B5AOiytaXeOSgN3UxSDC6dY6FOhdPZl1QqHjCweEmiAFiCnwzujSN8Q1dTakPUgmZlyZfOLWrf6gEPL8kC2cuk9+pR9TonXCCPT9i4e4Hwd3tqFgJsqpTNG5a2Gf/Uh9uogzE+95buQmXimMC8q/dRrR//afJ5/YOiAB+MwA6zxahmdLqrDRxLTWb14owRu89h6Vo+Pveb9mwO5mUp3iQIWqCGvCFVFOISjWNVtK7Rn1PkDACaoAf0Rp8s3Zjv089j8SqtqwmGrrDwbyJvIjq2NPqJfRlCYVotqANlU2f3iFtXMVMQnFAmH+LeUSfWf0dbNncbRnWvnWRBYEHgkhYtazdE22Ahj2MQNCinYGMYkYOTLn0wM+3LOlJUmi5C/ARNWckuqzfhrsmrvB48JLcq4FvoNCYxfnD/2xloUWN9Hnx/xBvnnALWOijnm0zSU2Ob7wJXvnN+7iPn/zEmvIc+4fiKQbdfON4Qq8SWrCluIR64p8WVDIdP9qblpDCZnEky/j2IgzSPYZNXAs+zf/WNv9TgZOeecSc00Acyt4z1B2XwLdwa35tZfrh1cO/tJBxrfarQsxbhcD5FTmqdEMWv8wBmTu2uhZg5jxXksMSWhW37cxZXvR0ZyXDQuUpo6L3xszh/aC0IjjwgHxsjwd/rbhVXo0/Te2UvlIXjG00wOeIlj8O/O2aT/8AO3MJK62uS8hkeuW9ZX550C0iGgW/p00GmOqoR6N4OU5TumakS00sHpemyrZHnMf6sPgn04bozturWPFLCI5OeG5d4PfOeujHK5fs0GvZZrwuxrYZKfmWpPSluXqJ9iHI2Rq9fNO2BU+pNNHt6Qr/qxZOvUFXeDaaiusTrSQfabveJM6fybZ5fMnhDkk2JpwBhqeb0Nw3JbHiEhEsoshcvLyZrcIgVupbS8ZUu/5MbIeoD1Ed5Bpr4BmW9Rpo3l2SZUTW2Hz3Kk2EOnUH99h88kudHpRCNIduV9jyx8jQhSbqSDXscNoXuXZ8eG5/LJj3ttnR0qJ+A8i1rzGpgpSegadPbMmFYFAaUKZPoEDIzHXH5o7+XpnfS+fBUlzzsQ3tOkMjFYiyC7et2xqL4gXaX8OfelBqDnkzo1lnJXcBf8lGovQC7AwhGHPBg951nYeCyUFmhU2k5SGh3b0lkKi6925auAqBkS44S1T538aKtU9kVyBp/9ZQi73otJuu6i/m/Lke8Ji1G4i4IcIvzV/jwUOil6SyXb80OLtAABt+yR6pcaWOTPv9mpFFxUOTVLPS0B3uoHYE7yGZLeKD1cR/zylrwqVMKPciZDe6XoMZ+YnwtVT/UixuUQoESxQMeKysVnF4Dgv7Mp3JA8AhfMcF72VymjElG25cgPHY8oJCNb/Z3I2skUCbfzf7rHAhhj4yDu9s0VhnFnb/JA4NEoB3o66rVMP0PXi9vFeSEgoZYc4tpIsYr8t095cODV4Sz5H3Lx9omZdhDjdytrif7oPNo4tVkwK+4oxrTy+R2tYGAlyUkZD+1zmq1X2Nn+osUnAAlQBGXwc3ocE7wEH3orMuU4vhWxbNo3/xX9CNovcU6dQtGebncyuBVJUKjHnz9p6MbhuGM2Ur4wPmsr7FWM7DNglRDAdcvDljRl9uSTGC+VKcgPunkth6uZQgElrto/RfazCR/09y9roAf/7ed69DghjgfIFXUG+wg+qLO3d/fXNyriBzhFuHhLRwl9TEasEbXkNwRQKmdHzEXLzicxSdmOFt5qTqnZk1qmj9MrMwNNg3gR3b4XX/ExpVWhqksVqUSOPcUga40xtogN6QVcQDLbhe7vNKh9MYwaNWFSh8bwvaMVl4I8LUMzlQAMNmq4x/CsGuvWJa3Zt8CMJnhJ31hCVNmnDdfygLikjadFgcnVd45OmEpm+apSJIkF3YB4FqyUtYDcYSkp7jNZRgSQhumOl+LQ4k6t/mZlN5deLgKgyCiGQZ5r9oRi+VGT9YSoLonJKFJBc7DFf/p+gSzg4yzQ7JpXv2j/VD4zdV4/E+mp25kCKD5jmWLpt2yiMkVXxIMRun20+Cp2Bn4rh1B89vMubMQEuPovdloZMeGDTwtqukj3RlngKOXFi4AoafucoHjL05sZpXWMrKr8YkwdNI2VB9+mzO8UFQp1esD0/6hLPQPMvb4+VyGA0yHct4XEyVnqW1q8C2nH4GDFwEffWpomVelxu2ItS2ooS2/gnqJka0b4eG3EaRgGtheZsgaCMTghs6+BAXA+GSDqnBAGmupwlpI3M5cgfzrjmSS4SLIa+HW6VzIgCBINLGJaTl3HejJxP1le9ypbIW++fLR+3OPxGnCZE+TEAiGJ+ZH79T5Xm0O967G/Bd+D6K7j707pJ9wDPK4VlxVHxXvA+B23tuIkSdVk8tYAO5VWXg5s2/TSAjO1QIDL1pcSH7/jNQIgNtuiry3qG+8eTDCrNyf0ht7dhLBOv+xOLffWQ8LlURuRVbCphmQZzQkfHcjoD2W0CSn3usTkxNJiwkstc+4GU/qwqrmCq/AGMns9iZ3KtgORhjKruYOVBbU+WxRzWoqhBNMjsyc8Jzge5s1ziHGRp/PcHIzw8AwJUYSwBYq2D33VER0o8eJWTQ80P17Smlx9l2fE5yeOOOTc7/kfYVD6m1xI4QG5TuIWbbruA3QbkWbQDQLFMUd+zbSlchz6epbGfjSzuHvjGuiBidXn3oU9/QTWymhS2VXgSLLXZTbDgIai9xEr/a4a7Wx+X0Io/kKUEBo91iG3aP11dDVQLaNDHDz1ilufYRHSFn5I1mELzKFNCrBYSiLy1Fzuc7Ps9lz5ihQNCWXeMdARxINqDBds++XqJknwJDr3CitU7HVBknKK/T0zwY2w7HcVpDpOXv2mgVTvQkywo8BrrTjjwOPsY39v6h7NxdReVrG+PTDytrKBnfIMjoJliFbdwItT50vuLQF845sAPHtRDDuAiW8ktWrJAf0m/DHlhTxD65VUjBDTFTHQm4H59cClNXAP0sH+GB0H2o9asRWMtMhVg18e44a+2tOOmuihu/+qlJm5b0WUsK7YY0iDbnlvf8Zxg933vd7VwC8eH23SoKoojzirjYTtSGDoezUIPuKECPyPYYBYjYHF7YdCoJPh8IElPupbDedL7458+dL8T+CREkokvguAO9eOmlN7NGjoUpnp+u78EgsKI2QdSOKs5pro7uv057R8jQ5wPXT2grAc21FR6kMZCLAQsvo4cLsk4wc1wMHnss57ORGWlRGdfYUp5gjUALLTFzJAtGfUdCAR2bWEHDCXu3PdyHu1UOgg9qFtaHkZ34XFFFr5AlDO2CrDIcMnUG1OwZAsXXsTqZXU9FPNtcsrpFtgf2rfNXKxnRp2TrmeoHlQ17fhONlAEmqm30N9dURbFJ3khTIy6UvW69LdAz/sqJFhzOaoCSebtEhzrTx6IDsqjL06NTE+FU71QuGD6st/GyPoYDmD8uM/8VRazX5XyXLe6Wn7IieuqV3eJp219WAyXDCZnN+hzFkFp5NXWhW+bwEyb23fZzmXpTk61zBqzQuGVflASf32VYpERfibvOBp3yVZhnG8y3kEkYFqfU27VhD3E6wmpn6KNRhOAv/I6b95YNScgCsSGwQpxckF/7UAZ63vl+naCjGX+JRUTwMuoZJGxu9FloQADzEFTcqeIHWb3fKqtYcZ+NVi/ixom1fd8wV6L3hX6hHmIXVFNGf5zGsMsZpxnegchl0neIHD30dSJFi+kfBv4rc3SOX/dNh+8BXCiP/V5HNnOaCcR+R3gdEoLIJ60QhA1S8gCfTJNu7i7vACIRBAmaOvXsIRB9z41zDOYNyABCjN4Xxoz+YRQMv3iQfN+MgNg2weD9VnHnFDvP/Uut0s1Z+Y2SsVF50K42M7V8GhH6bLG77K/LauLXeCwJulu5q11+VRWk0Mu4aIun9Hvw7oTSc75h8RnbPioc5KAxXQu2vDiTs+sudNFQmU8/QVqxIBbXSTUcMYWqWoaWzj1vyAvLxiUDS6QXTf+Ea+UuPIwpujgES+eTNFC0nRrieIgisQLiyP9Ir9iu3CB/oYJl2VnKGpHL1zta/kB7rAyDvg/DXKQrH/78g1HMGChlcsE+cUyM/wyZwfAmQbk2tzosnQrAyOc0QqjQ97E5QiuWFc/gaQVPW+j2UwzlAkhDPxinvJ/OMqHSFiT4YM3m7RB4JRKy78EuxJ3RNyG0zg9WHDH/mXUavlzOVPutofZxeLk3pV1pCBX5ChE7TQ4Uc+EwhADxoQh8ZLlxe4wji0Hf3zaPABEydOpuOLQ4Q5VLiyjsZPZ721sTAw5YbZwzZGOa4dfCy28FYCEnfDHgI7YaKQM8+SMsnzD/66sH+24ZzUydiCNYtlP8U6rShfexGxhRElXl3Idtn9nqcuifA7CUxhvXYnz8Vbkm6LTiGBaZtTmctJ0h/mnxemZl/r5rY1zu5fGQ3UpBNgdyz9aDq5kuhMZdKkTRYcs79YNANngr8KNRrkaaHElnYy+tOovqYBSHqYdJaMo5AtEbwFmTO155F10zWPwRo1EpoyfnPfdmHM3h059binfXjU9EuFaIShnbAUsBJTJri+Nwt3Z/h/QZDOSlyZiF97uz+GsdFn9njdS9PqxgBELM+iL0OFiXeSrKBFv39JMYU6CuRiHhyNddLmbVvifS9XfM3JPLaG6CMqdnFmJJ0TdWL92w5QwBxpqj7XbSkehQx1Yy7mNxnNmAw9b3BD2YzUw2wpSbS9N59Ah/biwPym/14an2CGa/LOPwOxy5Bj0YwRbC2hSUEmyHGf0te8h9N2GO40dXnvwuO1zT4QVSUotACuicEwJXHfPSO1Yi+2wgJJS7bW14r/TsbASBWAvJY3Z3GGGA7XA7cp8anyjxVEs2MzcbhIeNCUUvTWcVv2akZ9HabMI0BV4hPq2Q2tuGQeaoDfA6Oj+52Wkqtu7rpEp9AbE6hAywd7vy48edbbxGx5Ri76jy1g7pQrHS6GF02lStonE3UK/n7xvLjlXtzBkSo18N+3T/VVwdnXquziFb6YjogcmE0lTT5QeD3QURLmJTqXmWrkkUZ04kLyn5vZwlQoBUZ2wrsV1DSO5KUGTyZo1otQ2rcbFG0sDNeaNytdFduDaJX0XsH8xdL6ekZvotUHs3iHHZOHP9ROLWwh2TvmcddNlctQ9GImkbbn4OuIOXHe73ZQ1kzvDfGkcle+o/6IZP3eYh/FeqZlwwM6AZ1rBA74eXP4gD/RNW0J8XWfB5H48Z2QbHOKoRHPPGio3F1FcRLQyXjSE2k6SWICaWYs50w+5zLdj9XugXbCsurKN12QY1WUOw/C4fIdQ4Xk9IL6xVpGhf2vWxUFIPpYsraHov7rupyjrEyVlPRXm+QLxcShiHwTw6vNU/KDDUrh2fKWDQCvodpVY7bcNXWUN7J7IHCTtgPg9nz80Nk99xW4JgSwdUniLCiHC65iVfBK5Z898UzLtWq/uDNNK/vGd6aG6xzInVwXL7Nh5y8UQOsr9WAIhD6F5GHiquRrGG4oC5ljN1sNz/bkiFZE41gDM3L9KjZYrOiwViPiaRAXbZyCit4uAED+mQGUBY8dffDP18p5G8XRhYGs37kzqoFlosUDm12QYc1+c7BPTBQ1ZVR96CVCPYkjfXdzLNDGU2JOsMn37QuGUSQ4ed44HRRK5ooSYRiopsDovMmkaKqdUps9zk+RlS9qhsr4CUlxNYwV2oiSyGVzVu6Cg4XyBmkd7BVtBkGoFuBQ9oCji+UWfB4m6XI2k50lOMo0wJIUD/5MJD8MV1uJMIy0pu7a1DZb3REA/B0CDzb0l7zCVBJiubIRNP0Ab0RIFlcs8RlsYZ3YoHOCPwaOq5SvrG+5afUQUmHBBj384BX6D1S62GY4zfUwZZUsey/xoqv6ZlgUjJCndBAK/ryFyBXtdx7UjN1wY+7iuw0KCuHbjv1ZI/gsmcskA1AE1Vqc2yf+/zEnWgESmgLDp7p6sxnHU2FBdvKv77bTb89ufpq03ouTG36p5Umv5PE1b4pgpLGWwRv4jk2ehKb418B+mdypBF0ocvOUEy5OYDwLh+lzCGt5d5T1xt+UZAMOIqCktUR6E613evFwh0F7V97IJbKmnMMnXdnoDZWWHROZwX2xboAfAo/x595rwNbPavg71xJN4A9UsOdn1P8gneo+5dSa5swm8qkpsHZrohu9bybT1w9b0CFGAXRy3MNHV9EZUBmI07b4B9IRNmokm9e01aY73SswsO3/nppmUoGxq6h3gYOnRDy/+lhi8RTkczsJxG2s3/y70R3k0LjKC1tYJtT/umn9Iwt4u5xxZEZpCOHi/scp8vCEPsSrYmN1lzvco6sqZBSipCsYsrWiC+Jvg8y39qTeOIkXjKp/4dW1j3YVsD+KheFeaoRHwNyhJNqbgyNymDu86cAtu7Oi/drgFYDz/b2wdNntzw1zJy66bvt9lPA+RZ5miKtkJAik8AHE2rBm4+IIbeL57Q6txb4L2KRVLqXOWqqwO+Jcn3t9E6uawm9kdEUeLxN/2I7+mHjbf+PBkxoHHHZO2BvQRdNcotAowhXzBHkgX7uFj/l/pm9xqkUsnrnmAyJ5MYagaLd8KB6pXJo+SOrO1ueigxbQ9Di77/o9dtLsGh5EMriRD5HVbxly5rif+Pxa5DKix8vQW/2tC0RvcAUDYJCcOTlx9tDCxFE0vFoJF6kVQgh8r+C188K9fFZCb+ULijWV1btTK5ACFtQrirX6fAyZ+o0M8puLZQ7Z8j41SS+1laZPBmaL+C5ds0zE6oSeKPW0RrbwlQiFmJX3f0/jDtZJKpOG9zzfU8r+shdlvHFSBRyw+Py41qYorjRsc1zcgrPo2rpBRbNBHXW6YbktBl5iTceDrXhh7NmB8KIF0doK0m55V2hc0cqUBf5+M1p1w7y2ygS0QnxmsKF+zU334F+AMtzcAk14h2ROvIxspFOoVgxKeSAEGfT6BX4UfNnLRE1188W2mV+0fXO3Gr+Gcp0fDvY9eoHUakahuyn3SHjg3t/6A+gbyFVFVSYubnZgGGbL6LHTAuZgSzwseNMnSar21qMSkSSVsKvV52kMMEaOJlTxpAKWdAvsf8E0jAtldoZFTbQ7KWPV3l//3A43FP5fIbRR2g5ThgldF2mUaKAyFRzBsRIj58/9hCeR2sNMwa2GVPuz+wCD3T2AN66iCmntwRbHtmnvTUNVsYGdMhnDRr0Ix78q60gCTP0i5xqlkPJYwQGbAwh/Pl0f/zskzfMZ1iUcIXng++adnf1cyO5/W9KrkUZwQZg/iY10S/Cd6C1Z6CM+ihYI1YiOpihVVbPBjM2WzYIW9HeucfRQg16ok2fnF44Z40HjZL+BAmYqoYl6z8ILgiAhGYzXd91fJolrfVh+MuNI5xG+Jhn8cy+gyYR6i1omO5jJ2+zb1OQTMVtk8ykiyak4b7efl7g55LeazZhueJrfwqmHMug4vCG5eF3y3e9HyBeKffm2nrTxtvVFCuZICcbc7BnkHLHbS3PzSiwezjCpTCaPpyxvhKD+NeO1s78RMpwUsx3MErh42wjRA4BzO1DJ+kggaaCmOgWuySC8AhQkp5LXofVP3zpr4L3qA7fYj5G06brm091QX9zmE17AoD+v6m35jb/qz5m1WEe3jI0Ynf9pauYoUNMOxocB92cF5hW6eis2JTpskwl/lB45rK0IdVMTekkqyBoaUYAHNOSajgQhL3hEhzoLkLoefOxMhfBT4YXIaidYQTYFLEcNotn5q0W/5ZCPnStD2ddxLhtNF9/2IThBFbndFx13QbsMOxkVnZwCqL4EOaT2lUpz4s6hXpWqn8FE9fZfxrDgBx8kQr87bC9N/wLsfkMmlrxpnThxHKf9XJxhDI6GYiTRJla+rmfQxExkd+7FKl59Q4dDIY2XQK4+U2JuFYxxT1Prn94/W4BMF0iDQcp51czqeJtMVts4vST67L1O+NIj8ryA+5KdJkHgBBoWt33dObHdv9iLWWGdFSyNh+VE8uEHD6L+OyuXwBALopT80eAMg8QMwvO60JrblmFQ52LI1Q1lJgYxs3+g8VZLHw0ykNjVKE9gSPusBpqhwCAWsfFJ97XScfoGDanBWjsY75ehD09tiDCESRlmWEvLnpVZEslgpwLTKhvB0wMHpdEEJVCWwfM2TP2THZnPoMqLq0jhpwoG/ZmnmrWF37Cgq8RGS4daRr9Jq0sytVrDUwFof1LvggE7PF8ODMoALrJyATrFgMXNn3k3JPWAghnAd5C+Sx3BOq5wq/ppdZaUE/kkeI1CqiagSNLxv7lc7rP6XWe50WOHeSPKi+rC5oOzu9tuKXeWN3vNuHn5lgcaGJJ6ZCxfYANYCd1U0w2Z1Ka8iv+49Xur+SlJSyp2mDHG6rfSU+AKHFNrNNW+bWko0WWqsPBxi2aYKJ1DWLmxbwpYBMMbCWclAIAs6vSrqQrA1pNdoxUkAoO5qegjTq9gOiqtrpJ0dJXrJsE+t5MUVI5kVevzqoY31Shif0eQa8NjsSEOXI3osVJXictla+IQt+RzUrpbf665R85j3dhmlw/zH7ckGcRQyPiEkArETALfRymYYy2k7GXTq+FKHmJ5HtOU2vx/5HHuucM5jsy3al4GA8+MM4j9m+TqHwu741JGAIVThREexH9OhBjvUD9NhtPlM++V6whYJzJexVpwkAFF1lLTnd7tUlIM1oE+Cn/ivnE" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZBbRI-vLFGPASeYxh_KgLGJAGhxxxQHaAFUowMEJ38zbzJMIHhOPM0QVtz7ClVSrJw2&amp;t=639202794265548063" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1HoTsDJCIwegf7-cSVNQxKlxqJplUAag2gjZMR_ctGyeKzMDbl61mq8CG1bXK2cKIO5F_d_eACHU7rvEovdRsHjPwMxL_2RbhdHxnXThSzdTd55hY37B50zmwPwIsJ1FnQ2&amp;t=4623e90" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvqBoWBYTDUGuawA_2GYbNQlKfMSt2G6fTRv2v_CvkMQC-NDKOxcBHZBsr4m43UZoWnDElLWlfRSMae7wFN5-j848Bfbquym3Qmm_a4KPTP8MlNJWDtdRKeoXno9ND71Mj-dmT4RATMPqWph8tRm5et41&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OAh7tEdde-lvG3-30egxXz8aAgw_K6hDRuGQnL44pJNvGX0k88IpkhwtBpf_hp5FI_xl-S6IOzDAoSwTftgBkdwIVbozv2itakdYRoj6lyvW2iAmc3lxcxcAsYCLcWBMdMG64QNAlb5JWK1NKm4PkKk1&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=eE6V8nDbUVn0gtG6hKNX_FhBCrEodp5vWm_YmsPN6L6kd8QLjOqCyZgy7R07cf_-q6jt6CUudI9DljzC2TdIySTnrKddg3RKYGaYn4SUdM3lZcSR2HeYBRZYoT1mfgRe0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=mcAASOSteirJeuV-3by3Udl0BXtV-9r3zqXldfMmh4nMyRrfOyOUzm9PjtxhXMnCb3u1w9Bl8xQwuZ3vJQhQk5K_jbJ7TUVZSafdbK767TU1&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=jwf4VSQi7LeShc44FJ-gAeDpDtsq5KMQ8v0UGSwL0n57o9DwezYikDFx_PyigWyXj_0OxQaznPKYQt6DlIveEltbNvWSF7tPucSRMMT0SDIeemWSUwY9H6muRTmCFq5y0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=nai7mGcYyE2dix_TwveLDUh5s-4A2YxYW54tIrkM_TUunAGPTDDQIgTi7_jF0ZDsXQf2DAdig0qNTG97Zho5rt0FlKu4f2urbVFVmxpi95du0q96Rm7avCmT7YWIJACc0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=yDT7ulzE00Yqzs5zd38bJ9uYK0mE0NQaZIaf-pwWkJgWYgpXpMmyr9X13OsEF0tAmtivqF1lykUd9zGXXG_12HtYlW9Y5ThEGbuS1bPsUkjRauDlH9wZ-Gg0tVnmDj270&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=HEFpVKbnoeQjkjHkFKu3MFt9ri5W5MnThyWIA17NLksVbAMJb3b4J6FUWFjTqfhe62vQzBBryc0D7vtVE9sCvRaBkQXkkFQdNC1ak54UhzYYY35kSK400VtcrgLyqWDD0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=5ib3lCcyinHeLQmkwMF7EsGoPbLcoTPc-cgtukLJYPUZaLkkgAnENQdSi8NDc4l_BKxYZA1H9k0706BHQRpedGJsNRjKTrwz8gPmzzA-oap0ysiJ6VwrD01uCYx37kM30&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=iON9Jxe8QCRam1nkdNLgkffrRZCMCj6iq7qHWPZc_e3jKeMk_XnmxshFxNhoGH9SwE5Oz8w4xs83YnQN2PvBuUDeB4qmPOBf6C6AjLMoHrEWhVT0hkNgKR3X5v1OCzxI0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=xGmPTKfsNy0_1Sr5I58kO5DASLN2udyuv-7sLUq5_rfvt0h0nqG8q3lnLwCBbElWqxPrkky3q5vq3pg0VXsmEcTWWXMOeG7FgMUlD16VLKssIvRudHPE5Dua6R6EOhY40&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=LQ1q2RBSthBAZhliMjtG_6LMhlQH2DbcQYgRKlCVjFIh5IZ7GFZUyt66Y_m4cqI1Qb8Rf2oM6HCIJJLQ9rSBDT1GrsRxo5ZypZQOZ1maIbKPmaC4yLryG1OCPsyASQdm0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=VOYD8Xe7kQA0lniBYXVpAuKo3oFKAyHWpDt0JH4amXNlZ9J7vLHsxoqoc15eTAjA6oglPYd0zwAK4QpQdtZv0jvkOUq5Z5is2nQki9YITO0skfivF47CJZD_3wdgAEY50&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=hOeJu0xhC-uW6Gf8ooKdXldiqMjTwkMrPiRL7tfxCMAYgx7LQGO2FKVjBYyeRQsczHJO8YrvOhmAf48uwtZEnO4Mu9oj9tlaZBV6uinaXInS4irYgdmuHH1_fMK8aVI10&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=XlV9GqTk6b5uqDuL38kZ4M4-D19lMtmt0Nfm-OaIfmfKZXxxdkEy0_fz8Rb50xJiOME7ruSlDELDwr_q88n93Z8DbpgP-PrvolSTi43wrxjzmVSKMK-250V1wOfusJzQ0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/WebResource.axd?d=JoBkLzP19aTuxbWOhHobYndLm8rB8C7w5JAGcozHelAi0yxlDEHXqwBJPZODPDVe3kynVZnW81KTBhLcr2IKvw2&amp;t=639202794265548063" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="76B9DA33" />
	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0" />
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="hlvaGrgt7IqMm9Ci/ekFNB3rHDdkTXpLe2SGV2cntgZqEPqu96U718SKMUTRuxUkVbVc5KkvF+I56qk+AzHe49WDjzrLf3kf1ci7J92wtXr39I+PJjTAzW463B6DQzy/ZLV/wLsssKUJYo3MKRz6LakmufRPApbp64ep1dS2G+G+LTesI2AG3oZQEKRwp5e6BLelH8oveDlHasD+Tfb6gWV/S98XFHt8NgZw06C/pDzmvF1VExZrfLGaz9NZ9hrquS4SskcvFfqFJ41p49uzzt+eZ0Fse3v0dBWHs8cu9npHx9bRRd/rmHBTZr5rmbJQG365ze5HcDDrUW+c7xgo+UKJSUfZIwafrPy+HlXRPvpiv5OVHHX+vlFhUqScta0ms8nWkXBqzbQC9FBsUEkOJsGFI0oQeAq/jl6JtGbr9egq53mCJLQIdrjvqnWAt2WvW5HvO3kPa34NbXEuMjtXOH26bh8YjylL1NGcAob4Z68lDVp9NFX08YPFhLlgq6umJnaoHT/VlN+UoAjrWesfj3J/7TdAReN6WVz2YDDuAVSuUVONx6/+F7Nkfo2XO6yxy0Ua84pfW59yijcymwYyrsSPgHHlweT4vZ6vrAGdn3jxeoE/Wmd5NhO61EImsAykBhOzxjTD94ob4SiEq/7gs8LHRemveuAiEZV6OH4Xu6J/mUGCZGnxesKMe81WI/+vXXpd/AEEVXddlCSgYzngoZLjmLOshj8DBfaOw+dR4f8rjayMOMDZdHQ/EEhpRsDpgcR2f+htB2IL6SBYiqaMEdPo2EMHdvuoH/kVON5qqx1Y79KIg5TpTk7kmJSuYy+qxiVfMs4E5bn3mu1MjJ7abYyPqW6Km0a9PEtIcvegS/9vqGbn0KH3WOo/ogNAh+xvBEjerce55Bs4vuT3UC+5rO6U2Bc3YGZghltvUa1BEvCDElvyZ67t/ppgS9GdqYINNKlosmVz7Jgl/LpH75SlI6YSKxwm8ihhi9005Qm9+u4=" />
</div>
           
        <div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', ['tctl00$SelectRegion$updChangeRegion','SelectRegion_updChangeRegion','tctl00$UpdRegion','UpdRegion','tctl00$ContentPlaceHolder1$UpdatePanel111','ContentPlaceHolder1_UpdatePanel111','tctl00$ContentPlaceHolder1$updtApplicant','ContentPlaceHolder1_updtApplicant','tctl00$ContentPlaceHolder1$updtForm','ContentPlaceHolder1_updtForm'], ['ctl00$ContentPlaceHolder1$btnGetOtp','ContentPlaceHolder1_btnGetOtp','ctl00$ContentPlaceHolder1$btnOTPVerify','ContentPlaceHolder1_btnOTPVerify'], [], 600, 'ctl00');
//]]>
</script>

            <button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-topD">
                <i class="fas fa-arrow-up"></i>
</button>
<!-- Simple splash screen-->
<div class="splash">
 <div class="color-line"></div>
 <div class="splash-title">
 <h1>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h1>
 <p>ਕਿਰਪਾ ਕਰਕੇ ਉਡੀਕ ਕਰੋ ਜਦੋਂ ਤੱਕ ਅਸੀਂ ਤੁਹਾਡੇ ਲਈ ਖੋਜ ਮੋਡੀਊਲ ਨੂੰ ਸੈਟਅਪ ਕਰਦੇ ਹਾਂ./Please wait while we setup the search module for you. </p>
 <img src="ui-assets/images/loading-bars.svg" width="64" height="64" alt="Loading.."/>
  </div>
   </div>
		<div id="updWebsite" style="display:none;">
	
				<div class="loadingContainer">
					<div class="loading">
						<img src="ui-assets/images/loading-bars.svg" alt="Loading.." width="64" height="64" />
						&nbsp;
					&nbsp;
					</div>
				</div>
			
</div>
<!-- Header -->
	
        
        <div id="header">
            <div id="plrs-header">
                 
    <div class="plrs-header-row">
     
        <!-- LOGO -->
        <div class="plrs-left">
        <div class="plrs-logo">
            <img src="ui-assets/images/logo.png" alt="Punjab Land Records" />
            <div class="plrs-logo-text">
                ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼
                <span>Punjab Land Records</span>
            </div>
        </div>
        <div class="plrs-menu header-link hide-menu"><i class="fa fa-bars"></i></div>
            </div>
        <!-- REGION -->
        <div class="plrs-region">
               
             

<div id="dvChangeRegion" class="modal fade">

	<div class="modal-dialog modal-lg" style="min-width:80%">
		<div class="modal-content">

			<div id="SelectRegion_updChangeRegion">
	

					<div class="modal-body">
						<div class="row">
                            <div class="col-md-12 m-t-sm">
                                <fieldset id="SelectRegion_fsSelectRegion" class="form_ font-resize-scope">
										<legend id="SelectRegion_lgSelectRegion" class="lg p-sm head-legend">
											<i class="fa fa-map-marker"></i>
											<span id="SelectRegion_lbllgRegionInfo">ਖੇਤਰ ਚੁਣੋ/Select the Region</span>
										</legend>
							   <div class="dvSelectRegion m-t-sm m-b-sm">
                                   <div class="row form-group">
                                                    <div class="col-md-12" >
                                                		<span id="SelectRegion_Label2" class="label label-lg-font-size">ਜਮਬੰਦੀ ਪੀਰੀਅਡ/Jamabandi Period</span>
														<table id="SelectRegion_rdPeriod" class="form-control smedium m-t-sm">
		<tr>
			<td><span class="radiobtn"><input id="SelectRegion_rdPeriod_0" type="radio" name="ctl00$SelectRegion$rdPeriod" value="1" checked="checked" tabindex="1" /><label for="SelectRegion_rdPeriod_0">ਮੌਜੂਦਾ/Current</label></span></td><td><span class="radiobtn"><input id="SelectRegion_rdPeriod_1" type="radio" name="ctl00$SelectRegion$rdPeriod" value="2" onclick="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$rdPeriod$1\&#39;,\&#39;\&#39;)&#39;, 0)" tabindex="1" /><label for="SelectRegion_rdPeriod_1">ਪਿਛਲਾ/Previous</label></span></td>
		</tr>
	</table>
                                                        </div>
                                                </div>
                                <div class="row form-group">
								    <div class="col-sm-3 district-dropdown" style="position:relative; z-index:9">
									    <span id="SelectRegion_lblddlDistrict" class="label  label-lg-font-size">ਜ਼ਿਲ੍ਹਾ/District</span>
									    <select name="ctl00$SelectRegion$ddlDistrict" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlDistrict\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlDistrict" tabindex="2" class="form-control">
		<option selected="selected" value="">ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Choose District</option>
		<option value="7">ਅੰਮ੍ਰਿਤਸਰ/Amritsar</option>
		<option value="8">ਬਰਨਾਲਾ/Barnala</option>
		<option value="9">ਬਠਿੰਡਾ/Bathinda</option>
		<option value="10">ਫਰੀਦਕੋਟ/Faridkot</option>
		<option value="11">ਫਤਿਹਗੜ੍ਹ ਸਾਹਿਬ/Fatehgarh Sahib</option>
		<option value="12">ਫ਼ਾਜ਼ਿਲਕਾ/Fazilka</option>
		<option value="13">ਫਿਰੋਜਪੁਰ/Ferozepur</option>
		<option value="14">ਗੁਰਦਾਸਪੁਰ/Gurdaspur</option>
		<option value="15">ਹੁਸ਼ਿਆਰਪੁਰ/Hoshiarpur</option>
		<option value="16">ਜਲੰਧਰ/Jalandhar</option>
		<option value="17">ਕਪੂਰਥਲਾ/Kapurthala</option>
		<option value="18">ਲੁਧਿਆਣਾ/Ludhiana</option>
		<option value="18953">ਮਲੇਰਕੋਟਲਾ/Malerkotla</option>
		<option value="19">ਮਾਨਸਾ/Mansa</option>
		<option value="20">ਮੋਗਾ/Moga</option>
		<option value="21">ਪਠਾਨਕੋਟ/Pathankot</option>
		<option value="22">ਪਟਿਆਲਾ/Patiala</option>
		<option value="23">ਰੂਪਨਗਰ/Rupnagar</option>
		<option value="24">ਐਸ. ਏ. ਐਸ ਨਗਰ/S.A.S. Nagar</option>
		<option value="25">ਸੰਗਰੂਰ/Sangrur</option>
		<option value="26">ਸ਼ਹੀਦ ਭਗਤ ਸਿੰਘ ਨਗਰ (ਨਵਾਂਸ਼ਹਿਰ)/Shahid Bhagat Singh Nagar(Nawanshahr)</option>
		<option value="27">ਸ਼੍ਰੀ ਮੁਕੱਤਸਰ ਸਾਹਿਬ/Sri Muktsar Sahib</option>
		<option value="28">ਤਰਨ ਤਾਰਨ/Tarn Taran</option>

	</select>
                                        <span id="SelectRegion_RFVDistrict" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District</span>
								    </div>
                                    <div class="col-sm-3 m-b-md tehsil-dropdown" style="position:relative; z-index:8">
									    <span id="SelectRegion_lblddlTehsil" class="label label-lg-font-size">ਤਹਿਸੀਲ/Tehsil</span>
									    <select name="ctl00$SelectRegion$ddlTehsil" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlTehsil\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlTehsil" disabled="disabled" tabindex="3" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਤਹਿਸੀਲ ਚੁਣੋ/Choose Tehsil</option>

	</select>
                                        <span id="SelectRegion_RFVTehsil" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil</span>
								    </div>
                                    <div class="col-sm-3 village-dropdown" style="position:relative; z-index:7">
									    <span id="SelectRegion_lblddlVillage" class="label label-lg-font-size">ਪਿੰਡ/Village</span>
									    <select name="ctl00$SelectRegion$ddlVillage" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlVillage\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlVillage" disabled="disabled" tabindex="4" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਪਿੰਡ ਚੁਣੋ/Choose Village</option>

	</select>
                                        <span id="SelectRegion_RFVVillage" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village</span>
								    </div>
                                    <div class="col-sm-3 m-b-md year-dropdown" style="position:relative; z-index:6">
									    <span id="SelectRegion_lblddlYear" class="label label-lg-font-size">ਸਾਲ/Year</span>
									    <select name="ctl00$SelectRegion$ddlYear" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlYear\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlYear" disabled="disabled" tabindex="5" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਸਾਲ ਚੁਣੋ/Choose Year</option>

	</select>
                                        <span id="SelectRegion_RFVYear" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year</span>
								    </div>
                                </div>
							</div>
                                    </fieldset>
                            </div>

						</div>
					</div>
					<div class="modal-footer">
						<!-- Submit Button-->
						<input type="submit" name="ctl00$SelectRegion$btnSearch" value="ਖੇਤਰ ਬਦਲੋ/Change Region" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$SelectRegion$btnSearch&quot;, &quot;&quot;, true, &quot;ChangeRegion&quot;, &quot;&quot;, false, false))" id="SelectRegion_btnSearch" tabindex="6" class="btn btn-pimary submit-custom-btn" />
						<button id="SelectRegion_btnCancel" class="btn btn-danger btn-no" data-dismiss="modal" TabIndex="7">ਰੱਦ ਕਰੋ/Cancel</button>
					</div>
				
</div>
			
			

		</div>
	</div>
</div>

            <div id="UpdRegion">
	
                    







                
</div>
        </div>

        <!-- ACTIONS -->
        <div class="plrs-actions">
            <div class="plrs-font">
                 <input type="button" id="btnincreasefonts"  value=" A+ " />
                 <input type="button" id="btndecreasefonts"  value=" A- " />
                 <input type="button" id="btnresetfonts" value=" A= " />
            </div>

            <a href="Login.aspx" class="plrs-login">
                <i class="fa fa-lock"></i>
                Official Login
            </a>
        </div>

    </div>
            
</div>

</div>


        <div id="divBackground" class="modal"></div>
		
        
<link href="../ui-assets/Pgstyles/uc_navugatonmenu.css" rel="stylesheet" />
<!-- Navigation -->
<aside id="menu">
	<div id="navigation">
		<nav class="nav-primary">
			<ul class="nav">
				
				
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl00_liItem">
							<a href="Default.aspx?itemPID=1">
								    
                                    <i class='fa-solid fa-house'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl00_bBG" class="bg-info"></b>
								</i>
								
								<span>ਮੁੱਖ ਪੰਨਾ/Home</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl01_liItem">
							<a href="OnlineRequestStatus.aspx?itemPID=77">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl01_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਟਰੈਕ ਐਪਲੀਕੇਸ਼ਨ/Track Application</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_liItem">
							<a href="./?itemPID=82">
								    
                                    <i class='fa-solid fa-file-export'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl02_bBG" class="bg-primary2"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl02_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਸ਼ਿਕਾਇਤ ਨਿਵਾਰਨ/Grievance Redressal</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl02_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Grievance.aspx?RefNo=1&itemID=83&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦਾਖਲ ਕਰੋ/Submit Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_liItem">
											<a href="GrievanceTrack.aspx?RefNo=2&itemID=84&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦੀ ਜਾਂਚ ਕਰੋ/Track Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_liItem">
							<a href="Jamabandi.aspx?itemPID=3">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl03_bBG" class="bg-success"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl03_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਜਮ੍ਹਾਂਬੰਦੀ ਵੇਖੋ/View Jamabandi</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl03_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Jamabandi.aspx?section=Owner-Name-Wise&itemID=7&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਮਾਲਕ ਦੇ ਨਾਮ ਮੁਤਾਬਕ/Owner Name Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Jamabandi.aspx?section=Khewat-Number-Wise&itemID=8&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖੇਵਟ ਨੰ: ਮੁਤਾਬਕ/Khewat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_liItem">
											<a href="Jamabandi.aspx?section=Khasra-Number-Wise&itemID=9&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਸਰਾ ਨੰ: ਮੁਤਾਬਕ/Khasra No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_liItem">
											<a href="Jamabandi.aspx?section=Khatouni-Number-Wise&itemID=10&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਤੌਨੀ ਨੰ: ਮੁਤਾਬਕ/Khatouni No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_liItem">
							<a href="Mutation.aspx?itemPID=4">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl04_bBG" class="bg-danger"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl04_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਇੰਤਕਾਲ ਵੇਖੋ/View Mutation</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl04_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Mutation.aspx?section=Mutation-Number-Wise&itemID=13&itemPID=4">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਇੰਤਕਾਲ ਨੰ: ਮੁਤਾਬਕ/Mutation No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_liItem">
							<a href="Roznamcha.aspx?itemPID=5">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl05_bBG" class="bg-info"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl05_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਰੋਜਨਾਮਚਾ ਵੇਖੋ/View Roznamcha</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl05_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Roznamcha.aspx?section=Rapat-Number-Wise&itemID=11&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਰਿਪੋਰਟ ਨੰਬਰ ਮੁਤਾਬਕ/Rapat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Roznamcha.aspx?section=Waqiati-Number-Wise&itemID=12&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਵਾਕਿਆਤੀ ਮੁਤਾਬਕ/Waqiati No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl06_liItem">
							<a href="RegistryDeed.aspx?itemPID=21">
								    
                                    <i class='fa-regular fa-copy'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl06_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਰਜਿਸਟਰਡ ਡੀਡ ਵੇਖੋ/View Registered Deed</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl07_liItem">
							<a href="FardStatus.aspx?itemPID=29">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl07_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਫਰਦ ਬੇਨਤੀ ਸਥਿਤੀ/Fard Request Status</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl08_liItem">
							<a href="GroundTruthingDataMap2.aspx?itemPID=85">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl08_bBG" class="bg-success"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-2 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-2 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl09_liItem">
							<a href="GroundTruthingDataMap3.aspx?itemPID=86">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl09_bBG" class="bg-danger"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-3 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-3 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl10_liItem">
							<a href="IPWTD.aspx?itemPID=15">
								    
                                    <i class='fa fa-university'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl10_bBG" class="bg-info"></b>
								</i>
								
								<span>ਇਨਟੈਗਰੇਟਿਡ ਜਾਇਦਾਦ/Integrated Property</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl11_liItem">
							<a href="faq.aspx?itemPID=33">
								    
                                    <i class='fa fa-question-circle'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl11_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਐੱਫ ਏ ਕਿਊ/FAQ</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl12_liItem">
							<a href="UserManual.aspx?itemPID=35">
								    
                                    <i class='fa fa-user'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl12_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਉਪਯੋਗ ਪੁਸਤਕ/User Manual</span>
                                 
							</a>
							
							
							
                            
						</li>
					
                				
			</ul>
		</nav>
	</div>
</aside>


	    
		<div id="wrapper" >
            <div class="page-body">
                <div class="normalheader transition animated fadeIn small-header hide-mob hidden-xs hidden-sm">
				<div class="hpanel">
					<div class="panel-body">
						<div class="row">
							<div class="col-sm-12">
                                <div class="nav-pills bg-light breadcrumbs">
                                    <span id="SiteMapPath1"><a href="#SiteMapPath1_SkipLink" style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;">Skip Navigation Links</a><a id="SiteMapPath1_SkipLink"></a></span>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>

		<div class="content animate-panel">
            

    <div id="ContentPlaceHolder1_UpdatePanel111">
	

            <input type="submit" name="ctl00$ContentPlaceHolder1$btnShowPopup" value="" id="ContentPlaceHolder1_btnShowPopup" style="display: none" />
            <div class="content transition animated fadeIn">
                <div class="panel hpanel dblue">
                    <div class="panel-heading">
                        <div class="form-horizontal text-center">
                            <h3 class="font-resize-heading"><b>ਪਰਿਵਾਰਕ ਵੰਡ ਲਈ ਬੇਨਤੀ
                                <br />
                                Request for Family Partition </b></h3>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="form-horizontal">

                            
                            <fieldset id="ContentPlaceHolder1_FieldsetApplicantDetail" class="form_ font-resize-scope" style="background-color: white">
                                <legend id="ContentPlaceHolder1_legendApplication" class="lg p-sm text-left head-legend">
                                    <i class="fa fa-info-circle hidden"></i>
                                    <span id="ContentPlaceHolder1_lblApplicantDetailH2">1. ਬਿਨੈਕਾਰ ਦਾ ਵੇਰਵਾ/Details of Applicant</span>
                                </legend>

                                <div id="ContentPlaceHolder1_updtApplicant">
		
                                        <div id="ContentPlaceHolder1_pnlApplicantInfo">
			
                                            <div class="row form-group">
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਨਾਮ/Name of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Name</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtName" type="text" maxlength="200" id="ContentPlaceHolder1_txtName" tabindex="1" class="form-control label-lg-font-size" />

                                                </div>
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="ContentPlaceHolder1_Label6" class="label-lg-font-size">Gender</span>

                                                    
                                                    <select name="ctl00$ContentPlaceHolder1$ddlGenderA" id="ddlGenderA" tabindex="2" class="form-control" RepeatDirection="Horizontal">
				<option selected="selected" value="0">Select</option>
				<option value="1">ਮਹਿਲਾ/Female</option>
				<option value="2">ਪੁਰਸ਼/Male</option>

			</select>
                                                </div>


                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="lblFatherNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦੇ ਪਿਤਾ ਦਾ ਨਾਮ/Name of Father of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVFatherName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Father Name</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtFatherName" type="text" maxlength="200" id="ContentPlaceHolder1_txtFatherName" tabindex="3" class="form-control label-lg-font-size" />

                                                </div>
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="lblGrandFatherName" class="label-lg-font-size">Name of Grandfather/Father-in-law/ਦਾਦਾ/ਸਹੁਰਾ ਜੀ ਦਾ ਨਾਮ<span class="text-danger">*</span></span>
                                                    <span id="ContentPlaceHolder1_RFVGrandFatherName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Grandfather/Father-in-law</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtGrandFatherName" type="text" maxlength="200" id="ContentPlaceHolder1_txtGrandFatherName" tabindex="4" class="form-control label-lg-font-size" />

                                                </div>
                                            </div>
                                            <div class="row form-group">

                                                <div class="col-sm-4 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblMobileNumberH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਮੋਬਾਈਲ ਨੰ./Mobile No. of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Mobile number</span>
                                                    <span id="ContentPlaceHolder1_REVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter a valid 10-digit mobile number.</span>
                                                    <input name="ctl00$ContentPlaceHolder1$txtMobileNumber" type="text" maxlength="10" id="ContentPlaceHolder1_txtMobileNumber" tabindex="5" class="form-control label-lg-font-size" />


                                                </div>

                                                <div id="ContentPlaceHolder1_pnlOTP">
				
                                                    <div class="col-sm-2 m-t-sm" style="margin-top: 30px">

                                                        
                                                        <a id="ContentPlaceHolder1_btnGetOtp" tabindex="6" class="btn btn-primary" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ContentPlaceHolder1$btnGetOtp&quot;, &quot;&quot;, true, &quot;GrpRequestotp&quot;, &quot;&quot;, false, true))">
                                                         <i class="fas fa-mobile"></i> ਓਟੀਪੀ ਭੇਜੋ/Send OTP
                                                        </a>

                                                    </div>
                                                    <div class="col-sm-2 m-t-sm">
                                                        
                                                    </div>
                                                    <div class="col-sm-2 m-t-sm">
                                                        <span id="ContentPlaceHolder1_lblVerifyOTP" class="label-lg-font-size">ਓਟੀਪੀ/OTP<span class="text-danger">*</span>
											        </span>

                                                        <span id="ContentPlaceHolder1_RequiredFieldValidator2" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the OTP number</span>
                                                        <input name="ctl00$ContentPlaceHolder1$txtOTP" type="text" maxlength="10" id="ContentPlaceHolder1_txtOTP" tabindex="7" class="form-control label-lg-font-size" />
                                                    </div>
                                                    <div class="col-sm-2 m-t-sm" style="margin-top: 30px">
                                                        
                                                        

                                                        <a id="ContentPlaceHolder1_btnOTPVerify" tabindex="8" class="aspNetDisabled btn btn-primary">
                                                         <i class="fas fa-check-circle"></i>ਓਟੀਪੀ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ/Verify OTP

                                                        </a>

                                                    </div>
                                                
			</div>
                                            </div>
                                        
		</div>
                                    
	</div>
                            </fieldset>


                            <div id="ContentPlaceHolder1_updtForm">
		
                                    
                                    
                                
	</div>
                            
                            
                            
                            
                            
                            
                            




                            <div id="ContentPlaceHolder1_pnlmsgConfirm" class="sweet-modal" style="display: none;">
		
                                <div class="sweet-modal-header">
                                    Alert
                                </div>
                                <div class="sweet-modal-body">
                                    
                                </div>
                                <div class="sweet-modal-footer">
                                    <input type="submit" name="ctl00$ContentPlaceHolder1$btnOK" value="OK" id="ContentPlaceHolder1_btnOK" class="btn" />
                                </div>
                            
	</div>
                            



                        </div>
                    </div>
                </div>
            </div>
        
</div>


            
			
			
			
			
			
			
		</div>

    </div>
    <!-- Footer-->
    <footer class="footer footer-font">

    <!-- Govt -->
    <div class="digi-topBoderThickDis">
        <div class="container-fluid text-center">
            <span>ਮਾਲ, ਮੁੜ ਵਸੇਬਾ ਅਤੇ ਆਪਦਾ ਪ੍ਰਬੰਧਨ ਵਿਭਾਗ,ਪੰਜਾਬ ਸਰਕਾਰ, ਭਾਰਤ / Department of Revenue, Rehabilitation and Disaster Management, Government of Punjab, India.
            </span>
        </div>
    </div>

    <!-- Copyright -->
    <div class="digi-topBoder">
        <div class="container-fluid text-center">
            <span>ਕਾਪੀਰਾਈਟ © 2025 ਪੰਜਾਬ। ਸਾਰੇ ਹੱਕ ਰਾਖਵੇਂ ਹਨ। / Copyright © 2025  Punjab. All rights reserved.
            </span>
        </div>
    </div>

    <!-- Stats -->
    <div class="digi-topBottomBoder footer-stats">
        <div class="container-fluid">
            <div class="footer-stats-row">
                <span class="badge-pill">
                    ਕੁੱਲ ਵਿਜ਼ਿਟਰ/Total Visitors :
                    <span id="lblv">2380020</span>
                </span>

                <span class="badge-pill">
                    ਆਖਰੀ ਵਾਰ ਅੱਪਡੇਟ ਕੀਤਾ/Last Updated :
                    <span id="lblud">12/10/2026</span>
                </span>
            </div>
        </div>
    </div>

</footer>

</div>	          
    <script src="ui-assets/vendor/bootstrap/dist/js/bootstrap.min.js" nonce="jW2m3XxhDx1VexjefAfLIg"></script>
	<script src="ui-assets/vendor/datatables_with_buttons/datatables.min.js" nonce="jW2m3XxhDx1VexjefAfLIg"></script>
	<script src="ui-assets/vendor/virtual-keyboard/js/keyboard.js" type="text/javascript" nonce="jW2m3XxhDx1VexjefAfLIg"></script>
 <!-- App scripts -->
    <script src="ui-assets/scripts/homer.js" nonce="jW2m3XxhDx1VexjefAfLIg"></script>
    <script src="ui-assets/Pgscript/masterpg.js" nonce="jW2m3XxhDx1VexjefAfLIg"></script>
    <script src="ui-assets/scripts/select2.min.js" nonce="jW2m3XxhDx1VexjefAfLIg" > </script>
    <script src="ui-assets/scripts/BackToTopN.js" nonce="jW2m3XxhDx1VexjefAfLIg" > </script>              
</div>

<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("SelectRegion_RFVDistrict"), document.getElementById("SelectRegion_RFVTehsil"), document.getElementById("SelectRegion_RFVVillage"), document.getElementById("SelectRegion_RFVYear"), document.getElementById("ContentPlaceHolder1_RFVName"), document.getElementById("ContentPlaceHolder1_RFVFatherName"), document.getElementById("ContentPlaceHolder1_RFVGrandFatherName"), document.getElementById("ContentPlaceHolder1_RFVMobileNumber"), document.getElementById("ContentPlaceHolder1_REVMobileNumber"), document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var SelectRegion_RFVDistrict = document.all ? document.all["SelectRegion_RFVDistrict"] : document.getElementById("SelectRegion_RFVDistrict");
SelectRegion_RFVDistrict.controltovalidate = "SelectRegion_ddlDistrict";
SelectRegion_RFVDistrict.focusOnError = "t";
SelectRegion_RFVDistrict.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District";
SelectRegion_RFVDistrict.display = "Dynamic";
SelectRegion_RFVDistrict.validationGroup = "ChangeRegion";
SelectRegion_RFVDistrict.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVDistrict.initialvalue = "";
var SelectRegion_RFVTehsil = document.all ? document.all["SelectRegion_RFVTehsil"] : document.getElementById("SelectRegion_RFVTehsil");
SelectRegion_RFVTehsil.controltovalidate = "SelectRegion_ddlTehsil";
SelectRegion_RFVTehsil.focusOnError = "t";
SelectRegion_RFVTehsil.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil";
SelectRegion_RFVTehsil.display = "Dynamic";
SelectRegion_RFVTehsil.validationGroup = "ChangeRegion";
SelectRegion_RFVTehsil.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVTehsil.initialvalue = "";
var SelectRegion_RFVVillage = document.all ? document.all["SelectRegion_RFVVillage"] : document.getElementById("SelectRegion_RFVVillage");
SelectRegion_RFVVillage.controltovalidate = "SelectRegion_ddlVillage";
SelectRegion_RFVVillage.focusOnError = "t";
SelectRegion_RFVVillage.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village";
SelectRegion_RFVVillage.display = "Dynamic";
SelectRegion_RFVVillage.validationGroup = "ChangeRegion";
SelectRegion_RFVVillage.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVVillage.initialvalue = "";
var SelectRegion_RFVYear = document.all ? document.all["SelectRegion_RFVYear"] : document.getElementById("SelectRegion_RFVYear");
SelectRegion_RFVYear.controltovalidate = "SelectRegion_ddlYear";
SelectRegion_RFVYear.focusOnError = "t";
SelectRegion_RFVYear.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year";
SelectRegion_RFVYear.display = "Dynamic";
SelectRegion_RFVYear.validationGroup = "ChangeRegion";
SelectRegion_RFVYear.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVYear.initialvalue = "";
var ContentPlaceHolder1_RFVName = document.all ? document.all["ContentPlaceHolder1_RFVName"] : document.getElementById("ContentPlaceHolder1_RFVName");
ContentPlaceHolder1_RFVName.controltovalidate = "ContentPlaceHolder1_txtName";
ContentPlaceHolder1_RFVName.focusOnError = "t";
ContentPlaceHolder1_RFVName.errormessage = "Please enter the Name";
ContentPlaceHolder1_RFVName.display = "Dynamic";
ContentPlaceHolder1_RFVName.validationGroup = "GrpRequest";
ContentPlaceHolder1_RFVName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVName.initialvalue = "";
var ContentPlaceHolder1_RFVFatherName = document.all ? document.all["ContentPlaceHolder1_RFVFatherName"] : document.getElementById("ContentPlaceHolder1_RFVFatherName");
ContentPlaceHolder1_RFVFatherName.controltovalidate = "ContentPlaceHolder1_txtFatherName";
ContentPlaceHolder1_RFVFatherName.focusOnError = "t";
ContentPlaceHolder1_RFVFatherName.errormessage = "Please enter the Father Name";
ContentPlaceHolder1_RFVFatherName.display = "Dynamic";
ContentPlaceHolder1_RFVFatherName.validationGroup = "GrpReques";
ContentPlaceHolder1_RFVFatherName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVFatherName.initialvalue = "";
var ContentPlaceHolder1_RFVGrandFatherName = document.all ? document.all["ContentPlaceHolder1_RFVGrandFatherName"] : document.getElementById("ContentPlaceHolder1_RFVGrandFatherName");
ContentPlaceHolder1_RFVGrandFatherName.controltovalidate = "ContentPlaceHolder1_txtGrandFatherName";
ContentPlaceHolder1_RFVGrandFatherName.focusOnError = "t";
ContentPlaceHolder1_RFVGrandFatherName.errormessage = "Please enter the Grandfather/Father-in-law";
ContentPlaceHolder1_RFVGrandFatherName.display = "Dynamic";
ContentPlaceHolder1_RFVGrandFatherName.validationGroup = "GrpReques";
ContentPlaceHolder1_RFVGrandFatherName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVGrandFatherName.initialvalue = "";
var ContentPlaceHolder1_RFVMobileNumber = document.all ? document.all["ContentPlaceHolder1_RFVMobileNumber"] : document.getElementById("ContentPlaceHolder1_RFVMobileNumber");
ContentPlaceHolder1_RFVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
ContentPlaceHolder1_RFVMobileNumber.focusOnError = "t";
ContentPlaceHolder1_RFVMobileNumber.errormessage = "Please enter the Mobile number";
ContentPlaceHolder1_RFVMobileNumber.display = "Dynamic";
ContentPlaceHolder1_RFVMobileNumber.validationGroup = "GrpRequestotp";
ContentPlaceHolder1_RFVMobileNumber.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVMobileNumber.initialvalue = "";
var ContentPlaceHolder1_REVMobileNumber = document.all ? document.all["ContentPlaceHolder1_REVMobileNumber"] : document.getElementById("ContentPlaceHolder1_REVMobileNumber");
ContentPlaceHolder1_REVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
ContentPlaceHolder1_REVMobileNumber.focusOnError = "t";
ContentPlaceHolder1_REVMobileNumber.errormessage = "Please enter a valid 10-digit mobile number.";
ContentPlaceHolder1_REVMobileNumber.display = "Dynamic";
ContentPlaceHolder1_REVMobileNumber.validationGroup = "GrpRequestotp";
ContentPlaceHolder1_REVMobileNumber.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ContentPlaceHolder1_REVMobileNumber.validationexpression = "^[6-9]\\d{9}$";
var ContentPlaceHolder1_RequiredFieldValidator2 = document.all ? document.all["ContentPlaceHolder1_RequiredFieldValidator2"] : document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2");
ContentPlaceHolder1_RequiredFieldValidator2.controltovalidate = "ContentPlaceHolder1_txtOTP";
ContentPlaceHolder1_RequiredFieldValidator2.focusOnError = "t";
ContentPlaceHolder1_RequiredFieldValidator2.errormessage = "Please enter the OTP number";
ContentPlaceHolder1_RequiredFieldValidator2.display = "Dynamic";
ContentPlaceHolder1_RequiredFieldValidator2.validationGroup = "GrpRequestVOTP";
ContentPlaceHolder1_RequiredFieldValidator2.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RequiredFieldValidator2.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        
theForm.oldSubmit = theForm.submit;
theForm.submit = WebForm_SaveScrollPositionSubmit;

theForm.oldOnSubmit = theForm.onsubmit;
theForm.onsubmit = WebForm_SaveScrollPositionOnSubmit;
WebForm_AutoFocus('ContentPlaceHolder1_txtName');Sys.Application.add_init(function() {
    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":500,"dynamicLayout":true}, null, null, $get("updWebsite"));
});

document.getElementById('SelectRegion_RFVDistrict').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVDistrict'));
}

document.getElementById('SelectRegion_RFVTehsil').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVTehsil'));
}

document.getElementById('SelectRegion_RFVVillage').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVVillage'));
}

document.getElementById('SelectRegion_RFVYear').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVYear'));
}

document.getElementById('ContentPlaceHolder1_RFVName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVName'));
}

document.getElementById('ContentPlaceHolder1_RFVFatherName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVFatherName'));
}

document.getElementById('ContentPlaceHolder1_RFVGrandFatherName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVGrandFatherName'));
}

document.getElementById('ContentPlaceHolder1_RFVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVMobileNumber'));
}

document.getElementById('ContentPlaceHolder1_REVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_REVMobileNumber'));
}

document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2'));
}
Sys.Application.add_init(function() {
    $create(Sys.Extended.UI.ModalPopupBehavior, {"backgroundCssClass":"modalBackground","cancelControlID":"ContentPlaceHolder1_btnOK","dynamicServicePath":"/RequestForPartition.aspx","id":"ModalPopupExtenderAlert","popupControlID":"ContentPlaceHolder1_pnlmsgConfirm"}, null, null, $get("ContentPlaceHolder1_btnShowPopup"));
});
//]]>
</script>
</form>

</body>

</html>
