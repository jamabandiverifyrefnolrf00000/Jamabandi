

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><title>
	ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records
</title>

    <!-- Vendor styles -->
    <link href="../ui-assets/vendor/bootstrap/dist/css/bootstrap.css" rel="stylesheet" /><link href="../ui-assets/sweetalert/sweetalert2.min.css" rel="stylesheet" />

    <!-- App styles -->
    <link rel="stylesheet" href="../ui-assets/styles/style.css" /><link href="../ui-assets/styles/plrs-custom-v1.0.css" rel="stylesheet" /></head>
<body>
    <form method="post" action="./Login.aspx" onsubmit="javascript:return WebForm_OnSubmit();" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="aYY5o9FmqUu4S59KYhK8WPkyJSf5dI8lTBkS+se+by/YacqwRnoH5oqQ3p0CCKzwEM861KlyFwv3g+mudP2tNtzWyTginFVsuHoacovydgoEXCVviAzM9J1Dzll7obwBdaZUrf/SbQKeWjFMQb9+JrlhOjqYPxTP9JB2xJgly2ZrjpNaVmSUnh8/oGjcBj3VXxvdfv3inYn1+2TNyJUdWFrrQmzl5SfMJWAB6s7boiTl+oX7N8GML+q/fkAwZZBpVdy5tGnS5QlWd033/8hIqCGtR2rx6+ZNDdb1i5cvjpDNbXb0Yw/P8IIt/0snmU08" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZBbRI-vLFGPASeYxh_KgLGJAGhxxxQHaAFUowMEJ38zbzJMIHhOPM0QVtz7ClVSrJw2&amp;t=639202794265548063" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1HoTsDJCIwegf7-cSVNQxKlxqJplUAag2gjZMR_ctGyeKzMDbl61mq8CG1bXK2cKIO5F_d_eACHU7rvEovdRsHjPwMxL_2RbhdHxnXThSzdTd55hY37B50zmwPwIsJ1FnQ2&amp;t=4623e90" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvqBoWBYTDUGuawA_2GYbNQlKfMSt2G6fTRv2v_CvkMQC-NDKOxcBHZBsr4m43UZoWnDElLWlfRSMae7wFN5-j848Bfbquym3Qmm_a4KPTP8MlNJWDtdRKeoXno9ND71Mj-dmT4RATMPqWph8tRm5et41&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OAh7tEdde-lvG3-30egxXz8aAgw_K6hDRuGQnL44pJNvGX0k88IpkhwtBpf_hp5FI_xl-S6IOzDAoSwTftgBkdwIVbozv2itakdYRoj6lyvW2iAmc3lxcxcAsYCLcWBMdMG64QNAlb5JWK1NKm4PkKk1&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="C2EE9ABB" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="IzPTNfy4LwxOzPwZfkDSYqQa9bzeQL1Sn3aMMQvIqQwb9U9EAOOpjJjkPDBSY5/ZJlGoOhY2xlR5VcPbJEzpLhZ3pagzVBEwPghoBmhmafrbKdfc5eP02gtE3Z4mfFrwDrli2wOD4PevHhFYAZFVl9AF3V+zIEDxN5oG2aDfPJ5fJbkYUEESedXQanhG59NHaw15y9skdspTy+pO3pgksJFRkDN0GQwIExdIDNE6hpyNsHpQPWSCBu3gs7vsPGHp" />
</div>
        <input type="hidden" name="__CSRFToken" id="__CSRFToken" value="9e8cab14b49a423e888c89683b666aa3" />
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ScriptManager1', 'form1', ['tupdLogin','updLogin'], [], [], 90, '');
//]]>
</script>

        <div class="splash">
            <div class="color-line"></div>
            <div class="splash-title">
                <img src="../ui-assets/images/pbLogo_84x101.png" />
                <h1>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h1>
                <p>Please wait while we setup the module for you. </p>
                <img src="../ui-assets/images/loading-bars.svg" width="64" height="64" />
            </div>
        </div>
        <div id="updWebsite" style="display:none;">
	
                <div class="loadingContainer">
                    <div class="loading">
                        <img src="../ui-assets/images/loading-bars.svg" width="64" height="64" />
                    </div>
                </div>
            
</div>
        <div class="color-line"></div>
        

        <div class="login-container">
            <div class="hpanel">
                <div class="panel-body">
                    <div class="row">

                        <div class="col-md-12">
                            <div class="text-center m-b-md">
                                <img src="../ui-assets/images/pbLogo_64x77.png" width="50" height="50" />
                                <h4>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h4>
                                <small>
                                    <span id="lblcmsg" class="text-danger">Please login to continue!</span></small>
                            </div>
                            <div>
                            </div>
                            <div class="row" style="border-top: solid; border-top-color: black; border-top-width: thin">
                                <div id="updLogin">
	
                                        <div class="panel-body">
                                            <div class="form-group">
                                                <label class="control-label" for="username">Username</label>
                                                <input name="txtUserName" type="text" id="txtUserName" class="form-control" placeholder="Please enter username" />
                                                <span id="reqUname" class="text-danger" style="display:none;">Required.</span>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label" for="password">Password</label>
                                                <input name="txtPassword" type="password" id="txtPassword" class="form-control" placeholder="******" />
                                                <span id="reqPassword" class="text-danger" style="display:none;">Required.</span>
                                            </div>
                                            <div class="form-group">
                                                <img id="imgCaptcha" src="GenerateCaptcha.aspx?639274832313373360" />
                                                <input type="submit" name="btnRefresh" value="Refresh" id="btnRefresh" class="btn btn-success" />
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label" for="captcha">Enter Captcha</label>
                                                <input name="txtCaptcha" type="text" id="txtCaptcha" class="form-control" style="width:200px;" />
                                                <span id="reqCaptcha" class="text-danger" style="display:none;">Required.</span>
                                            </div>
                                            <input type="submit" name="btnLogin" value="Login" onclick="javascript:return hashpassword();WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;btnLogin&quot;, &quot;&quot;, true, &quot;login&quot;, &quot;&quot;, false, false))" id="btnLogin" class="btn btn-primary btn-block" />
                                            <div class="col-12 ms-2">
                                                <br />
                                                <span id="lblMsg"></span>
                                            </div>


                                        </div>
                                        
                                        <input type="hidden" name="hdnfld" id="hdnfld" value="$2a$10$2DwUjxh.raCPvLH01ZL12u" />

                                    
</div>
                                <div class="col-sm-12 text-right" style="border-top: solid; border-top-color: black; border-width: thin">
                            <a href="ForgotPassword.aspx" style="color: blue; text-decoration: underline">Forgot Password</a>
                        </div>
                            </div>
                        </div>
                        
                    </div>
                    
                    <div class="row" style="border-top: solid; border-top-color: black; border-top-width: thin">
                        
                        <div class="col-sm-12 text-right" style="border-top: solid; border-top-color: black; border-width: thin">
                            <a href="Default.aspx" style="color: blue; text-decoration: underline"><- Back to Home Page</a>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    
<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("reqUname"), document.getElementById("reqPassword"), document.getElementById("reqCaptcha"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var reqUname = document.all ? document.all["reqUname"] : document.getElementById("reqUname");
reqUname.controltovalidate = "txtUserName";
reqUname.focusOnError = "t";
reqUname.errormessage = "Required.";
reqUname.display = "Dynamic";
reqUname.validationGroup = "login";
reqUname.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
reqUname.initialvalue = "";
var reqPassword = document.all ? document.all["reqPassword"] : document.getElementById("reqPassword");
reqPassword.controltovalidate = "txtPassword";
reqPassword.focusOnError = "t";
reqPassword.errormessage = "Required.";
reqPassword.display = "Dynamic";
reqPassword.validationGroup = "login";
reqPassword.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
reqPassword.initialvalue = "";
var reqCaptcha = document.all ? document.all["reqCaptcha"] : document.getElementById("reqCaptcha");
reqCaptcha.controltovalidate = "txtCaptcha";
reqCaptcha.focusOnError = "t";
reqCaptcha.errormessage = "Required.";
reqCaptcha.display = "Dynamic";
reqCaptcha.validationGroup = "login";
reqCaptcha.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
reqCaptcha.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        Sys.Application.add_init(function() {
    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":500,"dynamicLayout":true}, null, null, $get("updWebsite"));
});

document.getElementById('reqUname').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('reqUname'));
}

document.getElementById('reqPassword').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('reqPassword'));
}

document.getElementById('reqCaptcha').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('reqCaptcha'));
}
//]]>
</script>
</form>
    <script src="../ui-assets/jquery/jquery.min.js"></script>
    <script src="../ui-assets/vendor/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../ui-assets/scripts/select2.min.js"></script>

    <script src="../ui-assets/scripts/JCrypt.js"></script>
    <!-- Vendor scripts -->
    <script src="../ui-assets/sweetalert/sweetalert2.all.min.js"></script>
    <!-- App scripts -->
    <script src="../ui-assets/scripts/homer.js"></script>
    <script src="../ui-assets/scripts/bank-custom-v1.0.js"></script>

</body>
</html>
