
<!DOCTYPE html>
<html lang="en">


<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="google" content="notranslate" /><title>
	ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records
</title><link rel="stylesheet" href="ui-assets/fontawesome/css/fontawesome.css" /><link rel="stylesheet" href="ui-assets/fontawesome/css/solid.css" /><link rel="stylesheet" href="ui-assets/vendor/bootstrap/dist/css/bootstrap.css" /><link href="ui-assets/sweetalert/sweetalert2.min.css" rel="stylesheet" /><link rel="stylesheet" href="ui-assets/vendor/datatables_with_buttons/datatables.min.css" />
    <!-- pe-icon-7-stroke styles -->
	<link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" /><link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/helper.css" />
	 <!-- Custom styles -->
    
    <link rel="stylesheet" href="ui-assets/vendor/virtual-keyboard/css/keyboard.css" /><link rel="stylesheet" href="ui-assets/styles/style.css" /><link rel="stylesheet" href="ui-assets/styles/responsive.css" /><link rel="stylesheet" href="ui-assets/styles/plrs-custom-v1.0.css" /><link rel="stylesheet" href="ui-assets/styles/CardStyle.css" /><link rel="stylesheet" href="ui-assets/styles/custom.css" /><link href="ui-assets/landingPage/css/style.css" rel="stylesheet" type="text/css" /><link href="ui-assets/landingPage/css/flexslider.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="ui-assets/styles/select2.min.css" /><link rel="stylesheet" href="ui-assets/styles/selectStyle.css" /><link rel="stylesheet" href="ui-assets/styles/backToTop.css" /> 
<style>
    .d-flex{
        display:flex;
    }

    .margin-left-right-auto{
        margin-left:auto;
        margin-right:auto;
    }

    .margin-left-right-auto h3 {
      color: #ffffff;/*#126f00*/
    }

    .head-legend {
      padding: 20px 0;
    }

    .head-legend span {
      font-size: 20px;
    }

    .digi-pub-footer-top{
        padding: 25px 0 10px;
    }
</style>
    <style>
#SelectRegion_rdPeriod {
  height: auto;
}
</style>
    
    <link href="ui-assets/styles/plrsheader.css" rel="stylesheet" />

     <script   src="ui-assets/jquery/jquery.min.js" nonce="MMmg0qMgTQVFV48LiweQeA">
	</script>
	
    <script   src="ui-assets/jquery-ui/jquery-ui.min.js" nonce="MMmg0qMgTQVFV48LiweQeA" >
    </script>
       
     <script src="ui-assets/sweetalert/sweetalert2.all.min.js" 
        nonce="MMmg0qMgTQVFV48LiweQeA" ></script> 
           
    <script src="ui-assets/scripts/plrs-custom-v1.0.js" nonce="MMmg0qMgTQVFV48LiweQeA">
	    </script>

    <link href="ui-assets/fontawesome-free/css/all.min.css" rel="stylesheet" />
    <link href="ui-assets/styles/modalp.css" rel="stylesheet" />
    <link href="ui-assets/styles/HightLightFocus.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/reqRPT.css" rel="stylesheet" />
    <link href="ui-assets/jquery-ui/jquery-ui.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/tblbrder.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/lnkbtn.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/rdbtn.css" rel="stylesheet" />

    <script src="ui-assets/jquery/jquery.js"></script>
    <script src="ui-assets/jquery-ui/jquery-ui.min.js"></script>
    <script src="ui-assets/scripts/HightLightFocus.js"></script>
    <script src="ui-assets/Pgscript/reqRPT.js"></script>
    <script src="ui-assets/Pgscript/MaintaineScrollbarPosition.js"></script>

    <script src="ui-assets/Pgscript/genderOtherjs.js"></script>
    <script src="ui-assets/Pgscript/genderCourtjs.js"></script>
    <script src="ui-assets/Pgscript/genderjs.js"></script>

    <script type="text/javascript">
        function validateCheckboxes(sender, args) {
            var listViewRapat = document.getElementById('ContentPlaceHolder1_lstMultiKhasra');
            var isChecked = true;

            if (listViewRapat != null) {
                var checkboxes = listView.querySelectorAll("input[type='checkbox']");
                var isChecked = false;

                checkboxes.forEach(function (checkbox) {
                    if (checkbox.checked) {
                        isChecked = true;
                    }
                });
            }
            args.IsValid = isChecked;
        }
        function validateCheckboxesCourt(sender, args) {
            var listViewRapatCourt = document.getElementById('ContentPlaceHolder1_lstMultiKhasraCourt');
            var isChecked = true;

            if (listViewRapatCourt != null) {
                var checkboxes = listView.querySelectorAll("input[type='checkbox']");
                var isChecked = false;

                checkboxes.forEach(function (checkbox) {
                    if (checkbox.checked) {
                        isChecked = true;
                    }
                });
            }
            args.IsValid = isChecked;
        }

        function validateCheckboxesOther(sender, args) {
            var listViewRapatOther = document.getElementById('ContentPlaceHolder1_lstMultiKhasraOther');
            var isChecked = true;

            if (listViewRapatOther != null) {
                var checkboxes = listView.querySelectorAll("input[type='checkbox']");
                var isChecked = false;

                checkboxes.forEach(function (checkbox) {
                    if (checkbox.checked) {
                        isChecked = true;
                    }
                });
            }
            args.IsValid = isChecked;
        }
    </script>
</head>
<body class="bg">
  
	<form method="post" action="./RequestForRapat.aspx" onsubmit="javascript:return WebForm_OnSubmit();" id="form1" enctype="multipart/form-data">
<div class="aspNetHidden">
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="M42+EuQfIb5M/eU9OkHodkax28mIJ/TQjmMUrJCg4OGol94YJPCy9K/JMVJPS3I28ZAfezNI2HfxnWcNKwbQvhJa1C5aH4DyPVCKtYgEFHJbzTDTXs5bLQOWkrr6zhyPLQczVPDU3qgFz/HjLQHJX0bx7FUCd9heM41bYmsAnAugv9hpinC99r+LSs/vtuYAtfK42cOUogBdlQIHVaioOCjqOG6IDqR72cn3OIboZo+DPX1DsmwUhWm33Z/Sy64z1xriWhI7SiowD2yDwRLUbE12HUaRy9i9jGAQ2Iq5RB+cRzW6WJVm1TuvWIrTQkdBoNEEjGcxzPxKk74Iwym/kkdO4flye4Cs0FbnROE1R3u40VZk6ENmyn7iQrhsMTx4PHeEbgrqsWOknSkROz+1MsJbpEGi4ns878JVwJONYgIBWVIEN+Om+TttsJrCiOpgLrR0iuC+KOg1QANYopJAg3df4oeCTWDsWX8KtwXMU4kA1m+JEmbO5rCWsamQvYNLLuUaS+o57nzvQQm1tTFlwjMep2hB0319/cy00n3RwTg0spMU6BZQycpzLv06jmIqtdx1d9RQ/NLorvDMFik8NPi1JGVIb4VKIIvnt1WYvG2OXITB84k83eGMZWP0EF95F26dHkW40Xw1Nkf6QApKfWa1ZMzxAL5UaarAZgt4RcqS0bzpX1yMRb9O2WpcfmwoRyYxnUZaECkZqUN81qzqiXMcHrWgYFOQtU9T7brYzl4BQzus7+0rYa+Mw+1Iy9xfYLeCu8tJsoNAv2Yp+Ma7GNU73WPY38LlWW0TRgkEKyQ9qNjBVqO6ICSFTJCgbSxRd77towz7wh5HOeY+f9CZG187m+ZzMH9oF/nMvASNODBdvQhWXVvtTZWw5HuShg8uCDmXD03IXBXWEgXvQIq3VCVTEFc4i9doya0swevVcoDnL30+Fdm5dXs8gKOs83dM57eFfl0DFL7zrDw5G2dFr+sokhI//0E32qy2o10w/sIRJ9pX3/NdXZWcpNPOBo0ZrWmrouAn/0xcgWYJqPSKzSNPllzDf7fA1ZKsQGSV/jnTqRmnvzIkA5EuH52Q6hEb3jF8R72kUMv7f1s6yQImz0imX/m/2fYn/p/4sqvAG87s+62G+66E5lJ2raaRuKlGBYQg79Jwn6JR637MxF1QXM45W1caVeJY5whBDhTtHposFfiOfM8pubkzSYuOph664IjCJUWdo+FUHZIo5x5pZ+kgzFMBSP7y1Wl6vFoRgbZRnI8tl1NSBHOJ8pr1roTiIaTByZhF90Opu+VM4GjxYl8w9OVeK3y4ncQie0cPgIjryhsNlyAKvWVfc8vs37Qk/HHU4YAREWpOnuAFnVWefXiZweL3NcVkDseKxlDgFEFftxLSMte8PefW1K1tRuC9nJPdpgr/lUNnhC4Hp2AnBiP61mzUZs/dxb1n+ic5bK4q0IX6TBiP5b/79pMvqnHwCVWnmpWCLnxknCtDf+bAZWTKhpDWuMW/UO9FRSD99ay2mpvBL9bmFK8wYh9pwlhSSfjtjSzA3NnFkyYvOLTeeV6nofzNG4ag/Zm3UpyRPXO712Qu/w6pu9oBrsWEHHIGIQqVAXgk/pobvB/3E3HgIWIpgxvO5zq9oU2ZXDY9gZt/lEHixCza3XKaEC+VoWezqYnnJO8FVseDm8zDDOD3ExpWAL5vOW88PxVQAUPgBYOql+hPSo51y3Scl41nPeeCreRdIMwecCktMf0HGGzoAQPD6LlxW9zs7qW4L3ywqaKH/nP2fRszbq4UiqvX+zBy+Uf2hqs617J9KGl2erFWJRqNu963xMkwwgj6DuzCmRU6AruREC0HI1tzn1ljpz6By5gXVF7xqpA6fHhOvepwOhEFYZ6UyWyNY5dt7KY46SDzkoiBIR8lzVslwMHycO3F1jkcLJOb6zwB32D90/IwbPf0Fgul2X29hFi9qkCL0FSbGGK1tlosDzbJu25Hf8utV48rgDV+9AJcqf0qjA9B/pPPSIpTvLUHZk+N9x//fqtQETWWbF0vw9KXBu9jnK5w0YA3AGZjBJZrxPwxPY7I/Lo+FLjGEqUM/L1QwpKAfacnrM4863XKnz0HwHHhTrYfTYsF6Oogy96yrbNrwrQvFoIaHj4qNMA0DG5F/B/t2r/ajEDimsF5XzibZ7k2ryP/0cqKoIA+8RSymOEdE1NoFOttlyawOnGYnjsdaJHyIm1yf4vdi9s9tjN+b3es7nlYSdYh+AtLY4yCKAefCZ+TUvqXxFtOB1hFzbri1iZJ6leiDfwaaybpxucColC9LfIzJ5ZHCPFTM1r+q9uCU+hCuSfjc4B3V78k+ta8A4IGOWeBtJZqcSOxvZWTKjTubHYhdzcHqXolkWmJRcs6zXoQr7QjZbyxInz0m7SsI79B+wd15cjDa+xVktQlN5DXqK+U/US7L65o5T0Boh09G0Peofil72rrY4HpoVBRZn4bU+q3qE08Ln4H09ipcGHVZadG72yEI8PLsfRAV8L8ykzcd+Ixvcxyws6u61K6JQ3ZubpmEj9NIE8Tgd9zwxaKHMTp4tl29k9722dfQFfTvUlzSIn7IZIPDev3LkKzY1+ggkPqvKbQ0zGiJOgn+eZaB3iDWEqUJpb478XAiy2TEj7IFcYCmmXV3D3zkxi5WoyprnOkL+XG7wLnywJdU6GdxgKX8ZYTAy1sTvyQABDoj8u91a6sWaaJW53r7+8Z4VNE4K4wPkeC+pWfy/fmGAZBHqtB5nMVRj63ozLKDzMXmuQkHUu1TA8bM0dlRSVmQvNSJE0Ji+IDlUTzY+Ci1U6GtnJF+r8q/AwnQbORmZmuGJDwex00CD3Lf5A416iZCb/a57e5GUUfyDXxVZeFFqtb3Nar6NB7R4k4CU8f18cfMU3qOJ+1tcJ7zrXqF1Yolygtgsyg9pL31aXy/ErmoRcsv9GL1E2DNt7W/1H6JtqHUsV6XzUXGBQVPp2dcRPK3zdD/zbbwNLOVgWwr56DRqHupgtbROZmLDv5wVTBsDNEIbxtF/yCAAi47xf8kI91OUhTRbdL4fLhQHYFyy1LLCQDj8KueR1XSfN6w4CiYPQj36TQWSbhMrIDDxl6l2xmyKu4yU3wzKglKzfWkf13WTUA+/WHcJ4wXaKdoeRSfs9gldPvXYN0MuveL5GZSZi1O7W6FojEN/sz8VviPFAfrbsd1gMXdGxp/nH5mnYE+Y+DanOMLwLX0TkqH2jDS37fdHaBaqlkbBsmPiJOccL1GDIrVzPl4SqN33YT2NEPsydwLjDsclPGOjxcsBqE/I4A268RsyEElJT6/cowhL0cl3AUK0obxR4gBrkaVMUtiQI7WX0YYX8J1d8qsLhZJby996w0jarr5EolbP/3qcjxfmDfLEp+4TvU/TCT8EdTu2wOGEiGofn+AGGGdkdNz9G489Ojz2f0M9qvJvVQKzBYmOHSlA4PX6DCKNCOA7eDLWdtf4Zy8bBMufiDcZ70edINq9Cc4tcZU+Io+DqfKyX/9tlVs1c7rbP/M839CPl39UZs30oYd6OOXSH2LhZpSVYAgjfTMsJIX0Cy0L6rb3mM6ULI3wnqITi+zpMYq9mnuGeeWqjKuU5Cne61W1uj6LPH7msYxcsDZhkx19zy94D1IQQ3MPW0VEotvvdzFuAqTR90r8ujgLRozOlJPkmxiVAfO9JosHsoxPu3EsaK36KSPnAQQb9Jdh8i8SaxktgX6g8orf3PP+/kTP7Vy+zAjqERSePuk8Bmlshc4Ckt/N38wZ7mOeaSj1x1mETn0OoTfuHRDE9MtdK/yhRuWO59pMAYjZzMl9qEtchhmef5yzmaNBNE8jUbNWDGHPzVHQey9U3Wnzj/asV2dW31W/UGGd1ZE6YmE4cSYiEktqSZv8eD7eh0+IERXSm2AE1bVKicFll1ACm9DmKp/LlZFx0baI8qq/tGTSVkk4fPnfB1QxEnH1+4iYX+4cIFW1ot0oerq+ynzObRikH+e9I7yrUXncgID5gWI/KXmSJj94AKZkGgC1DoQ/w48eBwwJ+N42BcOddZ08/wYzP3gIXA6h30pvXO1RCnYFBZSn9fEuwv9qxbKEdP4E5P7hzeXO5qsGNAE2oeGutHkSGMkGbnxaBDsSDzdGAFVjBihzuNf4bw8EpL21wfskzI0goDF/cpiDW7jq1OViaNUgLRZxHBRPX+7GDemm0eOMCu8owHFSOOlvRlsuAMrorSGe72PJEnCie+josk19AwY0Jda7KgOdTovGLuA074x9Cd2yVO5F7S6uyZESmbI9xm2BKbC0h9+sUJcqsuPbVjInO0wdW30G/KFXyzdnX8wohftsZgpOTsiK4rZq1Xys/rVsghY8oRbIRDehVlkOwzo4D5ghojaAAKPmErj2q4l3vzqdtKhXmJaD6M8ZRH/VFKQxbKmcpHSTA8WdzsqZuAftU0AoLZdTXJDQqbf2EKXDGA+sbz72Kx2OumRSY461kEAQI8voFiNHSuPJx8pMT0SknsCtrIeoNFSTGOY0FlZ8oL4Cu+L/hhKQ50L/izdRO1HKfdjlwl4IiP8hoPqE+idpR1olWH1iRo8nMdDdpHQ8QSEOlWV3ZDY4klRvQdBAniXPtvnQpluotw7BDMbOWdXgKNx9dWqrizdyuaT1FdS+1og+v7KDXFNt9BtNzCsLuWaNhrAbweLky4aH9WiV1nyL7f4RXxnwuO7zUfkdUvfUxWJ6bbRr0gZ22mMXu76+bAyd/EYBZdzA2WRecjJKQnY/HCpvKkodBEMwNau4lC5kaCchDZ8orm9CK4dzu9me+NGVjoxus8f7et7J30TZphNAgcd4FSnABSYwakPfX+1PggizBioMovDl4oTNRBG1Ey7FzUJHAflV15+BcQ32lCCR+RbN8fCuo8f6uRKHLODPLdIU8VLZd5kx9ccrWlosK8CaCoOjJafJ6yUteBj6TxpLn/4OuRzg2tnvO2N1ct9X2e3Qq9SlYR4niJ2ruuCJmill7sMZkRCjZoYbbeVKuJaxpcaVwPHxltAdQB08snhxRJRI2xdfJeYSN6pbfbkVW1Eu4aE0i3IDLcnv6tNAL1NW3bJKIQtY2JEUlXTbGQkcqb4ypQnOaNkwSGs2Pq30VpCt+msGIA/+D20gVtQc80Za3L9B9gpyNH+kbVUgZlw9d5+QmdsNSukripIa72Wjrb6HRRLkCbelcMWWWeeayAm0U/zAy8eziukCw2faP0rN6GJxGvHmTOM5sy9R6l1u5cFuGMVY94qvYyeQQjQ1epSYJr9IjgLzUXPAeElnXkE7MFrKl4AfVe+qAlNem3I0E/5Qs06gVrXHZjO0gXJZQ6TJY2lR7B1v4xh0h3yPXszSESoW+gOZs808tzsNsd+K1sYLhUh/GGEgfcGg0lfIujrO9ghJD27hR/6XBJkZFh0A+M2jzMfYc2yKpFhY4fiQ6QvpjpoXNDE7sUSTOCYYLpXie8M3QjSKKr6IXhUKL53Ku5cIUZsVuY2zQ4GGXuSn7zPr38SuuTfdBemMbC5eiz8BVzoRVHpL72Ry6pqmINuyoE1Vmw+7GoGqB5Lydvcb5fC75vNSMnUVQiCEaPfLqU9GIiuU+aCgee1Dc0Z8dhGpQB6JE+1FYMwmJYKSrccsmk/tDDv6CusYQCNqGpCZ3O5Y+FAKM/DUhXaQ7fG6jAYlmMxOlM0+QuUXdBBgmuthH+zKCq4TjINdey5nerMrOrsquZ63sacgAmNoux/4WDpKWgh/RpH9ktlatueT1/FQJX5ibOmB5AIBdbBzk6kqKcGbcJ/n4Ndlq6Tv6rkePOj8XXge+YfbFFqZ9NbR8DRCJ+HDZHpb6STUyN2YlkI9SHDAaQwnzYK7eEPbNkFtOhtwymwSMwDTxrDeQWm/+qIHhuwCYQqLxzzcqgTRZLZrrLre++1PWMuVTyW6RBsMuGz6LPVuSmfLHqYaEaSe0dBrinYh6urp5iLJwG22lzqsrxcxirQzIdiQcKhcFq6uox8BIMCI+GCB08m/cgKVTj20KAU/TIJ+08xbTeVnukbCe7EBCBmyY9oQKN/WuLyAtWFODNDhk9kjZvO8F0G91V7Tp0cIZq2VfCFGiNEjM9Bva7vkIrIg203tduGgDVpr4mZhBcfvX2qGwbJt2LCyqw9t8Uq2OqSmTMNqb2sKWXS9EeAB8n8YA25nS2JifxDy7i1rAgabmNhxU+DnSHdbVSfi9x930iRkXUWFThClVjGepOfZc4t8mX6pAj2qxJPb7MBf+ZFR+vS6mM2xOwbAUh31Yvn1fohEv1xNTyddcQyOZO6BBq3a2DR1Mjxqn+/61AkLnJ1TmnKutztFpZUkYqfSkuHAfJv77Pnt38bLciQAvDuM2PBthBpCrEKg5qnS4r6bSJ35ec7UNXaJZFGsAl2AbtaP8EGHy/JKjGYXC1HM/QZgHA6r4AKNTkeH/1lgDhR0DMcEZaJcOaZ8m4PXuG0h/JrwrHM6oHOcC2ovYX5Cvs7Wq0wokRPSxQZyz/d1BrfkMLcmV6pWT2ThDh4l2B4JG4/bm5Ztxfqq3EkDcvyIw1Gkz5G5o38pnKUGDzJx5G1NBwN84tWtupmE/q1cPHiCYF1ZMmXRw2/SKDmlvaYDlRKw6Ows3ImGERnZKcj1/q3lVBhvPKyoU3D/rUmVExhoPQX0hjo1QO2XGNjovcYWDDNq0dDaaXmFSSjVQPnP3wV6n1I+hBsQl77yeRDmA/gXUpwox9NAWvTCGf6WfN8RHvxpNLazxqiXAmNUlrv25sEB9rhIwbaJW03XynK2QXI/X3ixLWP21V5H21+SmIWVb7ILiLu7L8MWqXS0EsaJW7QYgUl4JUyqgGan4SokmIWuvwtBXJUph5LkHgIRrovC+fo0GtI2XPafVCuYfMHr+Du8Es8oytFHeD5ablDzwNrJybePeA3Sren9z9HfCLNYTHHkaggqsVpxL0kI3uA42yQ1EQeBxUeyXSXjlU0nRzyd2tCkI9P9e8CsRz/hZgoQxQH7nNKXyH52jtqoAm+n75Fw7VfsdxHooIn3PPL6b7WvqOQt3e+Kn1VKxFypKnViYzWZ3GARl7oa+OZACwp5fcDab9aVBZDU5pSq0UULP4mm2fjirY4tSuTM3qvBp4zdhVbyUpyZBIJGqxfsLwOPXTQ4dq2sGHb6SaYmIBpDtYGv5np97tiD6Jh9T96YIy5d0Pr5dqjWNmMGQMW+QB22txZpp6oL2i4b5/8S5UzomeY4rLZQz2JIKncgkYZV6b6TtHdXWVSdkDlv3c8ZlRnSopke94yjWtt3mM82aUly84Vy/yB/sbDcreORXOzfAxmvOnXIVAiBHhgb2rtMSBRinWEv6GKBMJvJ6na/nUljO5Da0F+XVK28yPl9NbBluaS5+NMeB+f94Z0HC1M+d744r5NMyOZBIynVuN0IlUaxk1BBrFLcM9ZT6MRXpQpq3Z8mtjGt6A5P9Irh3ldd0Lii7AJPCpTkltf5lqTg4V9tcOXoKJ5Kd4VtV6YYerU9sUiK/ZadScrTzhxPh9SBBdsMJR4unSKd3cncnQC0zBg1ltLAICHhkYR9nkRaBZnazJuAZAxHchu8iheg9kTUPEQTMH72UXd0iKpdNsdSHm7scXOKj7TdVFHID6zCFM+EOrQ/wIjg/0hyKk5a/DxRD3eXwm3chSaX1lMELeCgPPmDnl1HWwOYyQtIQ15TLIlLFitNdY+O8DKdrcZkZNh2N7++6e9bSiuL6XLwUsPuRY6dXAXUa3g8XtxsO7JMoSbIXif3312X7ZhRdyfDYuzLWJBmUdjPTKgf4t935CX8NrCtemtK43B3E5+4J/e47EEI5jQaAjRa5S4qbZDTGl8S1SP0ppQchV1Kmad385WvKdvkpETMxnRgTKjl+bkvbzdJKVVjtrvhFvkpKbIKy+RRu3fcKPKZGLZkHD5kj8QIkF7bp402jT9PcuCd6dES5NzKWPvcDifYPHCy81cfwG/An4ENoFdAtpgIi4QC/Ml3PxVU3zHmu/oy97mRurkDQtn/cecMr7pwEyvO27wV5o/EDV6zJ/6KFCVAbz2mNX9HhoMiETKrEnnQ2gT5QHz/mZ5txrCN07RAVECNCdYTxEIn9ckrFC2PxdhfAKL5E65/Z9na+b1wstfj5kt4BI9fGzm4+ZPCHC8OVCPOIhAL4V8M5xjE6hEX9Ai89AbQhIuP52MhNZ4WTe14X0Fj510KDeZs3LKo0b2hLpDxS8pO8FsPEqBg515T+vpSkL+FmJn+YIhoXkmK21TLtjOfKS3AqiqFPCbIXyBfPQg6n2YJb0dOK1pEKpZU95YJptqnL4vFWCuG+yI3r5mlffe4bzTuqoy/2064ieaziTzJh72sgp8s9KE/yzH0TEEQNyo6Gs2hec+BL2vZk2itFibPUqqHzAx0wZ+4xLcayqjlb3V5Fel6LtSCht2HT7JV+he73YpxWeP+LBOzq2NUKQglFYbXB/zn+ieZQscb/m6Uu1PvDGkEYPFSiCP/CVueIamhM/SJpqf9odxgn6uGZ4i8vzd1hh8jEn9cJZdDCVFD0BpEo4pfXDs0V1acafSuCBKi6lupSjiFCUdtuG09vSiXEDhZahBw7f5azuRfQqkqMrdz+KYzprIcxb2Tc6T8FrZqv5QPAikS9THSrNKCdzQfvvqgMVagu2GHuzg1KVj1yicsRR8BSFlIpQEfAdRp5mWRPqFl1OErmsXIvubDGVt/Eoa7llVobmMg+ecPNAJ1+j7e0/OytL8s708M0if7LtALwWBRHGkJLvxSH18RRJXS2I4PGHBARTUV92gEbWR6T7SB+X90y99jHiF3t3+e0kKGBF2HHeGd5O4lXXw/kSr+l4Mk0H7XDS+BmQ2R0FWu6CcAqU9b2ks1LG7zzi/GNsEdtjMW5Wy1jNslUj7nfrBJGz4fgkEboy6rZPwyz9DL2Vm5EikrPNTdjk1rw6SBGAxyAMGQWD3D3XMp6X18+exrxKhbsdKiH6c971lYRr2xWBs0Tuld7NNGFlCB37i1eAWsudi8jR+6piUXpxQy7LqaGG6i8ZvgcDGsaOoF87xcOl/TYTmwTTRdG5zlWSdmLzHCEqjDq/mZZz55M3TzlA6ft/YSkCs9NaOmeeK7MT0JFh7jFuTbcZD1ijuSNkz8VKhloYek+Ad39fnl5LubZFJBX3UGngMoLmlYo4WzNTVgFNRPwxEs6IBXBoAqKEzvYEbaQUcGE0zmzwH5oAd4Jztl6WGodTg4iJAPK4L8PJ/B8CYW7E+eCqz4BznMAmreze3E7uB2Lu6Eatr3uXUg99fbBvsRS1XBb/f/r3ub28/EZCj1BTC7QoTbANJDKgtRa7ZXNv0F8dyslf1jvkQF5B4A7XAyV2tiBVhHfLBBZcfTqfPchlMkwwzmhHiWZScJunltx2go4Ly5jg2rkQVGDaeRVg85ZSzUf+z51tozVkdDoyMhqiAsNMxfSRrJCzgNln7acjoIYpl8x+0mFbo69r5EJ9JVttIH2sYa222AU9mi4vnv/pgXA03sIh4Rv0suzejRcf/Rndw5e8jJAkz/7xeg//ovQIUGVvRDuEPK5HxjJ9n84Xw9b3z3nPEL2bzB7QV6FE141qBi+n6Kj1hrcZM00Atuh1T/Z52KZtdGjLkQeLDVAwLzHdxgGmKH1S9hPMH4c9zTFctao7XD2p7TH7AZ4ktAj0q1+Gkhq/gclXSaEdTomsfjCc8pxCGqZWp+7zqkvZQsnz0Ei0svJgWYvWID8Fmx8kkiEn7N5VWbjnPnwP1/H14uek60dCN1NoDIMhuEUQnqxaT9+Ry1Z2SQ5eM+JxEVBUkginucVq8K8iLmHLW5Y8cFeNV0h5nuCuagSecubW4K5fd+iUTnLIdMStrJDnNyZyKbiPtKQeAIcotfvIlAHr0UtXR7CDUYYUF2SasXX8L0PUlSFYuDDsdXhGJ0izsZ1kFi3Lhbmt9aSt59HLglzSnFmmG5ledzewhnd9r1jeUob+NRrfw/qHXhif45jHCijAtz3wWmKvZYpTU1RDNuF51k1sVG+Kui3sr3w/8yhXEEkjCVB+E112oNj3RhTPj5HEQyhZ6CZLQ0egMP1K+BbRCFF0Fgy8DG2UOCbar6EsVVcKuXFBcL0yJQT7QmpgZjTVgFqIT14g2LaJpV5+m0zrQtXBTqUw5b0jLLD/oS2ZbtHUNI7uksc3/JXT42qCKrfKg51fFgVcf5ybqt3cewyPblhJ9BQWKnDTY62Y4H9KDxvpQECsfFKd9ikW0DvtLlx48ySxkoEgM3vtKb+d649tKaegtSbgpk6KFasBZ6EVRFtjQysq8nq3nI8EJGaq8mLABVaOKlTg4VywaUXZVfoM2heBB4TIbCN4nEEH+Tvn7UHRcm+DzfVRicTpv9q2bzhZFM4vpduESbO7wQOblqX4N0h+8rXgUsoK6o8agWZI2ibMW7Pjva/XsrkBbliOMGlw/bs/gRDbNDZg14nOUNUNv7J1u2kg806IUeDcyYBBV2fa7wUyAhrv3L7q84kmHEWq+VJOORIqBgNTDA3ftjdact8aHGjYWbroFTeqi9tQTg1ARL9L0p0IIZJpU2+k8wNCGMUYyAHfZM+323gV/M5Q7RPyW+P3W93qgnzNLVpdqDMNaPCjgP5iR4kU9PmKZpDhJKngsaCbGo7BMX++LR9d1pAcp3pBR+SVTo6oqCeBb87OXEefPVacrdw6zYftPIqGn6h6mWysuORfDjwx9RjeofQMWGqQRJnZNp/EsidqX472j2yd76wehAuRbYsQ5MaZnL8LOKo08ULxCpLlRo4b550+WXt0E0vpceIOY8a5VvI+ty3TyUvqkXciLuOkFe8hqlSVxKEZ9lTrRSnZar9MHjvySQREje9LxS0nZkLeUK8Q81XJSn7+D180Nk/YN+q2OToY0Mrlo2g2v+iCrVhhdrzvH0O5RS3b+ZRSkxPpfj95TTyaGuzy9aWeU4OcweGYFbejgfhuF5Vo7vgEyRune/+bDFFec02wDQ67Xllj+heSXqXnfdr8RrYtjBi7Kw75VFkYQ3N3RRMaE8REFF/QwFBTVy7lMRcaKGxDAMc2XuU7ZCgXd5YWOWV/JshqGKCLjeZ2e1PA9YZLZx5AE/aTAebd/BGUErjq7pfVB4hVVTgT3+v645lSjZ2pcevogAQJCvPDCcQBR74EFAPEBMFMYselGglOjtxUjnZ42uHPLMtWnLcHgQhbRpqfaFZ+MmJSJG6lhWfKwqu3vs/Totd9eVFU4n3PfA1o+QxcrZ6NsCXMgeFVxP9vYb5kmyB8BZ+BzjTwIfVGjXolx9nBOy2FmLzrN9EcHmutVb99RytNY9H5YoakS43m2l6ofvaiCIDKgPKjqpk6yuFvyBfi8SPmlUujTj1I+gQUPYWrVJxVepl8tzFVxhzluJFntAAH1uyjlTFEhxGL4oiRU9haCROZImwR3MV+WdPUTrXkdcLvIBwqDdiW37EDfILiidJENI8AewMUv9+aPxqRfWbNBQk426uOTP9x0tM8W0Vwn4vZke3V45GjG59nXzxOhp2TjfbW3wCCbLW9TYp7OIaqV7tBxXS6C69k6QO1p74Q1kxP3B4vhyZvbwzbaPoS8FGP4XR2Bvb01zLpbG+FyMbE2OMcB3nYuO9BI8Wj7+VlfeG4DXxzirkklvNC4YHWi/t2Klqn7ljtPtAK/HPf2Vs7Q+BZ+i31ybwaqUpfXk4CCbiMd1mhyPO7QulpRFOTACXv+YE65124tSYQhqBSzgzHQBliAS19KKqRGDk6bxpsM9LKratdVI+Rphfo8MDBEajSbC3tJKJflB1M7Ra8PpGw6fmV7SsF5jR24ztM7Xq/vCbUGyN3ZsnyDNCNRdgQ9NpHBKyd1n7dN5jmwFDdecPq3PFnfl6EJOXw5ogcCMoUbs1TPvekE7veW0EOd8KI/DtfzX6CxCE5UsR/2BG8YYobDniqIo51TbR53GKVbyMRH3ns2jwTYIhc/NFs96si++iQLfU3yWSGn6I6ZxezPCeyMX8J/gKUJB9EAFDMsUj2u7b57hV8y0UnHvQS179My8Fb6AvbtlIUNkJizAi+2iwDx3pKBJpiNwKefbscNpMYZTEnDnNWEfhVg4y0s829QlyfgmcaTGLOL/9CtsH7PG1h/8D+2n6Rjwu4sGKcj++imKENmE5VyKyFzhq4AJ7tLA7s/jdMJ9PcyFQeEcUfLCNzna1c02cnyvi4fgxqFCZpGT1XWu6UdBqojA4ukEdJChzSH9/uyVLH9ExqU945AWTdTHIzEx5ysfVColiwoeNl/EYQt2CFokaD0meYWweKiNdv37Aew9gLQmEsF469LjFovWocszfpT4E8VnwAnbV6Rxo/GV0lnu/eDmH/QmsFvyg9dxtVHRcZNvCBx5UW7I9FDAVDAvKIVW3dhtnbrNm5/bvVKkFV5qD3bknvIy7nIpxNfpuzG3W00gYuAgtfohwmWYHR0rqNXf5pX9H55NArGkQT6zEkJA2nHQ2r4Ns0+nYRoSNn9LhlJnSir3OOTG5UrHDQS1gzZny3499j6fOILsQ8uMHr24vK8d7kf5HrzrKJMfnKzxHr2D9KstUfgHvtLkMEJLpLhCxSfg08OjFIGfWI/yoYUbN3pilkNcbRIsEzwM1511ftk0mhqkORVyusvq/TwrEqGL9O9mh64nQz0I1L4pi2QuWc9g0OBhLz+q5UbkRqge57oGMRk6OGvqUGP+1sod33ZPudJ7RrY+vb6U8hELW3dV/2f7GuCd9lKFovX5QIfN9TbzLSzpCduK1V0AzOla0lJTXx2SpthShn8YQ/q4j9H56RB9KP1iH0OEpb3C0+XCyr8BEkl/8rgpBbcvZ+FZbu2KMYIwqRT/MGMcGKHwl1ueLbDXSu8ofqzoftqIOi/4cgj6Xhe6RZ4pQCvhePGPhtkINMdB9G5nIF+JSByktU3g5HLYPHuN498pyKKL2X9SXvCrDTWlcw1RssSkt3YnjIVUAhAcwmpp9Yj8VsxBc3oQkjOHFV" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZBbRI-vLFGPASeYxh_KgLGJAGhxxxQHaAFUowMEJ38zbzJMIHhOPM0QVtz7ClVSrJw2&amp;t=639202794265548063" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1HoTsDJCIwegf7-cSVNQxKlxqJplUAag2gjZMR_ctGyeKzMDbl61mq8CG1bXK2cKIO5F_d_eACHU7rvEovdRsHjPwMxL_2RbhdHxnXThSzdTd55hY37B50zmwPwIsJ1FnQ2&amp;t=4623e90" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvqBoWBYTDUGuawA_2GYbNQlKfMSt2G6fTRv2v_CvkMQC-NDKOxcBHZBsr4m43UZoWnDElLWlfRSMae7wFN5-j848Bfbquym3Qmm_a4KPTP8MlNJWDtdRKeoXno9ND71Mj-dmT4RATMPqWph8tRm5et41&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OAh7tEdde-lvG3-30egxXz8aAgw_K6hDRuGQnL44pJNvGX0k88IpkhwtBpf_hp5FI_xl-S6IOzDAoSwTftgBkdwIVbozv2itakdYRoj6lyvW2iAmc3lxcxcAsYCLcWBMdMG64QNAlb5JWK1NKm4PkKk1&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=eE6V8nDbUVn0gtG6hKNX_FhBCrEodp5vWm_YmsPN6L6kd8QLjOqCyZgy7R07cf_-q6jt6CUudI9DljzC2TdIySTnrKddg3RKYGaYn4SUdM3lZcSR2HeYBRZYoT1mfgRe0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=mcAASOSteirJeuV-3by3Udl0BXtV-9r3zqXldfMmh4nMyRrfOyOUzm9PjtxhXMnCb3u1w9Bl8xQwuZ3vJQhQk5K_jbJ7TUVZSafdbK767TU1&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=jwf4VSQi7LeShc44FJ-gAeDpDtsq5KMQ8v0UGSwL0n57o9DwezYikDFx_PyigWyXj_0OxQaznPKYQt6DlIveEltbNvWSF7tPucSRMMT0SDIeemWSUwY9H6muRTmCFq5y0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=nai7mGcYyE2dix_TwveLDUh5s-4A2YxYW54tIrkM_TUunAGPTDDQIgTi7_jF0ZDsXQf2DAdig0qNTG97Zho5rt0FlKu4f2urbVFVmxpi95du0q96Rm7avCmT7YWIJACc0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=yDT7ulzE00Yqzs5zd38bJ9uYK0mE0NQaZIaf-pwWkJgWYgpXpMmyr9X13OsEF0tAmtivqF1lykUd9zGXXG_12HtYlW9Y5ThEGbuS1bPsUkjRauDlH9wZ-Gg0tVnmDj270&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=HEFpVKbnoeQjkjHkFKu3MFt9ri5W5MnThyWIA17NLksVbAMJb3b4J6FUWFjTqfhe62vQzBBryc0D7vtVE9sCvRaBkQXkkFQdNC1ak54UhzYYY35kSK400VtcrgLyqWDD0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=5ib3lCcyinHeLQmkwMF7EsGoPbLcoTPc-cgtukLJYPUZaLkkgAnENQdSi8NDc4l_BKxYZA1H9k0706BHQRpedGJsNRjKTrwz8gPmzzA-oap0ysiJ6VwrD01uCYx37kM30&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=iON9Jxe8QCRam1nkdNLgkffrRZCMCj6iq7qHWPZc_e3jKeMk_XnmxshFxNhoGH9SwE5Oz8w4xs83YnQN2PvBuUDeB4qmPOBf6C6AjLMoHrEWhVT0hkNgKR3X5v1OCzxI0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=xGmPTKfsNy0_1Sr5I58kO5DASLN2udyuv-7sLUq5_rfvt0h0nqG8q3lnLwCBbElWqxPrkky3q5vq3pg0VXsmEcTWWXMOeG7FgMUlD16VLKssIvRudHPE5Dua6R6EOhY40&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=LQ1q2RBSthBAZhliMjtG_6LMhlQH2DbcQYgRKlCVjFIh5IZ7GFZUyt66Y_m4cqI1Qb8Rf2oM6HCIJJLQ9rSBDT1GrsRxo5ZypZQOZ1maIbKPmaC4yLryG1OCPsyASQdm0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=VOYD8Xe7kQA0lniBYXVpAuKo3oFKAyHWpDt0JH4amXNlZ9J7vLHsxoqoc15eTAjA6oglPYd0zwAK4QpQdtZv0jvkOUq5Z5is2nQki9YITO0skfivF47CJZD_3wdgAEY50&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=hOeJu0xhC-uW6Gf8ooKdXldiqMjTwkMrPiRL7tfxCMAYgx7LQGO2FKVjBYyeRQsczHJO8YrvOhmAf48uwtZEnO4Mu9oj9tlaZBV6uinaXInS4irYgdmuHH1_fMK8aVI10&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=XlV9GqTk6b5uqDuL38kZ4M4-D19lMtmt0Nfm-OaIfmfKZXxxdkEy0_fz8Rb50xJiOME7ruSlDELDwr_q88n93Z8DbpgP-PrvolSTi43wrxjzmVSKMK-250V1wOfusJzQ0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/WebResource.axd?d=JoBkLzP19aTuxbWOhHobYndLm8rB8C7w5JAGcozHelAi0yxlDEHXqwBJPZODPDVe3kynVZnW81KTBhLcr2IKvw2&amp;t=639202794265548063" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="EA7F75BC" />
	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0" />
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="I90JHQvY7rNdJ+pBpMX7SuBOVzMUt0uCcKe4N/JKWxV3ktzKhhsPwHvr/womuCyizI8L0p+W77sL5VXTVtP3DJWlTdA/I6aJjDpIZINeS7BH0mgGKa00Z348JB1ItEKsHlFWx3BBLiBrOBQMor+oIzCaTKQWO55+bTHdqLIt24YHHVuXRxsRrFDcM0Cr5U7OVqlwqziKZZ/3gI81zXb9w1SJ46pMV00LyfkGIrJLup6YoDiakfrP895ClqEx5/GVN6H1XvPZw9Y6rjPhi40aCkrJb1I4x2uZ9Qc+zsjhZts5By+Q107wCHmS8mJVhfJSA9sHHWhe39mwkjsbQyE6/1Xx8w7xm96kCkmYfEPEmw6K4kN1/v9hwYXyzGZ8tdgx/H7EWfO0/mFovPmWNCsohDsEv9myFb+4WrkeUG40yQxZ4NWuRkuBV5NSKTEWfcW4EDeg40JxbIT8AsNxZpDMgpX1KGUSK9LyK4BUE1wSAmaUgiNKx0LdmFm5aVJr/whWWwTjOWYEs7JPemugEuXBFYMYmTB1y4xtCkDY+kgd2HwNjlUixtFTn3YQe8DHIwpnTxoLoWkGSszpjdaxYUQsLLihzM3xgqh3G0HRGPqe3RCPtG5pFc3yHqq19nwJGj2ixk9Hr18usxtX6XHNe6DZk2fDj7x2qNGxQniSo/jiZNxixIdgdr7RM2hXCAgfGw7+uOHt6s+1Io2/TkKQZYFDBNay7Tq7HacwqM0AdfrUObNSQb9tqjdk1t5/5HZzN8Z6eBcl38krn0RrjsMV7dQBskIWqfLJl14eqTZAic4g+KjmSkyekO9yEpm5U7XsKQWwOKp4oAz6/GwLL/xBU3g1Chob7yIqO2TJcOVJ3NxNuhqhmVq4mNv2cyzOg0mzEuMvh0f7VoKiEg3sU+z0VMA7jw==" />
</div>
           
        <div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', ['tctl00$SelectRegion$updChangeRegion','SelectRegion_updChangeRegion','tctl00$UpdRegion','UpdRegion','tctl00$ContentPlaceHolder1$UpdatePanel111','ContentPlaceHolder1_UpdatePanel111','tctl00$ContentPlaceHolder1$updtApplicant','ContentPlaceHolder1_updtApplicant','tctl00$ContentPlaceHolder1$updtForm','ContentPlaceHolder1_updtForm'], ['ctl00$ContentPlaceHolder1$btnGetOtp','ContentPlaceHolder1_btnGetOtp','ctl00$ContentPlaceHolder1$btnOTPVerify','ContentPlaceHolder1_btnOTPVerify'], [], 600, 'ctl00');
//]]>
</script>

            <button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-topD">
                <i class="fas fa-arrow-up"></i>
</button>
<!-- Simple splash screen-->
<div class="splash">
 <div class="color-line"></div>
 <div class="splash-title">
 <h1>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h1>
 <p>ਕਿਰਪਾ ਕਰਕੇ ਉਡੀਕ ਕਰੋ ਜਦੋਂ ਤੱਕ ਅਸੀਂ ਤੁਹਾਡੇ ਲਈ ਖੋਜ ਮੋਡੀਊਲ ਨੂੰ ਸੈਟਅਪ ਕਰਦੇ ਹਾਂ./Please wait while we setup the search module for you. </p>
 <img src="ui-assets/images/loading-bars.svg" width="64" height="64" alt="Loading.."/>
  </div>
   </div>
		<div id="updWebsite" style="display:none;">
	
				<div class="loadingContainer">
					<div class="loading">
						<img src="ui-assets/images/loading-bars.svg" alt="Loading.." width="64" height="64" />
						&nbsp;
					&nbsp;
					</div>
				</div>
			
</div>
<!-- Header -->
	
        
        <div id="header">
            <div id="plrs-header">
                 
    <div class="plrs-header-row">
     
        <!-- LOGO -->
        <div class="plrs-left">
        <div class="plrs-logo">
            <img src="ui-assets/images/logo.png" alt="Punjab Land Records" />
            <div class="plrs-logo-text">
                ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼
                <span>Punjab Land Records</span>
            </div>
        </div>
        <div class="plrs-menu header-link hide-menu"><i class="fa fa-bars"></i></div>
            </div>
        <!-- REGION -->
        <div class="plrs-region">
               
             

<div id="dvChangeRegion" class="modal fade">

	<div class="modal-dialog modal-lg" style="min-width:80%">
		<div class="modal-content">

			<div id="SelectRegion_updChangeRegion">
	

					<div class="modal-body">
						<div class="row">
                            <div class="col-md-12 m-t-sm">
                                <fieldset id="SelectRegion_fsSelectRegion" class="form_ font-resize-scope">
										<legend id="SelectRegion_lgSelectRegion" class="lg p-sm head-legend">
											<i class="fa fa-map-marker"></i>
											<span id="SelectRegion_lbllgRegionInfo">ਖੇਤਰ ਚੁਣੋ/Select the Region</span>
										</legend>
							   <div class="dvSelectRegion m-t-sm m-b-sm">
                                   <div class="row form-group">
                                                    <div class="col-md-12" >
                                                		<span id="SelectRegion_Label2" class="label label-lg-font-size">ਜਮਬੰਦੀ ਪੀਰੀਅਡ/Jamabandi Period</span>
														<table id="SelectRegion_rdPeriod" class="form-control smedium m-t-sm">
		<tr>
			<td><span class="radiobtn"><input id="SelectRegion_rdPeriod_0" type="radio" name="ctl00$SelectRegion$rdPeriod" value="1" checked="checked" tabindex="1" /><label for="SelectRegion_rdPeriod_0">ਮੌਜੂਦਾ/Current</label></span></td><td><span class="radiobtn"><input id="SelectRegion_rdPeriod_1" type="radio" name="ctl00$SelectRegion$rdPeriod" value="2" onclick="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$rdPeriod$1\&#39;,\&#39;\&#39;)&#39;, 0)" tabindex="1" /><label for="SelectRegion_rdPeriod_1">ਪਿਛਲਾ/Previous</label></span></td>
		</tr>
	</table>
                                                        </div>
                                                </div>
                                <div class="row form-group">
								    <div class="col-sm-3 district-dropdown" style="position:relative; z-index:9">
									    <span id="SelectRegion_lblddlDistrict" class="label  label-lg-font-size">ਜ਼ਿਲ੍ਹਾ/District</span>
									    <select name="ctl00$SelectRegion$ddlDistrict" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlDistrict\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlDistrict" tabindex="2" class="form-control">
		<option selected="selected" value="">ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Choose District</option>
		<option value="7">ਅੰਮ੍ਰਿਤਸਰ/Amritsar</option>
		<option value="8">ਬਰਨਾਲਾ/Barnala</option>
		<option value="9">ਬਠਿੰਡਾ/Bathinda</option>
		<option value="10">ਫਰੀਦਕੋਟ/Faridkot</option>
		<option value="11">ਫਤਿਹਗੜ੍ਹ ਸਾਹਿਬ/Fatehgarh Sahib</option>
		<option value="12">ਫ਼ਾਜ਼ਿਲਕਾ/Fazilka</option>
		<option value="13">ਫਿਰੋਜਪੁਰ/Ferozepur</option>
		<option value="14">ਗੁਰਦਾਸਪੁਰ/Gurdaspur</option>
		<option value="15">ਹੁਸ਼ਿਆਰਪੁਰ/Hoshiarpur</option>
		<option value="16">ਜਲੰਧਰ/Jalandhar</option>
		<option value="17">ਕਪੂਰਥਲਾ/Kapurthala</option>
		<option value="18">ਲੁਧਿਆਣਾ/Ludhiana</option>
		<option value="18953">ਮਲੇਰਕੋਟਲਾ/Malerkotla</option>
		<option value="19">ਮਾਨਸਾ/Mansa</option>
		<option value="20">ਮੋਗਾ/Moga</option>
		<option value="21">ਪਠਾਨਕੋਟ/Pathankot</option>
		<option value="22">ਪਟਿਆਲਾ/Patiala</option>
		<option value="23">ਰੂਪਨਗਰ/Rupnagar</option>
		<option value="24">ਐਸ. ਏ. ਐਸ ਨਗਰ/S.A.S. Nagar</option>
		<option value="25">ਸੰਗਰੂਰ/Sangrur</option>
		<option value="26">ਸ਼ਹੀਦ ਭਗਤ ਸਿੰਘ ਨਗਰ (ਨਵਾਂਸ਼ਹਿਰ)/Shahid Bhagat Singh Nagar(Nawanshahr)</option>
		<option value="27">ਸ਼੍ਰੀ ਮੁਕੱਤਸਰ ਸਾਹਿਬ/Sri Muktsar Sahib</option>
		<option value="28">ਤਰਨ ਤਾਰਨ/Tarn Taran</option>

	</select>
                                        <span id="SelectRegion_RFVDistrict" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District</span>
								    </div>
                                    <div class="col-sm-3 m-b-md tehsil-dropdown" style="position:relative; z-index:8">
									    <span id="SelectRegion_lblddlTehsil" class="label label-lg-font-size">ਤਹਿਸੀਲ/Tehsil</span>
									    <select name="ctl00$SelectRegion$ddlTehsil" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlTehsil\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlTehsil" disabled="disabled" tabindex="3" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਤਹਿਸੀਲ ਚੁਣੋ/Choose Tehsil</option>

	</select>
                                        <span id="SelectRegion_RFVTehsil" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil</span>
								    </div>
                                    <div class="col-sm-3 village-dropdown" style="position:relative; z-index:7">
									    <span id="SelectRegion_lblddlVillage" class="label label-lg-font-size">ਪਿੰਡ/Village</span>
									    <select name="ctl00$SelectRegion$ddlVillage" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlVillage\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlVillage" disabled="disabled" tabindex="4" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਪਿੰਡ ਚੁਣੋ/Choose Village</option>

	</select>
                                        <span id="SelectRegion_RFVVillage" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village</span>
								    </div>
                                    <div class="col-sm-3 m-b-md year-dropdown" style="position:relative; z-index:6">
									    <span id="SelectRegion_lblddlYear" class="label label-lg-font-size">ਸਾਲ/Year</span>
									    <select name="ctl00$SelectRegion$ddlYear" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlYear\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlYear" disabled="disabled" tabindex="5" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਸਾਲ ਚੁਣੋ/Choose Year</option>

	</select>
                                        <span id="SelectRegion_RFVYear" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year</span>
								    </div>
                                </div>
							</div>
                                    </fieldset>
                            </div>

						</div>
					</div>
					<div class="modal-footer">
						<!-- Submit Button-->
						<input type="submit" name="ctl00$SelectRegion$btnSearch" value="ਖੇਤਰ ਬਦਲੋ/Change Region" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$SelectRegion$btnSearch&quot;, &quot;&quot;, true, &quot;ChangeRegion&quot;, &quot;&quot;, false, false))" id="SelectRegion_btnSearch" tabindex="6" class="btn btn-pimary submit-custom-btn" />
						<button id="SelectRegion_btnCancel" class="btn btn-danger btn-no" data-dismiss="modal" TabIndex="7">ਰੱਦ ਕਰੋ/Cancel</button>
					</div>
				
</div>
			
			

		</div>
	</div>
</div>

            <div id="UpdRegion">
	
                    







                
</div>
        </div>

        <!-- ACTIONS -->
        <div class="plrs-actions">
            <div class="plrs-font">
                 <input type="button" id="btnincreasefonts"  value=" A+ " />
                 <input type="button" id="btndecreasefonts"  value=" A- " />
                 <input type="button" id="btnresetfonts" value=" A= " />
            </div>

            <a href="Login.aspx" class="plrs-login">
                <i class="fa fa-lock"></i>
                Official Login
            </a>
        </div>

    </div>
            
</div>

</div>


        <div id="divBackground" class="modal"></div>
		
        
<link href="../ui-assets/Pgstyles/uc_navugatonmenu.css" rel="stylesheet" />
<!-- Navigation -->
<aside id="menu">
	<div id="navigation">
		<nav class="nav-primary">
			<ul class="nav">
				
				
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl00_liItem">
							<a href="Default.aspx?itemPID=1">
								    
                                    <i class='fa-solid fa-house'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl00_bBG" class="bg-info"></b>
								</i>
								
								<span>ਮੁੱਖ ਪੰਨਾ/Home</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl01_liItem">
							<a href="OnlineRequestStatus.aspx?itemPID=77">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl01_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਟਰੈਕ ਐਪਲੀਕੇਸ਼ਨ/Track Application</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_liItem">
							<a href="./?itemPID=82">
								    
                                    <i class='fa-solid fa-file-export'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl02_bBG" class="bg-primary2"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl02_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਸ਼ਿਕਾਇਤ ਨਿਵਾਰਨ/Grievance Redressal</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl02_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Grievance.aspx?RefNo=1&itemID=83&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦਾਖਲ ਕਰੋ/Submit Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_liItem">
											<a href="GrievanceTrack.aspx?RefNo=2&itemID=84&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦੀ ਜਾਂਚ ਕਰੋ/Track Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_liItem">
							<a href="Jamabandi.aspx?itemPID=3">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl03_bBG" class="bg-success"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl03_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਜਮ੍ਹਾਂਬੰਦੀ ਵੇਖੋ/View Jamabandi</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl03_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Jamabandi.aspx?section=Owner-Name-Wise&itemID=7&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਮਾਲਕ ਦੇ ਨਾਮ ਮੁਤਾਬਕ/Owner Name Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Jamabandi.aspx?section=Khewat-Number-Wise&itemID=8&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖੇਵਟ ਨੰ: ਮੁਤਾਬਕ/Khewat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_liItem">
											<a href="Jamabandi.aspx?section=Khasra-Number-Wise&itemID=9&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਸਰਾ ਨੰ: ਮੁਤਾਬਕ/Khasra No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_liItem">
											<a href="Jamabandi.aspx?section=Khatouni-Number-Wise&itemID=10&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਤੌਨੀ ਨੰ: ਮੁਤਾਬਕ/Khatouni No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_liItem">
							<a href="Mutation.aspx?itemPID=4">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl04_bBG" class="bg-danger"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl04_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਇੰਤਕਾਲ ਵੇਖੋ/View Mutation</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl04_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Mutation.aspx?section=Mutation-Number-Wise&itemID=13&itemPID=4">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਇੰਤਕਾਲ ਨੰ: ਮੁਤਾਬਕ/Mutation No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_liItem">
							<a href="Roznamcha.aspx?itemPID=5">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl05_bBG" class="bg-info"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl05_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਰੋਜਨਾਮਚਾ ਵੇਖੋ/View Roznamcha</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl05_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Roznamcha.aspx?section=Rapat-Number-Wise&itemID=11&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਰਿਪੋਰਟ ਨੰਬਰ ਮੁਤਾਬਕ/Rapat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Roznamcha.aspx?section=Waqiati-Number-Wise&itemID=12&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਵਾਕਿਆਤੀ ਮੁਤਾਬਕ/Waqiati No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl06_liItem">
							<a href="RegistryDeed.aspx?itemPID=21">
								    
                                    <i class='fa-regular fa-copy'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl06_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਰਜਿਸਟਰਡ ਡੀਡ ਵੇਖੋ/View Registered Deed</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl07_liItem">
							<a href="FardStatus.aspx?itemPID=29">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl07_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਫਰਦ ਬੇਨਤੀ ਸਥਿਤੀ/Fard Request Status</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl08_liItem">
							<a href="GroundTruthingDataMap2.aspx?itemPID=85">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl08_bBG" class="bg-success"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-2 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-2 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl09_liItem">
							<a href="GroundTruthingDataMap3.aspx?itemPID=86">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl09_bBG" class="bg-danger"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-3 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-3 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl10_liItem">
							<a href="IPWTD.aspx?itemPID=15">
								    
                                    <i class='fa fa-university'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl10_bBG" class="bg-info"></b>
								</i>
								
								<span>ਇਨਟੈਗਰੇਟਿਡ ਜਾਇਦਾਦ/Integrated Property</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl11_liItem">
							<a href="faq.aspx?itemPID=33">
								    
                                    <i class='fa fa-question-circle'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl11_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਐੱਫ ਏ ਕਿਊ/FAQ</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl12_liItem">
							<a href="UserManual.aspx?itemPID=35">
								    
                                    <i class='fa fa-user'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl12_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਉਪਯੋਗ ਪੁਸਤਕ/User Manual</span>
                                 
							</a>
							
							
							
                            
						</li>
					
                				
			</ul>
		</nav>
	</div>
</aside>


	    
		<div id="wrapper" >
            <div class="page-body">
                <div class="normalheader transition animated fadeIn small-header hide-mob hidden-xs hidden-sm">
				<div class="hpanel">
					<div class="panel-body">
						<div class="row">
							<div class="col-sm-12">
                                <div class="nav-pills bg-light breadcrumbs">
                                    <span id="SiteMapPath1"><a href="#SiteMapPath1_SkipLink" style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;">Skip Navigation Links</a><span><a href="/Default.aspx">ਔਨਲਾਈਨ ਸੇਵਾਵਾਂ/Online Services</a></span><span> &gt; </span><span>ਰਪਟ ਲਈ ਬੇਨਤੀ/Request For Rapat</span><a id="SiteMapPath1_SkipLink"></a></span>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>

		<div class="content animate-panel">
            
    <div id="ContentPlaceHolder1_UpdatePanel111">
	

            <input type="submit" name="ctl00$ContentPlaceHolder1$btnShowPopup" value="" id="ContentPlaceHolder1_btnShowPopup" style="display: none" />
            <div class="content transition animated fadeIn">
                <div class="panel hpanel dblue">
                    <div class="panel-heading">
                        <div class="form-horizontal text-center ">
                            <h3 class="font-resize-heading"><b>ਰਪਟ ਲਈ ਬੇਨਤੀ/Request for Rapat</b></h3>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="form-horizontal">
                            <fieldset id="ContentPlaceHolder1_FieldsetApplicantDetail" class="form_ font-resize-scope" style="background-color: white">
                                <legend id="ContentPlaceHolder1_legendApplication" class="lg p-sm text-left head-legend">
                                    <i class="fa fa-info-circle hidden"></i>
                                    <span id="ContentPlaceHolder1_lblApplicantDetailH2">1. ਬਿਨੈਕਾਰ ਦਾ ਵੇਰਵਾ/Details of Applicant</span>
                                </legend>
                                <div id="ContentPlaceHolder1_updtApplicant">
		
                                        <div id="ContentPlaceHolder1_pnlApplicantInfo">
			
                                            <div class="row form-group">
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਨਾਮ/Name of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Name</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtName" type="text" maxlength="200" id="ContentPlaceHolder1_txtName" tabindex="1" class="form-control label-lg-font-size" placeholder="Please enter name of Applicant" />

                                                </div>
                                                <div class="col-sm-6 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblFatherNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦੇ ਪਿਤਾ ਦਾ ਨਾਮ/Name of Father of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVFatherName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Father Name</span>

                                                    

                                                    <input name="ctl00$ContentPlaceHolder1$txtFatherName" type="text" maxlength="200" id="ContentPlaceHolder1_txtFatherName" tabindex="2" class="form-control label-lg-font-size" placeholder="Please enter father name of Applicant" />

                                                </div>


                                                <div class="col-sm-4 m-t-sm">
                                                    <span id="ContentPlaceHolder1_lblMobileNumberH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਮੋਬਾਈਲ ਨੰ./Mobile No. of Applicant<span class="text-danger">*</span>
											        </span>
                                                    <span id="ContentPlaceHolder1_RFVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Mobile number</span>
                                                    <span id="ContentPlaceHolder1_REVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter a valid 10-digit mobile number.</span>
                                                    <input name="ctl00$ContentPlaceHolder1$txtMobileNumber" type="text" maxlength="10" id="ContentPlaceHolder1_txtMobileNumber" tabindex="3" class="form-control label-lg-font-size" placeholder="Please enter mobile no. of Applicant" />


                                                </div>

                                                <div id="ContentPlaceHolder1_pnlOTP">
				
                                                    <div class="col-sm-2 m-t-sm" style="margin-top: 30px">

                                                        
                                                        <a id="ContentPlaceHolder1_btnGetOtp" tabindex="4" class="btn btn-primary" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ContentPlaceHolder1$btnGetOtp&quot;, &quot;&quot;, true, &quot;GrpRequestotp&quot;, &quot;&quot;, false, true))">
                                                         <i class="fas fa-mobile"></i> ਓਟੀਪੀ ਭੇਜੋ/Send OTP
                                                        </a>

                                                    </div>
                                                    <div class="col-sm-2 m-t-sm">
                                                        
                                                    </div>
                                                    <div class="col-sm-2 m-t-sm">
                                                        <span id="ContentPlaceHolder1_lblVerifyOTP" class="label-lg-font-size">ਓਟੀਪੀ/OTP<span class="text-danger">*</span>
											        </span>

                                                        <span id="ContentPlaceHolder1_RequiredFieldValidator2" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the OTP number</span>
                                                        <input name="ctl00$ContentPlaceHolder1$txtOTP" type="text" maxlength="10" id="ContentPlaceHolder1_txtOTP" tabindex="5" class="form-control label-lg-font-size" />
                                                    </div>
                                                    <div class="col-sm-2 m-t-sm" style="margin-top: 30px">
                                                        
                                                        

                                                        <a id="ContentPlaceHolder1_btnOTPVerify" tabindex="6" class="aspNetDisabled btn btn-primary">
                                                         <i class="fas fa-check-circle"></i>ਓਟੀਪੀ ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ/Verify OTP

                                                        </a>

                                                    </div>
                                                
			</div>
                                            </div>
                                        
		</div>

                                    
	</div>

                            </fieldset>

                            <div id="ContentPlaceHolder1_updtForm">
		
                                    
                                    
                                
	</div>

                            
                            
                            
                            
                            
                            
                            
                            

                            <div id="ContentPlaceHolder1_pnlmsgConfirm" class="sweet-modal" style="display: none;">
		
                                <div class="sweet-modal-header">
                                    Alert
                                </div>
                                <div class="sweet-modal-body">
                                    
                                </div>
                                <div class="sweet-modal-footer">
                                    <input type="submit" name="ctl00$ContentPlaceHolder1$btnOK" value="OK" id="ContentPlaceHolder1_btnOK" class="btn" />
                                </div>
                            
	</div>
                            

                            
                        </div>
                    </div>
                </div>
            </div>
        
</div>


            
			
			
			
			
			
			
		</div>

    </div>
    <!-- Footer-->
    <footer class="footer footer-font">

    <!-- Govt -->
    <div class="digi-topBoderThickDis">
        <div class="container-fluid text-center">
            <span>ਮਾਲ, ਮੁੜ ਵਸੇਬਾ ਅਤੇ ਆਪਦਾ ਪ੍ਰਬੰਧਨ ਵਿਭਾਗ,ਪੰਜਾਬ ਸਰਕਾਰ, ਭਾਰਤ / Department of Revenue, Rehabilitation and Disaster Management, Government of Punjab, India.
            </span>
        </div>
    </div>

    <!-- Copyright -->
    <div class="digi-topBoder">
        <div class="container-fluid text-center">
            <span>ਕਾਪੀਰਾਈਟ © 2025 ਪੰਜਾਬ। ਸਾਰੇ ਹੱਕ ਰਾਖਵੇਂ ਹਨ। / Copyright © 2025  Punjab. All rights reserved.
            </span>
        </div>
    </div>

    <!-- Stats -->
    <div class="digi-topBottomBoder footer-stats">
        <div class="container-fluid">
            <div class="footer-stats-row">
                <span class="badge-pill">
                    ਕੁੱਲ ਵਿਜ਼ਿਟਰ/Total Visitors :
                    <span id="lblv">2380020</span>
                </span>

                <span class="badge-pill">
                    ਆਖਰੀ ਵਾਰ ਅੱਪਡੇਟ ਕੀਤਾ/Last Updated :
                    <span id="lblud">12/10/2026</span>
                </span>
            </div>
        </div>
    </div>

</footer>

</div>	          
    <script src="ui-assets/vendor/bootstrap/dist/js/bootstrap.min.js" nonce="MMmg0qMgTQVFV48LiweQeA"></script>
	<script src="ui-assets/vendor/datatables_with_buttons/datatables.min.js" nonce="MMmg0qMgTQVFV48LiweQeA"></script>
	<script src="ui-assets/vendor/virtual-keyboard/js/keyboard.js" type="text/javascript" nonce="MMmg0qMgTQVFV48LiweQeA"></script>
 <!-- App scripts -->
    <script src="ui-assets/scripts/homer.js" nonce="MMmg0qMgTQVFV48LiweQeA"></script>
    <script src="ui-assets/Pgscript/masterpg.js" nonce="MMmg0qMgTQVFV48LiweQeA"></script>
    <script src="ui-assets/scripts/select2.min.js" nonce="MMmg0qMgTQVFV48LiweQeA" > </script>
    <script src="ui-assets/scripts/BackToTopN.js" nonce="MMmg0qMgTQVFV48LiweQeA" > </script>              
</div>

<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("SelectRegion_RFVDistrict"), document.getElementById("SelectRegion_RFVTehsil"), document.getElementById("SelectRegion_RFVVillage"), document.getElementById("SelectRegion_RFVYear"), document.getElementById("ContentPlaceHolder1_RFVName"), document.getElementById("ContentPlaceHolder1_RFVFatherName"), document.getElementById("ContentPlaceHolder1_RFVMobileNumber"), document.getElementById("ContentPlaceHolder1_REVMobileNumber"), document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var SelectRegion_RFVDistrict = document.all ? document.all["SelectRegion_RFVDistrict"] : document.getElementById("SelectRegion_RFVDistrict");
SelectRegion_RFVDistrict.controltovalidate = "SelectRegion_ddlDistrict";
SelectRegion_RFVDistrict.focusOnError = "t";
SelectRegion_RFVDistrict.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District";
SelectRegion_RFVDistrict.display = "Dynamic";
SelectRegion_RFVDistrict.validationGroup = "ChangeRegion";
SelectRegion_RFVDistrict.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVDistrict.initialvalue = "";
var SelectRegion_RFVTehsil = document.all ? document.all["SelectRegion_RFVTehsil"] : document.getElementById("SelectRegion_RFVTehsil");
SelectRegion_RFVTehsil.controltovalidate = "SelectRegion_ddlTehsil";
SelectRegion_RFVTehsil.focusOnError = "t";
SelectRegion_RFVTehsil.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil";
SelectRegion_RFVTehsil.display = "Dynamic";
SelectRegion_RFVTehsil.validationGroup = "ChangeRegion";
SelectRegion_RFVTehsil.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVTehsil.initialvalue = "";
var SelectRegion_RFVVillage = document.all ? document.all["SelectRegion_RFVVillage"] : document.getElementById("SelectRegion_RFVVillage");
SelectRegion_RFVVillage.controltovalidate = "SelectRegion_ddlVillage";
SelectRegion_RFVVillage.focusOnError = "t";
SelectRegion_RFVVillage.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village";
SelectRegion_RFVVillage.display = "Dynamic";
SelectRegion_RFVVillage.validationGroup = "ChangeRegion";
SelectRegion_RFVVillage.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVVillage.initialvalue = "";
var SelectRegion_RFVYear = document.all ? document.all["SelectRegion_RFVYear"] : document.getElementById("SelectRegion_RFVYear");
SelectRegion_RFVYear.controltovalidate = "SelectRegion_ddlYear";
SelectRegion_RFVYear.focusOnError = "t";
SelectRegion_RFVYear.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year";
SelectRegion_RFVYear.display = "Dynamic";
SelectRegion_RFVYear.validationGroup = "ChangeRegion";
SelectRegion_RFVYear.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVYear.initialvalue = "";
var ContentPlaceHolder1_RFVName = document.all ? document.all["ContentPlaceHolder1_RFVName"] : document.getElementById("ContentPlaceHolder1_RFVName");
ContentPlaceHolder1_RFVName.controltovalidate = "ContentPlaceHolder1_txtName";
ContentPlaceHolder1_RFVName.focusOnError = "t";
ContentPlaceHolder1_RFVName.errormessage = "Please enter the Name";
ContentPlaceHolder1_RFVName.display = "Dynamic";
ContentPlaceHolder1_RFVName.validationGroup = "GrpRequest";
ContentPlaceHolder1_RFVName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVName.initialvalue = "";
var ContentPlaceHolder1_RFVFatherName = document.all ? document.all["ContentPlaceHolder1_RFVFatherName"] : document.getElementById("ContentPlaceHolder1_RFVFatherName");
ContentPlaceHolder1_RFVFatherName.controltovalidate = "ContentPlaceHolder1_txtFatherName";
ContentPlaceHolder1_RFVFatherName.focusOnError = "t";
ContentPlaceHolder1_RFVFatherName.errormessage = "Please enter the Father Name";
ContentPlaceHolder1_RFVFatherName.display = "Dynamic";
ContentPlaceHolder1_RFVFatherName.validationGroup = "GrpRequest";
ContentPlaceHolder1_RFVFatherName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVFatherName.initialvalue = "";
var ContentPlaceHolder1_RFVMobileNumber = document.all ? document.all["ContentPlaceHolder1_RFVMobileNumber"] : document.getElementById("ContentPlaceHolder1_RFVMobileNumber");
ContentPlaceHolder1_RFVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
ContentPlaceHolder1_RFVMobileNumber.focusOnError = "t";
ContentPlaceHolder1_RFVMobileNumber.errormessage = "Please enter the Mobile number";
ContentPlaceHolder1_RFVMobileNumber.display = "Dynamic";
ContentPlaceHolder1_RFVMobileNumber.validationGroup = "GrpRequestotp";
ContentPlaceHolder1_RFVMobileNumber.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVMobileNumber.initialvalue = "";
var ContentPlaceHolder1_REVMobileNumber = document.all ? document.all["ContentPlaceHolder1_REVMobileNumber"] : document.getElementById("ContentPlaceHolder1_REVMobileNumber");
ContentPlaceHolder1_REVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
ContentPlaceHolder1_REVMobileNumber.focusOnError = "t";
ContentPlaceHolder1_REVMobileNumber.errormessage = "Please enter a valid 10-digit mobile number.";
ContentPlaceHolder1_REVMobileNumber.display = "Dynamic";
ContentPlaceHolder1_REVMobileNumber.validationGroup = "GrpRequestotp";
ContentPlaceHolder1_REVMobileNumber.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ContentPlaceHolder1_REVMobileNumber.validationexpression = "^[6-9]\\d{9}$";
var ContentPlaceHolder1_RequiredFieldValidator2 = document.all ? document.all["ContentPlaceHolder1_RequiredFieldValidator2"] : document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2");
ContentPlaceHolder1_RequiredFieldValidator2.controltovalidate = "ContentPlaceHolder1_txtOTP";
ContentPlaceHolder1_RequiredFieldValidator2.focusOnError = "t";
ContentPlaceHolder1_RequiredFieldValidator2.errormessage = "Please enter the OTP number";
ContentPlaceHolder1_RequiredFieldValidator2.display = "Dynamic";
ContentPlaceHolder1_RequiredFieldValidator2.validationGroup = "GrpRequestVOTP";
ContentPlaceHolder1_RequiredFieldValidator2.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RequiredFieldValidator2.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        
theForm.oldSubmit = theForm.submit;
theForm.submit = WebForm_SaveScrollPositionSubmit;

theForm.oldOnSubmit = theForm.onsubmit;
theForm.onsubmit = WebForm_SaveScrollPositionOnSubmit;
WebForm_AutoFocus('ContentPlaceHolder1_txtName');Sys.Application.add_init(function() {
    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":500,"dynamicLayout":true}, null, null, $get("updWebsite"));
});

document.getElementById('SelectRegion_RFVDistrict').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVDistrict'));
}

document.getElementById('SelectRegion_RFVTehsil').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVTehsil'));
}

document.getElementById('SelectRegion_RFVVillage').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVVillage'));
}

document.getElementById('SelectRegion_RFVYear').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVYear'));
}

document.getElementById('ContentPlaceHolder1_RFVName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVName'));
}

document.getElementById('ContentPlaceHolder1_RFVFatherName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVFatherName'));
}

document.getElementById('ContentPlaceHolder1_RFVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVMobileNumber'));
}

document.getElementById('ContentPlaceHolder1_REVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_REVMobileNumber'));
}

document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2'));
}
Sys.Application.add_init(function() {
    $create(Sys.Extended.UI.ModalPopupBehavior, {"backgroundCssClass":"modalBackground","cancelControlID":"ContentPlaceHolder1_btnOK","dynamicServicePath":"/RequestForRapat.aspx","id":"ModalPopupExtenderAlert","popupControlID":"ContentPlaceHolder1_pnlmsgConfirm"}, null, null, $get("ContentPlaceHolder1_btnShowPopup"));
});
//]]>
</script>
</form>

</body>

</html>
