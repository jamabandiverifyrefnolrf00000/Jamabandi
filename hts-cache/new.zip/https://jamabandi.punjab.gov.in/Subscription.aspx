
<!DOCTYPE html>
<html lang="en">


<head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="google" content="notranslate" /><title>
	ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records
</title><link rel="stylesheet" href="ui-assets/fontawesome/css/fontawesome.css" /><link rel="stylesheet" href="ui-assets/fontawesome/css/solid.css" /><link rel="stylesheet" href="ui-assets/vendor/bootstrap/dist/css/bootstrap.css" /><link href="ui-assets/sweetalert/sweetalert2.min.css" rel="stylesheet" /><link rel="stylesheet" href="ui-assets/vendor/datatables_with_buttons/datatables.min.css" />
    <!-- pe-icon-7-stroke styles -->
	<link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" /><link rel="stylesheet" href="ui-assets/fonts/pe-icon-7-stroke/css/helper.css" />
	 <!-- Custom styles -->
    
    <link rel="stylesheet" href="ui-assets/vendor/virtual-keyboard/css/keyboard.css" /><link rel="stylesheet" href="ui-assets/styles/style.css" /><link rel="stylesheet" href="ui-assets/styles/responsive.css" /><link rel="stylesheet" href="ui-assets/styles/plrs-custom-v1.0.css" /><link rel="stylesheet" href="ui-assets/styles/CardStyle.css" /><link rel="stylesheet" href="ui-assets/styles/custom.css" /><link href="ui-assets/landingPage/css/style.css" rel="stylesheet" type="text/css" /><link href="ui-assets/landingPage/css/flexslider.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="ui-assets/styles/select2.min.css" /><link rel="stylesheet" href="ui-assets/styles/selectStyle.css" /><link rel="stylesheet" href="ui-assets/styles/backToTop.css" /> 
<style>
    .d-flex{
        display:flex;
    }

    .margin-left-right-auto{
        margin-left:auto;
        margin-right:auto;
    }

    .margin-left-right-auto h3 {
      color: #ffffff;/*#126f00*/
    }

    .head-legend {
      padding: 20px 0;
    }

    .head-legend span {
      font-size: 20px;
    }

    .digi-pub-footer-top{
        padding: 25px 0 10px;
    }
</style>
    <style>
#SelectRegion_rdPeriod {
  height: auto;
}
</style>
    
    <link href="ui-assets/styles/plrsheader.css" rel="stylesheet" />

     <script   src="ui-assets/jquery/jquery.min.js" nonce="h+nLG9f6Xz7fhyYbY0csKQ">
	</script>
	
    <script   src="ui-assets/jquery-ui/jquery-ui.min.js" nonce="h+nLG9f6Xz7fhyYbY0csKQ" >
    </script>
       
     <script src="ui-assets/sweetalert/sweetalert2.all.min.js" 
        nonce="h+nLG9f6Xz7fhyYbY0csKQ" ></script> 
           
    <script src="ui-assets/scripts/plrs-custom-v1.0.js" nonce="h+nLG9f6Xz7fhyYbY0csKQ">
	    </script>

    <link href="ui-assets/fontawesome-free/css/all.min.css" rel="stylesheet" />
    <link href="ui-assets/styles/modalp.css" rel="stylesheet" />
    <script src="ui-assets/scripts/HightLightFocus.js"></script>
    <link href="ui-assets/styles/HightLightFocus.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/tblbrder.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/lnkbtn.css" rel="stylesheet" />
    <link href="ui-assets/Pgstyles/rdbtn.css" rel="stylesheet" />
</head>
<body class="bg">
  
	<form method="post" action="./Subscription.aspx" onsubmit="javascript:return WebForm_OnSubmit();" id="form1" enctype="multipart/form-data">
<div class="aspNetHidden">
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="oPzlWsQKFqGt4o1Bkid8fTXdieMq/zMeVUpUirCms66ClEfmgqGywaPqb1R/lMjVDMjI8cmSij+TaSUtXyW1jbkG5MHMVQKWFB4PnUCW7B6Shm2+y1r7VyXpbIkH7UD5UyhdTF+VkzhMWRat0cKr9ianpA3ftjeW0n5ZDOx/UR+jfXpEt5HUhwmIatsZQdqyIxQN61sW0Q750Zr3taGM/a2M9jZq/7vf3+k99nmOIFEy2Up40TsLLxUsNdld6K9w51o5LHizkyIFj8uCcJcETp2zHwttrog5+ANDPHZqhxB3a+ixaLtT2Kbuemmm9MUWFxZ4xNMlrXfVEwtTVr6dWe3MimvVzuGKL9liInTN5ItyeNmXb9GWr5feDbGUDw02lpPhc+Qw8xfyePOkkh3BSdtow3k0UMjxWIhgjPcP3tWh2Y0ushqx+9A8z5E28FhgyiLi4AwGzkMAYt8Z24JHMnDFXBgzRrlq0OUZEx8fjzqovcQnuqrEBNfW9RfeCnPbYy9/cG7ah0KA0SAJ/rspWGgZD3VRM/6AVvX5dt/yNgC0Z5IKElEKTgf95eVyHQ1RuVQdu9onzpmPpn5LbZDxYfMCefxAcvhVqnQPGWQy255Y53gX3m7sNbpPn+S1jVA72D3aFQ0E7mY2zT1slL+mNdnu8Wng6uLee87GSaOSmMo00oOyYvetCx06WDwQ/bKmWT11UdvhqqSovjHRr/VvIQMP5nUXDrE7swGwMvhlWmn8UZDdSIfU7A21V9+EqnAqZKM0xF35/CCgBlbUoPjIs2cj8yYlhzn/8ggXIPnZIxRZNYTF50ZnFzYtkO0VDx3HQkODo5OV5sIRxb099KtMlSLoWDRyWqY5oU4VyR7mNsAyzKaLP0R+Ge9kqZfvWZlQBx47xYFN4hn2l2GdwRBBleU9eN5aAB+qLRDzEDZ8QOMCFMGGqJVgfBZp3bk1v6xzcs/WsMLF2w3qPmbAgXtwdDDUKCxvbdJel/b8Vw7MjZnqhsEYu6f6rBg6sj3AFQ5kQyKTmzC8OYMpu0OzNT0DlOG19CBgV7cKt+4E/M2Zgk6VU6gKwJa/mfTNWxiwlOZZ5UVp7B8zXNvxokfy++bLts23o4xubKujQ2THSWs569eHPnbpuQ613FKThNN2F5x9zS84EPsWPh+Uzysvk2dLWsLiffvrLC+dY8u81GmUbEuuJ1bFvQGpZPn7PJH+765j+blwq/u0/RjKKSEfarP97wbyzCEsJS+cryOqc/WhBRpG9RmkRGYQ4x0R82PNBzo+8wIVoXotQGmh/NmnntHUerxRtE8IKp+MgW7gQiPUKVAEoTDani7Vi1F0Fa0cG8xph5oaa8Aiwt77G3cEmcIlMnBvTZ+fG46Q4Ospn8wXf86H19eUBEqUJQSlgs0ZLPtVXCny5LfXfUISfQpxDXLm5T1HQ52i97vNYxyuy/NxHJzjL8r+2bjTy3llN81A923NxLUk/DCJ8n5Nop3/vqirXCwAQGEW4V8pp6nfOsM389E9AxTytBUrSg5nhqMaLlbwumrUGvdEz2Fnth+TVMJAsJ3YSYg9U724eJy0ewoh/ndYcdCD0uPs7CrCMKbH6jUJ9ds87IchA9oLu6ehHTuYOZCm9A5xLT2hDde9eUOqVD411TlbRCvKO53WVTAg3hZKJDkG2JeLLiEs89xVkNYXtp3wlG621+VqLv0Lobj31iK+FgQRTpSsumhOHwB+vjVa696TTxZV7MASHOlSgwJ39X1AAZ3ObbIsGmYMoMVFFb6jSSKXQ76ntNa+s0Q4ugMy10HAdS0+hjthLManf2nBQ9rJvXJ8RlWHcpYHXjIcJUwKItLCV3OPa4Yv+mEyWOJ9Oktg1tHPuuPy41ELOfd6PSacdMCxYoSaOX9M4jaDEnqgXkKTXA8yKhSBxD5JERnHYx0L6aOjF0FJn2GcBFjRfpkvW0lXYHj8YfzsOi38GJmo3MMN8sXaA2qHed6zfBpLec2f0JcZvLqfQfKCZyDUswWRwMmtl/nlAzJEbYKi2DYYOqIK8tyZI3hTb29pNvXivhmZS1LKKzZEIchHRq37msJFx8sNS3DjeySEx8Z3jsrNyg9mzOR1auODv7TsK5TQ2VsVEYw+DLAjkAT41uDAG7n2vbjJ0N+N+bMkgWq5UCVUh90WmA5M+9xo/VCwOcsVWsZBCTqrP5i65cKs0Tbfc7o2wISD8D6Z+/YEo0E67rQ5AuV78/Heo5z0q4O9K+SX5yKL4Rgjyu4ArHhrxqVgDhipNPVH/hUdYVO5U3ifvoxJn6oziR7gMCyNZlqJaIBFq6/3Y8NVlihrzEm3DEX9+dd4gOOtrUeS1ibGHARIlHeGG3gfZ5oYtJj5g5ym80tI0s9ZFL8mAQh8ZNssGNJbwcNoGoxR6eELmq9aVWpnoYECmxfXYgbREqZ/nFequq6WW6HQ8wNvPq34PVqeANo2yTmiP/evteFPchqLG93kAwCMxse+Z9T4Zu0Jj34yZ2GkOF8BHQHOU3csW44rDTJEsFfTnc1NlaAMpO+/NATqCwz13fY8ZQVg4kNm1jL132Exb+rZ73LjpdtlGinRfCaReM8qSHjCAIjQnbJQMKBwLbou85ffjZqyqdW0jgquUJBzTUHPDMgL1wNuZqFtUTMm1VDnCh9Zxqm7nG9uj6z9DCFRbB6cKusefGh7xtc7FNugEeirVBAEaZ9XGT0cCjZtNUA0kYU4bhC3AbLzG7YGg0+SK+SgoYdZKz/LX1e4F/HelTWlnVWN08WwNJRCt8DO5F07eQrWPm2dEJD0tVy1A9LQ4DOw+MkCKhoFIPY/wZZhnd+3xpUB5UCDugVyhMIg3dXMNbJrUHRpQheKpL4MrLvTDSV3BVOFBmRR4nGny6ULXutXeyCfzWtpnyFY8+pw82FFUo9V1lqgWSva0wFSMrQDV1VSuLai/eTp/mVcB89sCVOOHAKGKdctM4ejYxDsy0lPOroeyewJdVTsV/nP+NmjuE8NVIeBldKwC6d+xTHk6zOe4eRWeTq8gOJ8lcfGUat5LLSr+eLiynnnJ2s/nLa5qaG3uU0mg5xEdB1klO4Skdz8AZJULtyryW9+KDV1eO82m0RtstoaRgoS/5zeeS/G4vE15KaMuVxzaJy8z0GtBolXfijSY2owu5LtY/1j+pIo93Q7NPbfmQOsIizk40lPNFfnlqAAymLdAknJS87EmDwHLdIZ4tX/6tsltxvfd+919G7jB+ZYhgmpqJTqQSk/oh5gbd27KBATyE6+36VMRjbnp+Z5N2Lxw2aO1+//5bQpxgtIGaZKl3CMi/0cB14wySz3rFk6CfWukB32H4qGx56RdzOp6VEtWaKOvSgcEixYB6Qk4rkWYbBrtFDmwEbtEX2gG8uRpJqpTKwneMYFMN6beiCdqxwmi8uQXIAn3jrlYt1wbqYV32UTrSixO0QCEFPALE8CHbksJBovB+YH7thFc4g9QpGDYVaTUahovIP/ly+nRC4I7AwzWd0LWMUElnAtQjVDrKP9y6c1hKYvhRN+jQwRm95cgQW4laIF+FhmGZox3294u2k01xIbFRuZx4y2ROigBPfca+w1oOeEhHgVbb26g/knGJu/TRoVO9viilzh/yq916/99HyyXQZbSSiTWPkFP/YufY9g57gSD6N+BgBTfEaeUxWKNejDIWJNuOmUsr0nXAbw4KVGOXOahCkRIdYJ+tDX9eYKnuUiNc2v/vbhUYAZROd4m71N/ifGAaxDUlm0cSFJvuCDZUrBwJIVKE6nLDp78IbXk1nuFVp9jG9C9KSXcEaemgT3dLLJ6OKAodiMkIf5vl5NMGF4uH0XxRiwPv5FKx4HFgf3YIesvyUgIGPsUV+KCdDbVOVJ1tVR6oLRtF1hX0AO013DMIEJyTKbcz1GMxpkca2GXrXU2qL5pVrsNaAK6A7bQ8Y6NLSyoTjIaWGMlZrpXZw1JeRRHFdz6xYKO8uk2niQBvzrysHgc6Oy/sILYNasd6pGPvb/NzV3kIaCEEtt+an6tuTU2LjvPWzv9UCjYex6mLPEgwQn/pphnA3fkuUjWUN5T5l33+XqotbJX3dN4oMoJbluS8qLARtDnNDdXTnZ6F3Gitmx/JATL2OrSNKcoSvIjZDmJXdj+3Yu70sr/D0wWPiCddtY0AINAFf2Svm4g5ZGkH198eMdsF5UvCRYsaAX3rNSGvH6cmbiOBu9O2vxD/d+dTLZ3iSPNesTVeQMErLn17ceRsrB06/lHq5lo/SZtEpPe/CPKr9WfU8vMVRSd9qRBjlw+/07sAwUzJhNUTdlfW+NeXTKexwd9icowSJwJvELCBLNePmzmfuOS3tjsSLi3BxwKKKe8hYTJD8phTB+7/+MLn6n3WWPSVmXBQ6m2K/uC5qySgHeLuk/NLV0RtNPU3PHYm4vuenypDaSQjCRi5KAGe32iySm/v9iLAOW9ihiXCk0GZDNwunMLsHcnHAtIHzgzgSxbLzaBWJVOtksS7I5nxN4Tk1kWOezIhJP1BbCn0oy22LxugV5NCamFk51lWz7DrGNOC2IwpCcnQW97ky9xExxtwGjh8JhhHmQBR13j7bXjCqgIjfLbSA+cpvuDwGr6/YjV4PHqxn3KejtM9Jl9l0hpvvQRG1J90PwArOLbHi982wqL0a2u+sI2txY6tFaAXfvmkG0dnfeyPbrAMY0p4U+DiSeEDBuVNQm7h1VzDIs5vFXhUPus/qNmWTNaY3hS/6VtPE9bQV+z0LFFLVzh5S7DHUbYeFCZCmwYRwbWt/QcI+q+BYWIkt4SUKsZ/RjyvR+dEdwIkeDQZkDvnMwxY0ps6751LjG9ol2jPN8xeaW200NSoU29U4Mcl1vYWqXEDar+gOYtQvAmFfkVl5tbtG26q8aJfomf5oSgeo46Ca4RvP1oFKyAhHOjzNbj8hwZgF4GO3ZxmqDgeLkH5ICN67RHLtFaNmrPZY/Wd8+aZnROX6cXhmasbu4Rwqw9DL0KVk/Z4/TJ70KuwEuJZ1lFYqa7xubFGnhHZhUtatXiSr9InrIwoZlHfPNMP3b3HPUR7V1dC9fp+WEo/Bm/ln2Ej8FMXe6UQ5eBzeEV5kFXC4N6DwhN1gKBj/rR7RoylWtkbt18dRQKn9SkriuEdvdq+qFCn2Ppj+ZWwI4kWkbPr195s0KYj2aLGD/TuTCY+tOv5D3tt3qRiVOOChy5Ag5Pe4FCNwtkCH2CTBjIsMHRTNKuXFkoVtRCSpljocwAqztoavfudN8Eajw5Iv1JTq5lEA0LZDSoNPl9UI7CT38abb7EL8sufOxKIqBy3ndBXclEt+HjCAT8OgLN1p3scKBthJLpm3mFkQazjFhctAAIrVO94zc3ahMiFQGK3wgX5fll7qNq6DO36jWMjthTv4Szfxnx7cBZsK+DR6XpbZq3JjWIV5qvOxCZlgDp103UEC599n7QTIOHk9mBOdiwZdaqyc40eI0vyfY+B8kh5QeMhjb6sbLS+DFLHy6BVsCcj5RmxXxa4NVJPLbau8BNfYarMSe2Bt7hDPaoOLNZdbomltjuieSbUhqDpMGgOKIdEJj1glDS4LOyzpjLkItWGBxA6i1dOiolcVRzuiXhmRV0CTfg4roNe8IGToLWugzdiBH+sPd/hY+sHBH9TUXHlUzaQRLQVng33j8Pyiu6zHoXOclQ9ma0BvcanZ+eHHbvbWp5+LssF97H+XrKkWOwB3DSf+SGu306ZLHHLwZ1qa4zifPWieMpIDc4lhWnd5VdJl6NbCnaKD5XXXD79WMyuTLY9Apv4xZe4tJKEoisxLreojRvkYe8OFjt1tYCsMFbVzHlK2NF51vta9QG/Pcarxvr7uBnIts+SVF152Wa9b6e9+Vz7LfHf25h3WPeE3GFXT8IaO/WsWIIr3iyieXkIL4RGU8Fyb7WCOmHiKUTm9zIjoQJ+XX2bmQVd7ZFWXNBYzBh9qUsnwa9+2W+kd5VMkoyp67wvWfVcfFmWy9XIo/z1qmYgDmz3pUodAH9ylseXn0W6jEd3ueY4t+kpSQFNxmWK2hpRdxLetMqxgmsRcM82KQ9S9YLhj2S8YLvzWKGsVmLRIITleT3M8VLOaGPvCrMyUpd+pCu0JGA0cbteqohgAdSnhe6AO48JYHVLPAdmMb4JSe7D0784Tdu68G2CYrBQT19LCL/HPcfHlHPACWP2Or1UNaAvtySH19Ec4gYj/crcQdKTKm5TYKK40Wvpcr5JAST0GFWeDwO3SnUE6JjES7+dADIxkIuWoCBqz1DB+KVRbpYo8/AZ59By9CVlj4vWRTFZ2z6tRRvdB5VrlmLjJo5e5/ION+2flSaSkvqLNWTYn8eDwF9Te+tORDYE8+qJcfRlNZlQxogqYh6dVWdbrLO0ivkcBhTVo1Tvmcig6zqNQrcOPoOqQi3/kY6zQoDjt+hqmKxczDrlKE71gTiZbSWzE/G2YE5vZG/twmiDgGXVEjPv4SSAaC9+MbUgz17gmVu+BArKN3y0lqmGGb+dJe1vSUCXKkrETMsk2qNnnycJJ2DLQQSqhrVHZQUXH4rYcdHTm8BDiz6pAZ30gaoA4EKrfuDo4fgOTzwAMHfyESaHrZKtWZKWzCWvf/V0hcrlYkoqJ4RPjpp9VuoWvpO7rt4XgIB5BgSuv01U8zjO9ah1WXttlbfpQd9M14TwDV0cti6ZczCXrzAEtG3qJYSWJwBIK4n8d4gWlMv1nLxjXTh4/FUSpLmR82q6YYWTW9FchvxsUrd9/aixqHSa9svq2P2V0FJL9Gw0KfRB5xWlzHDKsbtW0pqJilNdgY912sFeYSxFP3Vhs/ljP/CGsxc9O2G2Hn11O/iX4Lwihcjin/xe0ypyVyf+81Q2y8H/+o71E7Nwm6YBcYsycIWEDOppF91kAb3qqlXrHPGlfluVmOT+P4sNLo6QxCdmwkHvssKkJg4XR0aR6Zg9U139JWMjhK/KSz/tkTkHdu4oF3Oe8Q6FMze1TeDVTufh5gcw1q3vQEMnxQB85vmmwZ3iBaUXEGcdGWyitzj0MNXxMhAFeFPyUr80SPMEKKyHxk3rjp4Xn0lxouRNvR7dPeK0yA4A3+ngv5HULK0C56JreiF7GU/otDAeWL4BDvmX4N2sSN/wvQ4xmPAcNX6eh1PF2PN9TSOy0CMXETI9u/G0cRWEhNEMrUx9f0TxqHcXTy3R7VIRy2qeDGUCiVbteOhbvan24Js6SGe7E6otufyrO3ILkCPjmB9mXx/SL4ztFtISZFvzdBPmPOuVi5N7nIsRXGJx3eI1zTkN5YWqFaARINC1yVs8+W+mwmZmmCk3s1ZORQp4IK/4uusnc7fVxLXXC9rYg3oljagRMX7In5zkKgZUuXndJBDs3r81r3HXIanRhwMMlnIgguixK7C0fl5xMGiUiobBrapmgKi0SPRbDC65l2BZi7WnljYDSvZyDIAaJWD2D8fUiorjgmJASkTvoDS4vsbpoxuN+EvDtLgOnB5qb9a0u+aouGXILMTlI0BsucVo9a1F128Be1vXmkT5yzityKN0FNqHXy4J1oQ1U1k8JC1aHjN1TkpdzohsDWHemni6gbThArI5kjpYA5bBZduAP1FD3e1Z+SWlnM9tn/aKfWpcpLjPyESIhatep4HkxAyr52Yy3wkLKxpqC1VB1wUZyJ5gJJHBqZRePqRDl34bKsh7LqnA3pJ//+bEOwO8Why3u4hg8XH7vSY3XHCnf1rMMtQWzxPdCFueFC+eYPD4CCftfpE1aH+SuWS/+maPyxwg+6JV40gc5jZbIV/DISmRtrp5VARzz4qEyYZ3JMwAPbO/FgdfVd/8nEG3/To7nNusKiR6p4B8dmOE6Rs22+RTbGMEQ4o+vF5qdovPDpgr/bibYiRn2W6unr/NwfRgIofgApwifNZl2+xX5SrkekVcchnFtfhlqh/VujPsgy7A/JUDp95POaXdW1ErFULZq1eUXf4HW7Z11eG3xOpISSeF1JWlwzrSdcNzQjkP9OOYgjGZLa4EGUuGcU8K8lHVMmRoG3TKKXGgJZrfiyB+zedzXofWjSf8u88D4mfJwgTN3ry07Ny1RiigH0X3XudVS/Q7u/F9dLKU6yEbMY7Mv2yux+F6nKUTDhF2MgnKulbVuypdxEuhGHfvEw3Y5BJ+2ih7SDXwsP5VOw4rLEy3gI2jUuQTYfznrt0azLyVBaiWlZ7iBcx+eeK3psj2VFptq0lUmmvZHtH18X/1GrnyRQ96k9Z8/0VG0y1qzP6x0T2JzMff97i0tYbaqj9fxPU847CqURlRp7fwsyCQcCLc0QHpEIbueUbc1TSO8DJoe627LE2GHnAzDsKpEggKbicSBizgArgw60A+CiYhBo9TlDYSXotXznz6u8dwTzePz0A843pDyULjrBHTYLxL4f1wBsV23eZpQJaNjFpV7UZUXvVdOkmiJ2pK+/n+EzFZbGXEITQcTePkNe4xczpHJtyjFbkx4vqTFj4pfynHidKRKirsZ87QAKwjagJpN5NwZNd4OY4W6OOK4WY9Z1ubnUtZdaJMMUxLbufz2AXwhxH3FmV5R4vjGVXey4DQsyudqrix+3IW4Z7o/H2d6rgNRZ3FmnpPlD8l84RTB+4TRbVX30TwJu7VWVQMjg4M2IiOjDuwUfJI63NkTnuok4Hn2SMRAvPzBOURzzt2K83nF4dzIDgUjjgI6hQyuoOp6OVItxF2KY/dFAdcGDrqtkX1aHsScCxbXy0jzPB4I+IX6FRydVRqe+VILRJM/8HCVWBrtToxZIhWAwrEeWV7Sn2W119ZrJj17Rp0o7HTgdrACB8UxhVAUuy1t0opPOr5fuwVJoMvsXh5kgq5Yob7AMxgoTAwxwOM1U1Hk00LuItjOCgu5cwDeYq4ZjStPsjRfpUZn+c9+zYj8q1i3Lmh2H+uv/YYwNY5iMswgTFydqU9sFF4sAr0ehRZl+8L/Eq1Pbv6qKhQuOPmIdcyPBV2H3gU1VpHtUSu+Dcw8hH3q4AU7tiugkVfquStuRTAmghVlWNoOxRuGi3+P9dFUbsgYxnae0NH1a8uiyYsAq3qZwaMeNqtH91lhggWxA/A/BIHIn0D3MNmA4cKGuF2eqVkOw+ggEM5Nh+hMpWWu5vRbCHGJGPQpsrH8Y9MLFRzMqrOvmLSh9aMNQHJIB18JDRPCn5B8/dF5vl+0yx+WZ/jTQ59EztpYK9EUfAY1qhMeS7KAk7ceEaGItSLn+utls58Yqs6WmIFt22PvUJqLyykwde++v14dOWBb0qY9fXGftA/5kY+YqS9xoJH7pemfaQEv89fkHx6wi5eMB8o5ErlORUJJt7yYQpSH4f8g44I4GCsXbJH+ZqPyCIXD3vM/kNmCHP+tE9B+U52Mmh17VoqvdEigq+F68AAOG+eqb8nYLuDsV0sehZR5GObhRGMFGctri6Yjas675uWJ9wSbZE72FjFqW/g9ITjB2FokFgxJMQZ8LqK+93dxXIYDeeMtXWmAhY+SdZ91DZyUt+Db1RsPVAGmQMXmwlXb7fi754hwl0bYtq5BMlC9m/5+R3chvsxpDhB+OAl55JqBo32RS/VFZMvtpqVlbbJYnzNx/bVDunBYjGvOGCsBwSNZu0RCkYeCwTDapJ+CfpFVTCrBuCjiKnlOL8S1uky4QR1XS0g7FDX4H42l1fKP7eaE/EJMKDoAkHzK021B5U/pHF65x7hzSoSdgT6UW0maPIw+bzHRLnuvcmHVvIunApQJtG7ewD7pR7bMOloPnAP1o1XEHpitAn0CQtPniJqCn3dfK+QAU0iG+7S8dFXS2tFOd/GC4oP2NyH2k4aG5ddfS443KkKGfikUI3GLiM2X5kLh5TXatumEqbZ0RhD7DwTRM/9KxXIRNEnJv7kkijlcQKGQ1w+RuB7exgbwsDRcAb9lplQMY8Y211Tu2QVj2jn3IdTUvMuGcrkD5xfzliNTiH8K8E1eI/b4lBFWUnKvVPolQUk/8NuVdWkoZGWO/mY+nZexEKxdrPB49hjkRARx7pJHenKMXMqDpxWZZZNoiaLPjuPrh8jc1ZdNeov7Rgzo6ZzvFiWz07v6ud3Czsjp4OVPI3HRhJ3LOvYSioUocCxJsDmfGtZIOWWJ/UeUhHwA4xn7xPVno02ycGCCx9bmREVfccR/Zp1PpwspAtWFcI0r1wpoUlV9orjNPpdI8jir8WR91iJdcAU65Yn3UgGkEZ/Ajm/owlTd/2i/4F/AoszYc4xjx2q/83ZV4SVv6d2+Tjhs6lww2pubCkPov7isGDBAuATPpso2nos2WCJynZrbePIood3ofEVj2rcNJDrpSy83t+XzAIyeKPDFQBfR1Y7t4lIewGOYUJmdRkq1XPeFzn9aZGoTrQ6P7a1GMfxg6a+gbnF3umjclCOyNv4qIJG0mMMv1M5RCvNGtkbOEfbRwfgYU8fvsCeL2MK1y/OGJMN4PK9njr3L90RGfs5fONsHxvhe03J3BG3QeNHktUaWue0Yx3vnbbPKp0IWPpACFeJb34kV0HuZgJnUxRIOlw3iKAaU/mKxT0j2Lz0Id8fTDlROJnY0T4NX2SyHwcPqRv1BhBe/+ZjvEBVBklJc21EP1ESolxh2UY76PX5U0n8nH5cWM44UJkNL6TKjQDY+7uPrQgLDcuKucfxR39pWfT4JsB8+QDqIqpicrl5eWUzf/Qcb76qdbPlCBoXMvDR0H/Y80lOhVHvwtHI7pXjNiIop29Hk3nbZzshJaOfx/mkaopmWQCyeysREYA+xcrJ/ztsq/WppdJXpJ00OweLgkAl++bm22abOEMJSlp1YHT1S9u8NX2O3grVC+MvvzZUKwk/A9bdPonzTw0dRFj02t2wIpFsTs+V/8ZttTWVjN4D6oirSNYYf/PvCHxjZYOeaWaKpR+V3DFu6v3kQC05xT+4c8KdfnMrslchMPtKw76RjmzWlrfVyDNGvicqkA368IRbHAF7VVJU0FtVDkuimXh0ppH18mny8mfZ+Ji+Yff/3o4y89kmZ9p6ePCPUMW/cFuja/JhxDgSEBfry3p9k7whK1a0QTxCHOmkQQnNnWcbhe6uLanJx7lxp1zgpTLB21+0AIqxtrffKw24btYlBnxjGBLjEQrA0511pAzo+x+m3j9WwLSEvQOwT2NIolfCAJXSPn8aDdRt2TkHlqhNTbyeCgQzQjzYfpzriW9Q2kFrJclA50IAwrCapJemS70D3oAEcTVoPOBsAmzZi7SN8C2c8FygpMIHm1rOr/f8urByxGUOLa+Had3XullbJeaj72fmJ+4LKcybft0uNsyxKgVdwXf85cGrR1Nyg+fxd1deqnjPYtKdE=" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZBbRI-vLFGPASeYxh_KgLGJAGhxxxQHaAFUowMEJ38zbzJMIHhOPM0QVtz7ClVSrJw2&amp;t=639202794265548063" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1HoTsDJCIwegf7-cSVNQxKlxqJplUAag2gjZMR_ctGyeKzMDbl61mq8CG1bXK2cKIO5F_d_eACHU7rvEovdRsHjPwMxL_2RbhdHxnXThSzdTd55hY37B50zmwPwIsJ1FnQ2&amp;t=4623e90" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=NJmAwtEo3Ipnlaxl6CMhvqBoWBYTDUGuawA_2GYbNQlKfMSt2G6fTRv2v_CvkMQC-NDKOxcBHZBsr4m43UZoWnDElLWlfRSMae7wFN5-j848Bfbquym3Qmm_a4KPTP8MlNJWDtdRKeoXno9ND71Mj-dmT4RATMPqWph8tRm5et41&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OAh7tEdde-lvG3-30egxXz8aAgw_K6hDRuGQnL44pJNvGX0k88IpkhwtBpf_hp5FI_xl-S6IOzDAoSwTftgBkdwIVbozv2itakdYRoj6lyvW2iAmc3lxcxcAsYCLcWBMdMG64QNAlb5JWK1NKm4PkKk1&amp;t=fffffffff7f39b88" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=eE6V8nDbUVn0gtG6hKNX_FhBCrEodp5vWm_YmsPN6L6kd8QLjOqCyZgy7R07cf_-q6jt6CUudI9DljzC2TdIySTnrKddg3RKYGaYn4SUdM3lZcSR2HeYBRZYoT1mfgRe0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=mcAASOSteirJeuV-3by3Udl0BXtV-9r3zqXldfMmh4nMyRrfOyOUzm9PjtxhXMnCb3u1w9Bl8xQwuZ3vJQhQk5K_jbJ7TUVZSafdbK767TU1&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=jwf4VSQi7LeShc44FJ-gAeDpDtsq5KMQ8v0UGSwL0n57o9DwezYikDFx_PyigWyXj_0OxQaznPKYQt6DlIveEltbNvWSF7tPucSRMMT0SDIeemWSUwY9H6muRTmCFq5y0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=nai7mGcYyE2dix_TwveLDUh5s-4A2YxYW54tIrkM_TUunAGPTDDQIgTi7_jF0ZDsXQf2DAdig0qNTG97Zho5rt0FlKu4f2urbVFVmxpi95du0q96Rm7avCmT7YWIJACc0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=yDT7ulzE00Yqzs5zd38bJ9uYK0mE0NQaZIaf-pwWkJgWYgpXpMmyr9X13OsEF0tAmtivqF1lykUd9zGXXG_12HtYlW9Y5ThEGbuS1bPsUkjRauDlH9wZ-Gg0tVnmDj270&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=HEFpVKbnoeQjkjHkFKu3MFt9ri5W5MnThyWIA17NLksVbAMJb3b4J6FUWFjTqfhe62vQzBBryc0D7vtVE9sCvRaBkQXkkFQdNC1ak54UhzYYY35kSK400VtcrgLyqWDD0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=5ib3lCcyinHeLQmkwMF7EsGoPbLcoTPc-cgtukLJYPUZaLkkgAnENQdSi8NDc4l_BKxYZA1H9k0706BHQRpedGJsNRjKTrwz8gPmzzA-oap0ysiJ6VwrD01uCYx37kM30&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=iON9Jxe8QCRam1nkdNLgkffrRZCMCj6iq7qHWPZc_e3jKeMk_XnmxshFxNhoGH9SwE5Oz8w4xs83YnQN2PvBuUDeB4qmPOBf6C6AjLMoHrEWhVT0hkNgKR3X5v1OCzxI0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=xGmPTKfsNy0_1Sr5I58kO5DASLN2udyuv-7sLUq5_rfvt0h0nqG8q3lnLwCBbElWqxPrkky3q5vq3pg0VXsmEcTWWXMOeG7FgMUlD16VLKssIvRudHPE5Dua6R6EOhY40&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=LQ1q2RBSthBAZhliMjtG_6LMhlQH2DbcQYgRKlCVjFIh5IZ7GFZUyt66Y_m4cqI1Qb8Rf2oM6HCIJJLQ9rSBDT1GrsRxo5ZypZQOZ1maIbKPmaC4yLryG1OCPsyASQdm0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=VOYD8Xe7kQA0lniBYXVpAuKo3oFKAyHWpDt0JH4amXNlZ9J7vLHsxoqoc15eTAjA6oglPYd0zwAK4QpQdtZv0jvkOUq5Z5is2nQki9YITO0skfivF47CJZD_3wdgAEY50&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=hOeJu0xhC-uW6Gf8ooKdXldiqMjTwkMrPiRL7tfxCMAYgx7LQGO2FKVjBYyeRQsczHJO8YrvOhmAf48uwtZEnO4Mu9oj9tlaZBV6uinaXInS4irYgdmuHH1_fMK8aVI10&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=XlV9GqTk6b5uqDuL38kZ4M4-D19lMtmt0Nfm-OaIfmfKZXxxdkEy0_fz8Rb50xJiOME7ruSlDELDwr_q88n93Z8DbpgP-PrvolSTi43wrxjzmVSKMK-250V1wOfusJzQ0&amp;t=5e95cc64" type="text/javascript"></script>
<script src="/WebResource.axd?d=JoBkLzP19aTuxbWOhHobYndLm8rB8C7w5JAGcozHelAi0yxlDEHXqwBJPZODPDVe3kynVZnW81KTBhLcr2IKvw2&amp;t=639202794265548063" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="0939AEE7" />
	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0" />
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="5VZn2/WPkuXBozwolj7addhBwprA7ucpAGRWB2EVIc1YdiuHJR6EbilACbfHNgh/3/2B0C/m3/ggKhvce4FWRgBewGd9bf1tYY+8DfuoRDMksSQOQb3+/+c6V7pOPNNY33mv/01OHh7lNdO9A2Jrp2oI3Gj04Twqj+tELq01z0xuNwuLyNCkBj2Cu+tU0fLwfqTw0K5ux72nnjh9pUK4isdSWwba1yLKUYJnXi+7Ehib24y39mQ/8ocsaIFjmY1PjHNNx9w6M3xEhf/ChWicKSg5CBDRhM0uCpu5vTefH2iatl0GMNn6U8Hiw+L72hoEv/v01PQuq54wXgQlxRMxusmrZ5kLVYioT86ah2gva0ClowJ3J8/qowb1W+z/LBz3Oq9nfHyqZAqP6vO9I8BYW8dUU3q+BFUMSzBz1fHotHqF7g+NUFErH5P06+pU4Gw1FrizQi8vWyV2F3O7TLrxqDFhOR+QO7V46hrDBlqYOaYYbC9ZWFySQArulxwU+oY6VoK/SBqZ779ptUTgskiNOwn8GB9B+esvKZBywgiDkbkdcMLYaRjnk+IENgsrhR+WZOzcHFaPGTWlarvvTWbdp6fcMcUjdCEFwEt3i4fTh8CeGfSC1r8eXZdMWIuh39lE7U88ch91uH58vj6mSrZ8tv9u+9V1F4hIhgybKb6kTKjdMXtUtbFDL9bbgIzaLtAB2hnTiT5JdY6Tk7hWpVZy5geioEovzWF2rgCYfkPiWDT21OSudr+X82xXBqeP8cPavQdTejsdks3R9MuWjhsggwKzHVupTZvvGN2KfN91x/gYhgjWUJAg/k7r2gv9jr3Ppwa5C6HDAyZ6hn0vbRb6UgRfS6BcDvNtYNZ9O/gXozcmpdkNOTif6N2RMA7aPY+7v66Pqiuroyv+tXG5HFFGwvAQwL1WoVOKdwn851P9B3U//ETXROPwiplc54ii2zLroUmtkk9OhTEAhxJLALbw5GueA6hVmhqCYSu1v6r+LeElLMX9y2eUCj92mHUdQCb0vh+/BTneZP11IPTSabBGmZJ5T9tcXjBJduyxYdNhJeU=" />
</div>
           
        <div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager1', 'form1', ['tctl00$SelectRegion$updChangeRegion','SelectRegion_updChangeRegion','tctl00$UpdRegion','UpdRegion','tctl00$ContentPlaceHolder1$updRegionSelector','ContentPlaceHolder1_updRegionSelector'], [], [], 600, 'ctl00');
//]]>
</script>

            <button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-topD">
                <i class="fas fa-arrow-up"></i>
</button>
<!-- Simple splash screen-->
<div class="splash">
 <div class="color-line"></div>
 <div class="splash-title">
 <h1>ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼/Punjab Land Records</h1>
 <p>ਕਿਰਪਾ ਕਰਕੇ ਉਡੀਕ ਕਰੋ ਜਦੋਂ ਤੱਕ ਅਸੀਂ ਤੁਹਾਡੇ ਲਈ ਖੋਜ ਮੋਡੀਊਲ ਨੂੰ ਸੈਟਅਪ ਕਰਦੇ ਹਾਂ./Please wait while we setup the search module for you. </p>
 <img src="ui-assets/images/loading-bars.svg" width="64" height="64" alt="Loading.."/>
  </div>
   </div>
		<div id="updWebsite" style="display:none;">
	
				<div class="loadingContainer">
					<div class="loading">
						<img src="ui-assets/images/loading-bars.svg" alt="Loading.." width="64" height="64" />
						&nbsp;
					&nbsp;
					</div>
				</div>
			
</div>
<!-- Header -->
	
        
        <div id="header">
            <div id="plrs-header">
                 
    <div class="plrs-header-row">
     
        <!-- LOGO -->
        <div class="plrs-left">
        <div class="plrs-logo">
            <img src="ui-assets/images/logo.png" alt="Punjab Land Records" />
            <div class="plrs-logo-text">
                ਪੰਜਾਬ ਲੈਂਡ ਰਿਕਾਰਡਜ਼
                <span>Punjab Land Records</span>
            </div>
        </div>
        <div class="plrs-menu header-link hide-menu"><i class="fa fa-bars"></i></div>
            </div>
        <!-- REGION -->
        <div class="plrs-region">
               
             

<div id="dvChangeRegion" class="modal fade">

	<div class="modal-dialog modal-lg" style="min-width:80%">
		<div class="modal-content">

			<div id="SelectRegion_updChangeRegion">
	

					<div class="modal-body">
						<div class="row">
                            <div class="col-md-12 m-t-sm">
                                <fieldset id="SelectRegion_fsSelectRegion" class="form_ font-resize-scope">
										<legend id="SelectRegion_lgSelectRegion" class="lg p-sm head-legend">
											<i class="fa fa-map-marker"></i>
											<span id="SelectRegion_lbllgRegionInfo">ਖੇਤਰ ਚੁਣੋ/Select the Region</span>
										</legend>
							   <div class="dvSelectRegion m-t-sm m-b-sm">
                                   <div class="row form-group">
                                                    <div class="col-md-12" >
                                                		<span id="SelectRegion_Label2" class="label label-lg-font-size">ਜਮਬੰਦੀ ਪੀਰੀਅਡ/Jamabandi Period</span>
														<table id="SelectRegion_rdPeriod" class="form-control smedium m-t-sm">
		<tr>
			<td><span class="radiobtn"><input id="SelectRegion_rdPeriod_0" type="radio" name="ctl00$SelectRegion$rdPeriod" value="1" checked="checked" tabindex="1" /><label for="SelectRegion_rdPeriod_0">ਮੌਜੂਦਾ/Current</label></span></td><td><span class="radiobtn"><input id="SelectRegion_rdPeriod_1" type="radio" name="ctl00$SelectRegion$rdPeriod" value="2" onclick="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$rdPeriod$1\&#39;,\&#39;\&#39;)&#39;, 0)" tabindex="1" /><label for="SelectRegion_rdPeriod_1">ਪਿਛਲਾ/Previous</label></span></td>
		</tr>
	</table>
                                                        </div>
                                                </div>
                                <div class="row form-group">
								    <div class="col-sm-3 district-dropdown" style="position:relative; z-index:9">
									    <span id="SelectRegion_lblddlDistrict" class="label  label-lg-font-size">ਜ਼ਿਲ੍ਹਾ/District</span>
									    <select name="ctl00$SelectRegion$ddlDistrict" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlDistrict\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlDistrict" tabindex="2" class="form-control">
		<option selected="selected" value="">ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Choose District</option>
		<option value="7">ਅੰਮ੍ਰਿਤਸਰ/Amritsar</option>
		<option value="8">ਬਰਨਾਲਾ/Barnala</option>
		<option value="9">ਬਠਿੰਡਾ/Bathinda</option>
		<option value="10">ਫਰੀਦਕੋਟ/Faridkot</option>
		<option value="11">ਫਤਿਹਗੜ੍ਹ ਸਾਹਿਬ/Fatehgarh Sahib</option>
		<option value="12">ਫ਼ਾਜ਼ਿਲਕਾ/Fazilka</option>
		<option value="13">ਫਿਰੋਜਪੁਰ/Ferozepur</option>
		<option value="14">ਗੁਰਦਾਸਪੁਰ/Gurdaspur</option>
		<option value="15">ਹੁਸ਼ਿਆਰਪੁਰ/Hoshiarpur</option>
		<option value="16">ਜਲੰਧਰ/Jalandhar</option>
		<option value="17">ਕਪੂਰਥਲਾ/Kapurthala</option>
		<option value="18">ਲੁਧਿਆਣਾ/Ludhiana</option>
		<option value="18953">ਮਲੇਰਕੋਟਲਾ/Malerkotla</option>
		<option value="19">ਮਾਨਸਾ/Mansa</option>
		<option value="20">ਮੋਗਾ/Moga</option>
		<option value="21">ਪਠਾਨਕੋਟ/Pathankot</option>
		<option value="22">ਪਟਿਆਲਾ/Patiala</option>
		<option value="23">ਰੂਪਨਗਰ/Rupnagar</option>
		<option value="24">ਐਸ. ਏ. ਐਸ ਨਗਰ/S.A.S. Nagar</option>
		<option value="25">ਸੰਗਰੂਰ/Sangrur</option>
		<option value="26">ਸ਼ਹੀਦ ਭਗਤ ਸਿੰਘ ਨਗਰ (ਨਵਾਂਸ਼ਹਿਰ)/Shahid Bhagat Singh Nagar(Nawanshahr)</option>
		<option value="27">ਸ਼੍ਰੀ ਮੁਕੱਤਸਰ ਸਾਹਿਬ/Sri Muktsar Sahib</option>
		<option value="28">ਤਰਨ ਤਾਰਨ/Tarn Taran</option>

	</select>
                                        <span id="SelectRegion_RFVDistrict" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District</span>
								    </div>
                                    <div class="col-sm-3 m-b-md tehsil-dropdown" style="position:relative; z-index:8">
									    <span id="SelectRegion_lblddlTehsil" class="label label-lg-font-size">ਤਹਿਸੀਲ/Tehsil</span>
									    <select name="ctl00$SelectRegion$ddlTehsil" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlTehsil\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlTehsil" disabled="disabled" tabindex="3" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਤਹਿਸੀਲ ਚੁਣੋ/Choose Tehsil</option>

	</select>
                                        <span id="SelectRegion_RFVTehsil" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil</span>
								    </div>
                                    <div class="col-sm-3 village-dropdown" style="position:relative; z-index:7">
									    <span id="SelectRegion_lblddlVillage" class="label label-lg-font-size">ਪਿੰਡ/Village</span>
									    <select name="ctl00$SelectRegion$ddlVillage" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlVillage\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlVillage" disabled="disabled" tabindex="4" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਪਿੰਡ ਚੁਣੋ/Choose Village</option>

	</select>
                                        <span id="SelectRegion_RFVVillage" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village</span>
								    </div>
                                    <div class="col-sm-3 m-b-md year-dropdown" style="position:relative; z-index:6">
									    <span id="SelectRegion_lblddlYear" class="label label-lg-font-size">ਸਾਲ/Year</span>
									    <select name="ctl00$SelectRegion$ddlYear" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$SelectRegion$ddlYear\&#39;,\&#39;\&#39;)&#39;, 0)" id="SelectRegion_ddlYear" disabled="disabled" tabindex="5" class="aspNetDisabled form-control smedium m-t-sm">
		<option selected="selected" value="">ਸਾਲ ਚੁਣੋ/Choose Year</option>

	</select>
                                        <span id="SelectRegion_RFVYear" class="text-danger label-md-font-size" style="display:none;">ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year</span>
								    </div>
                                </div>
							</div>
                                    </fieldset>
                            </div>

						</div>
					</div>
					<div class="modal-footer">
						<!-- Submit Button-->
						<input type="submit" name="ctl00$SelectRegion$btnSearch" value="ਖੇਤਰ ਬਦਲੋ/Change Region" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$SelectRegion$btnSearch&quot;, &quot;&quot;, true, &quot;ChangeRegion&quot;, &quot;&quot;, false, false))" id="SelectRegion_btnSearch" tabindex="6" class="btn btn-pimary submit-custom-btn" />
						<button id="SelectRegion_btnCancel" class="btn btn-danger btn-no" data-dismiss="modal" TabIndex="7">ਰੱਦ ਕਰੋ/Cancel</button>
					</div>
				
</div>
			
			

		</div>
	</div>
</div>

            <div id="UpdRegion">
	
                    







                
</div>
        </div>

        <!-- ACTIONS -->
        <div class="plrs-actions">
            <div class="plrs-font">
                 <input type="button" id="btnincreasefonts"  value=" A+ " />
                 <input type="button" id="btndecreasefonts"  value=" A- " />
                 <input type="button" id="btnresetfonts" value=" A= " />
            </div>

            <a href="Login.aspx" class="plrs-login">
                <i class="fa fa-lock"></i>
                Official Login
            </a>
        </div>

    </div>
            
</div>

</div>


        <div id="divBackground" class="modal"></div>
		
        
<link href="../ui-assets/Pgstyles/uc_navugatonmenu.css" rel="stylesheet" />
<!-- Navigation -->
<aside id="menu">
	<div id="navigation">
		<nav class="nav-primary">
			<ul class="nav">
				
				
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl00_liItem">
							<a href="Default.aspx?itemPID=1">
								    
                                    <i class='fa-solid fa-house'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl00_bBG" class="bg-info"></b>
								</i>
								
								<span>ਮੁੱਖ ਪੰਨਾ/Home</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl01_liItem">
							<a href="OnlineRequestStatus.aspx?itemPID=77">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl01_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਟਰੈਕ ਐਪਲੀਕੇਸ਼ਨ/Track Application</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_liItem">
							<a href="./?itemPID=82">
								    
                                    <i class='fa-solid fa-file-export'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl02_bBG" class="bg-primary2"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl02_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਸ਼ਿਕਾਇਤ ਨਿਵਾਰਨ/Grievance Redressal</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl02_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Grievance.aspx?RefNo=1&itemID=83&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦਾਖਲ ਕਰੋ/Submit Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_liItem">
											<a href="GrievanceTrack.aspx?RefNo=2&itemID=84&itemPID=82">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl02_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਸ਼ਿਕਾਇਤ ਦੀ ਜਾਂਚ ਕਰੋ/Track Grievance</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_liItem">
							<a href="Jamabandi.aspx?itemPID=3">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl03_bBG" class="bg-success"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl03_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਜਮ੍ਹਾਂਬੰਦੀ ਵੇਖੋ/View Jamabandi</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl03_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Jamabandi.aspx?section=Owner-Name-Wise&itemID=7&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਮਾਲਕ ਦੇ ਨਾਮ ਮੁਤਾਬਕ/Owner Name Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Jamabandi.aspx?section=Khewat-Number-Wise&itemID=8&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖੇਵਟ ਨੰ: ਮੁਤਾਬਕ/Khewat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_liItem">
											<a href="Jamabandi.aspx?section=Khasra-Number-Wise&itemID=9&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl02_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਸਰਾ ਨੰ: ਮੁਤਾਬਕ/Khasra No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_liItem">
											<a href="Jamabandi.aspx?section=Khatouni-Number-Wise&itemID=10&itemPID=3">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl03_repNavigationMenuLevel2_ctl03_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਖਤੌਨੀ ਨੰ: ਮੁਤਾਬਕ/Khatouni No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_liItem">
							<a href="Mutation.aspx?itemPID=4">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl04_bBG" class="bg-danger"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl04_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਇੰਤਕਾਲ ਵੇਖੋ/View Mutation</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl04_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Mutation.aspx?section=Mutation-Number-Wise&itemID=13&itemPID=4">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl04_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਇੰਤਕਾਲ ਨੰ: ਮੁਤਾਬਕ/Mutation No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_liItem">
							<a href="Roznamcha.aspx?itemPID=5">
								    
                                    <i class='fa-solid fa-book'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl05_bBG" class="bg-info"></b>
								</i>
								<span id="ctl00_NavigationMenu_repNavigationMenu_ctl05_spanArrow" class="pull-right">
									<i class="fa fa-angle-down text"></i>
									<i class="fa fa-angle-up text-active"></i>
								</span>
								<span>ਰੋਜਨਾਮਚਾ ਵੇਖੋ/View Roznamcha</span>
                                 
							</a>
							
							
							
                            <ul id="ctl00_NavigationMenu_repNavigationMenu_ctl05_ulSubMenu" class="nav lt">
								
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_liItem">
											<a href="Roznamcha.aspx?section=Rapat-Number-Wise&itemID=11&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl00_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਰਿਪੋਰਟ ਨੰਬਰ ਮੁਤਾਬਕ/Rapat No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
										<li id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_liItem">
											<a href="Roznamcha.aspx?section=Waqiati-Number-Wise&itemID=12&itemPID=5">
												<i id="ctl00_NavigationMenu_repNavigationMenu_ctl05_repNavigationMenuLevel2_ctl01_iRightArrow" class="fa fa-angle-right"></i>
												
												<span>ਵਾਕਿਆਤੀ ਮੁਤਾਬਕ/Waqiati No. Wise</span>
                                                 
											</a>
											
											
											
										</li>
									
							</ul>
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl06_liItem">
							<a href="RegistryDeed.aspx?itemPID=21">
								    
                                    <i class='fa-regular fa-copy'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl06_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਰਜਿਸਟਰਡ ਡੀਡ ਵੇਖੋ/View Registered Deed</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl07_liItem">
							<a href="FardStatus.aspx?itemPID=29">
								    
                                    <i class='fa fa-search'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl07_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਫਰਦ ਬੇਨਤੀ ਸਥਿਤੀ/Fard Request Status</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl08_liItem">
							<a href="GroundTruthingDataMap2.aspx?itemPID=85">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl08_bBG" class="bg-success"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-2 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-2 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl09_liItem">
							<a href="GroundTruthingDataMap3.aspx?itemPID=86">
								    
                                    <i class='fa fa-map-marker'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl09_bBG" class="bg-danger"></b>
								</i>
								
								<span>MGMN ਫਾਈਨਲ ਮੈਪ-3 ਡੇਟਾ ਵੇਖੋ/View MGMN Final Map-3 Data</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl10_liItem">
							<a href="IPWTD.aspx?itemPID=15">
								    
                                    <i class='fa fa-university'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl10_bBG" class="bg-info"></b>
								</i>
								
								<span>ਇਨਟੈਗਰੇਟਿਡ ਜਾਇਦਾਦ/Integrated Property</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl11_liItem">
							<a href="faq.aspx?itemPID=33">
								    
                                    <i class='fa fa-question-circle'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl11_bBG" class="bg-warning"></b>
								</i>
								
								<span>ਐੱਫ ਏ ਕਿਊ/FAQ</span>
                                 
							</a>
							
							
							
                            
						</li>
					
						<li id="ctl00_NavigationMenu_repNavigationMenu_ctl12_liItem">
							<a href="UserManual.aspx?itemPID=35">
								    
                                    <i class='fa fa-user'>
									<b id="ctl00_NavigationMenu_repNavigationMenu_ctl12_bBG" class="bg-primary2"></b>
								</i>
								
								<span>ਉਪਯੋਗ ਪੁਸਤਕ/User Manual</span>
                                 
							</a>
							
							
							
                            
						</li>
					
                				
			</ul>
		</nav>
	</div>
</aside>


	    
		<div id="wrapper" >
            <div class="page-body">
                <div class="normalheader transition animated fadeIn small-header hide-mob hidden-xs hidden-sm">
				<div class="hpanel">
					<div class="panel-body">
						<div class="row">
							<div class="col-sm-12">
                                <div class="nav-pills bg-light breadcrumbs">
                                    <span id="SiteMapPath1"><a href="#SiteMapPath1_SkipLink" style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;">Skip Navigation Links</a><span><a href="/Default.aspx">ਔਨਲਾਈਨ ਸੇਵਾਵਾਂ/Online Services</a></span><span> &gt; </span><span>ਸਬਸਕ੍ਰਿਪਸ਼ਨ/Subscription</span><a id="SiteMapPath1_SkipLink"></a></span>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>

		<div class="content animate-panel">
            
    <input type="hidden" name="ctl00$ContentPlaceHolder1$hiddenLastFocus" id="ContentPlaceHolder1_hiddenLastFocus" />
    
    <div class="content transition animated fadeIn">
        <div class="panel hpanel dblue">
            <div class="panel-heading">
                <div class="form-horizontal text-center ">
                    <h3><b>ਸਬਸਕ੍ਰਿਪਸ਼ਨ ਲਈ ਬੇਨਤੀ<br />
                        Request for Subscription</b></h3>
                </div>
            </div>
            <div class="panel-body">
                <div class="form-horizontal">

                    <div id="ContentPlaceHolder1_updRegionSelector">
	

                            <input type="submit" name="ctl00$ContentPlaceHolder1$btnShowPopup" value="" id="ContentPlaceHolder1_btnShowPopup" style="display: none" />
                            <fieldset id="ContentPlaceHolder1_FieldsetApplicantDetail" class="form_ font-resize-scope" style="background-color: white">
                                <legend id="ContentPlaceHolder1_legendApplication" class="lg p-sm text-left head-legend">
                                    <i class="fa fa-info-circle hidden"></i>
                                    <span id="ContentPlaceHolder1_lblApplicantDetailH2">1. ਬਿਨੈਕਾਰ ਦਾ ਵੇਰਵਾ/Details of Applicant</span>
                                </legend>
                                <div id="ContentPlaceHolder1_pnlApplicantInfo">
		
                                    <div class="row form-group">
                                        <div class="col-sm-6 m-t-sm">
                                            <span id="ContentPlaceHolder1_lblNameH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਨਾਮ/Name of Applicant<span class="text-danger">*</span>
											        </span>
                                            <span id="ContentPlaceHolder1_RFVName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Name</span>

                                            

                                            <input name="ctl00$ContentPlaceHolder1$txtName" type="text" maxlength="200" id="ContentPlaceHolder1_txtName" tabindex="1" class="form-control label-lg-font-size" />

                                        </div>

                                        <div class="col-sm-6 m-t-sm">
                                            <span id="ContentPlaceHolder1_Label2" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦੇ ਪਿਤਾ ਦਾ ਨਾਮ/Name of Father of Applicant<span class="text-danger">*</span>
											        </span>
                                            <span id="ContentPlaceHolder1_RFVFatherName" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Father Name</span>

                                            
                                            <input name="ctl00$ContentPlaceHolder1$txtFatherName" type="text" maxlength="200" id="ContentPlaceHolder1_txtFatherName" tabindex="2" class="form-control label-lg-font-size" />
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col-sm-6 m-t-sm">
                                            <span id="ContentPlaceHolder1_lblResidentH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦੀ ਰਿਹਾਇਸ਼<br>/Residence of Applicant<span class="text-danger">*</span>
											        </span>
                                            <select name="ctl00$ContentPlaceHolder1$ddlResidentStatus" onchange="javascript:setTimeout(&#39;__doPostBack(\&#39;ctl00$ContentPlaceHolder1$ddlResidentStatus\&#39;,\&#39;\&#39;)&#39;, 0)" id="ddlResidentStatus" tabindex="3" class="form-control">
			<option selected="selected" value="Ind">ਭਾਰਤ ਨਿਵਾਸੀ/India Resident</option>
			<option value="NRI">ਐਨ.ਆਰ.ਆਈ (ਗੈਰ-ਨਿਵਾਸੀ ਭਾਰਤੀ)/NRI(Non-Resident Indian)</option>

		</select>

                                        </div>
                                        <div class="col-sm-6 m-t-sm">
                                            <div class="col-sm-4 m-t-sm">
                                                <span id="ContentPlaceHolder1_Label1" class="label-lg-font-size">ਦੇਸ਼ ਦਾ ਕੋਡ/ Country Code<span class="text-danger">*</span>
											        </span>


                                                <span id="rfvCountryCode" style="color:Red;display:none;">Country code is required</span>

                                                <span id="revCountryCode" style="color:Red;display:none;">Invalid country code format. Enter 1 to 3 digits.</span>
                                                <input name="ctl00$ContentPlaceHolder1$txtCountryCode" type="text" value="91" maxlength="3" readonly="readonly" id="ContentPlaceHolder1_txtCountryCode" tabindex="4" class="form-control label-lg-font-size" />


                                            </div>
                                            <div class="col-sm-8 m-t-sm">
                                                <span id="ContentPlaceHolder1_lblMobileNumberH" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦਾ ਮੋਬਾਈਲ ਨੰ./Mobile No. of Applicant<span class="text-danger">*</span>
											        </span>
                                                <span id="RFVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the Mobile number</span>
                                                
                                                <span id="REVMobileNumber" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter a valid mobile number (6 to 15 digits).</span>

                                                <input name="ctl00$ContentPlaceHolder1$txtMobileNumber" type="text" maxlength="15" id="ContentPlaceHolder1_txtMobileNumber" tabindex="5" class="form-control label-lg-font-size" />


                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row form-group">

                                        <div class="col-sm-6 m-t-sm">
                                            <span id="ContentPlaceHolder1_lblEmail" class="label-lg-font-size">ਬਿਨੈਕਾਰ ਦੀ ਈਮੇਲ/Email of Applicant</span>


                                            <span id="REVEmail" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter a valid email address.</span>

                                            <input name="ctl00$ContentPlaceHolder1$txtEmail" type="text" maxlength="200" id="ContentPlaceHolder1_txtEmail" tabindex="6" class="form-control label-lg-font-size" />

                                        </div>

                                        <div class="col-sm-3 m-t-sm text-center" style="margin-top: 30px">
                                            <a id="ContentPlaceHolder1_btnGetOtp" tabindex="7" class="btn btn-primary" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ContentPlaceHolder1$btnGetOtp&quot;, &quot;&quot;, true, &quot;GrpRequestotp&quot;, &quot;&quot;, false, true))">
                                                <i class="fas fa-mobile"></i>
                                                <span id="ContentPlaceHolder1_lblSendOTP">ਮੋਬਾਈਲ 'ਤੇ ਓਟੀਪੀ ਭੇਜੋ/Send OTP on mobile</span></a>
                                        </div>
                                        <div class="col-sm-3 m-t-sm" style="margin-top: 30px">
                                            
                                        </div>
                                    </div>

                                    <div class="row form-group" style="border-top: solid; border-width: thin">

                                        <div id="ContentPlaceHolder1_pnlOTP">
			
                                            <div class="col-sm-4 m-t-sm">
                                                <span id="ContentPlaceHolder1_lblVerifyOTP" class="label-lg-font-size">ਆਪਣੇ ਮੋਬਾਈਲ 'ਤੇ ਪ੍ਰਾਪਤ ਹੋਇਆ OTP ਦਰਜ ਕਰੋ/Enter OTP received on your mobile <span class="text-danger">*</span>
											        </span>

                                                <span id="ContentPlaceHolder1_RequiredFieldValidator2" class="text-danger label-lg-font-sizeW" style="display:none;">Please enter the OTP number</span>
                                                <input name="ctl00$ContentPlaceHolder1$txtOTP" type="text" maxlength="10" id="ContentPlaceHolder1_txtOTP" tabindex="8" class="form-control label-lg-font-size" />
                                            </div>
                                            <div class="col-sm-2 m-t-sm" style="margin-top: 30px">
                                                

                                                <a id="ContentPlaceHolder1_btnOTPVerify" tabindex="9" class="btn btn-primary" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ContentPlaceHolder1$btnOTPVerify&quot;, &quot;&quot;, true, &quot;GrpRequestVOTP&quot;, &quot;&quot;, false, true))">
                                                         <i class="fas fa-check-circle"></i> OTP ਦੀ ਪੁਸ਼ਟੀ ਕਰੋ/Verify OTP
                                                      
                                                </a>


                                            </div>
                                        
		</div>
                                    </div>
                                
	</div>
                            </fieldset>

                            
                            
                            
                            
                            
                            
                            

                            
                            
                            
                            

                            
                            

                            
                            

                            <div id="ContentPlaceHolder1_pnlmsgConfirm" class="sweet-modal" style="display: none;">
		
                                <div class="sweet-modal-header">
                                    Alert
                                </div>
                                <div class="sweet-modal-body">
                                    
                                </div>
                                <div class="sweet-modal-footer">
                                    <input type="submit" name="ctl00$ContentPlaceHolder1$btnOK" value="OK" id="ContentPlaceHolder1_btnOK" class="btn" />
                                </div>
                            
	</div>
                            


                        
</div>

                </div>
            </div>
        </div>
    </div>


            
			
			
			
			
			
			
		</div>

    </div>
    <!-- Footer-->
    <footer class="footer footer-font">

    <!-- Govt -->
    <div class="digi-topBoderThickDis">
        <div class="container-fluid text-center">
            <span>ਮਾਲ, ਮੁੜ ਵਸੇਬਾ ਅਤੇ ਆਪਦਾ ਪ੍ਰਬੰਧਨ ਵਿਭਾਗ,ਪੰਜਾਬ ਸਰਕਾਰ, ਭਾਰਤ / Department of Revenue, Rehabilitation and Disaster Management, Government of Punjab, India.
            </span>
        </div>
    </div>

    <!-- Copyright -->
    <div class="digi-topBoder">
        <div class="container-fluid text-center">
            <span>ਕਾਪੀਰਾਈਟ © 2025 ਪੰਜਾਬ। ਸਾਰੇ ਹੱਕ ਰਾਖਵੇਂ ਹਨ। / Copyright © 2025  Punjab. All rights reserved.
            </span>
        </div>
    </div>

    <!-- Stats -->
    <div class="digi-topBottomBoder footer-stats">
        <div class="container-fluid">
            <div class="footer-stats-row">
                <span class="badge-pill">
                    ਕੁੱਲ ਵਿਜ਼ਿਟਰ/Total Visitors :
                    <span id="lblv">2380020</span>
                </span>

                <span class="badge-pill">
                    ਆਖਰੀ ਵਾਰ ਅੱਪਡੇਟ ਕੀਤਾ/Last Updated :
                    <span id="lblud">12/10/2026</span>
                </span>
            </div>
        </div>
    </div>

</footer>

</div>	          
    <script src="ui-assets/vendor/bootstrap/dist/js/bootstrap.min.js" nonce="h+nLG9f6Xz7fhyYbY0csKQ"></script>
	<script src="ui-assets/vendor/datatables_with_buttons/datatables.min.js" nonce="h+nLG9f6Xz7fhyYbY0csKQ"></script>
	<script src="ui-assets/vendor/virtual-keyboard/js/keyboard.js" type="text/javascript" nonce="h+nLG9f6Xz7fhyYbY0csKQ"></script>
 <!-- App scripts -->
    <script src="ui-assets/scripts/homer.js" nonce="h+nLG9f6Xz7fhyYbY0csKQ"></script>
    <script src="ui-assets/Pgscript/masterpg.js" nonce="h+nLG9f6Xz7fhyYbY0csKQ"></script>
    <script src="ui-assets/scripts/select2.min.js" nonce="h+nLG9f6Xz7fhyYbY0csKQ" > </script>
    <script src="ui-assets/scripts/BackToTopN.js" nonce="h+nLG9f6Xz7fhyYbY0csKQ" > </script>              
</div>

<script type="text/javascript">
//<![CDATA[
var Page_Validators =  new Array(document.getElementById("SelectRegion_RFVDistrict"), document.getElementById("SelectRegion_RFVTehsil"), document.getElementById("SelectRegion_RFVVillage"), document.getElementById("SelectRegion_RFVYear"), document.getElementById("ContentPlaceHolder1_RFVName"), document.getElementById("ContentPlaceHolder1_RFVFatherName"), document.getElementById("rfvCountryCode"), document.getElementById("revCountryCode"), document.getElementById("RFVMobileNumber"), document.getElementById("REVMobileNumber"), document.getElementById("REVEmail"), document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var SelectRegion_RFVDistrict = document.all ? document.all["SelectRegion_RFVDistrict"] : document.getElementById("SelectRegion_RFVDistrict");
SelectRegion_RFVDistrict.controltovalidate = "SelectRegion_ddlDistrict";
SelectRegion_RFVDistrict.focusOnError = "t";
SelectRegion_RFVDistrict.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਜ਼ਿਲ੍ਹਾ ਚੁਣੋ/Please Select District";
SelectRegion_RFVDistrict.display = "Dynamic";
SelectRegion_RFVDistrict.validationGroup = "ChangeRegion";
SelectRegion_RFVDistrict.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVDistrict.initialvalue = "";
var SelectRegion_RFVTehsil = document.all ? document.all["SelectRegion_RFVTehsil"] : document.getElementById("SelectRegion_RFVTehsil");
SelectRegion_RFVTehsil.controltovalidate = "SelectRegion_ddlTehsil";
SelectRegion_RFVTehsil.focusOnError = "t";
SelectRegion_RFVTehsil.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਤਹਿਸੀਲ ਚੁਣੋ/Please Select Tehsil";
SelectRegion_RFVTehsil.display = "Dynamic";
SelectRegion_RFVTehsil.validationGroup = "ChangeRegion";
SelectRegion_RFVTehsil.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVTehsil.initialvalue = "";
var SelectRegion_RFVVillage = document.all ? document.all["SelectRegion_RFVVillage"] : document.getElementById("SelectRegion_RFVVillage");
SelectRegion_RFVVillage.controltovalidate = "SelectRegion_ddlVillage";
SelectRegion_RFVVillage.focusOnError = "t";
SelectRegion_RFVVillage.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਪਿੰਡ ਚੁਣੋ/Please Select Village";
SelectRegion_RFVVillage.display = "Dynamic";
SelectRegion_RFVVillage.validationGroup = "ChangeRegion";
SelectRegion_RFVVillage.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVVillage.initialvalue = "";
var SelectRegion_RFVYear = document.all ? document.all["SelectRegion_RFVYear"] : document.getElementById("SelectRegion_RFVYear");
SelectRegion_RFVYear.controltovalidate = "SelectRegion_ddlYear";
SelectRegion_RFVYear.focusOnError = "t";
SelectRegion_RFVYear.errormessage = "ਕਿਰਪਾ ਕਰਕੇ ਸਾਲ ਚੁਣੋ/Please Select Year";
SelectRegion_RFVYear.display = "Dynamic";
SelectRegion_RFVYear.validationGroup = "ChangeRegion";
SelectRegion_RFVYear.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
SelectRegion_RFVYear.initialvalue = "";
var ContentPlaceHolder1_RFVName = document.all ? document.all["ContentPlaceHolder1_RFVName"] : document.getElementById("ContentPlaceHolder1_RFVName");
ContentPlaceHolder1_RFVName.controltovalidate = "ContentPlaceHolder1_txtName";
ContentPlaceHolder1_RFVName.focusOnError = "t";
ContentPlaceHolder1_RFVName.errormessage = "Please enter the Name";
ContentPlaceHolder1_RFVName.display = "Dynamic";
ContentPlaceHolder1_RFVName.validationGroup = "GrpRequest";
ContentPlaceHolder1_RFVName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVName.initialvalue = "";
var ContentPlaceHolder1_RFVFatherName = document.all ? document.all["ContentPlaceHolder1_RFVFatherName"] : document.getElementById("ContentPlaceHolder1_RFVFatherName");
ContentPlaceHolder1_RFVFatherName.controltovalidate = "ContentPlaceHolder1_txtFatherName";
ContentPlaceHolder1_RFVFatherName.focusOnError = "t";
ContentPlaceHolder1_RFVFatherName.errormessage = "Please enter the Father Name";
ContentPlaceHolder1_RFVFatherName.display = "Dynamic";
ContentPlaceHolder1_RFVFatherName.validationGroup = "GrpReques";
ContentPlaceHolder1_RFVFatherName.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RFVFatherName.initialvalue = "";
var rfvCountryCode = document.all ? document.all["rfvCountryCode"] : document.getElementById("rfvCountryCode");
rfvCountryCode.controltovalidate = "ContentPlaceHolder1_txtCountryCode";
rfvCountryCode.focusOnError = "t";
rfvCountryCode.errormessage = "Country code is required";
rfvCountryCode.display = "Dynamic";
rfvCountryCode.validationGroup = "GrpRequestotp";
rfvCountryCode.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
rfvCountryCode.initialvalue = "";
var revCountryCode = document.all ? document.all["revCountryCode"] : document.getElementById("revCountryCode");
revCountryCode.controltovalidate = "ContentPlaceHolder1_txtCountryCode";
revCountryCode.focusOnError = "t";
revCountryCode.errormessage = "Invalid country code format. Enter 1 to 3 digits.";
revCountryCode.display = "Dynamic";
revCountryCode.validationGroup = "GrpRequestotp";
revCountryCode.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
revCountryCode.validationexpression = "^[1-9][0-9]{0,2}$";
var RFVMobileNumber = document.all ? document.all["RFVMobileNumber"] : document.getElementById("RFVMobileNumber");
RFVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
RFVMobileNumber.focusOnError = "t";
RFVMobileNumber.errormessage = "Please enter the Mobile number";
RFVMobileNumber.display = "Dynamic";
RFVMobileNumber.validationGroup = "GrpRequestotp";
RFVMobileNumber.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
RFVMobileNumber.initialvalue = "";
var REVMobileNumber = document.all ? document.all["REVMobileNumber"] : document.getElementById("REVMobileNumber");
REVMobileNumber.controltovalidate = "ContentPlaceHolder1_txtMobileNumber";
REVMobileNumber.focusOnError = "t";
REVMobileNumber.errormessage = "Please enter a valid mobile number (6 to 15 digits).";
REVMobileNumber.display = "Dynamic";
REVMobileNumber.validationGroup = "GrpRequestotp";
REVMobileNumber.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
REVMobileNumber.validationexpression = "^\\d{6,15}$";
var REVEmail = document.all ? document.all["REVEmail"] : document.getElementById("REVEmail");
REVEmail.controltovalidate = "ContentPlaceHolder1_txtEmail";
REVEmail.errormessage = "Please enter a valid email address.";
REVEmail.display = "Dynamic";
REVEmail.validationGroup = "GrpRequestotp";
REVEmail.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
REVEmail.validationexpression = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
var ContentPlaceHolder1_RequiredFieldValidator2 = document.all ? document.all["ContentPlaceHolder1_RequiredFieldValidator2"] : document.getElementById("ContentPlaceHolder1_RequiredFieldValidator2");
ContentPlaceHolder1_RequiredFieldValidator2.controltovalidate = "ContentPlaceHolder1_txtOTP";
ContentPlaceHolder1_RequiredFieldValidator2.focusOnError = "t";
ContentPlaceHolder1_RequiredFieldValidator2.errormessage = "Please enter the OTP number";
ContentPlaceHolder1_RequiredFieldValidator2.display = "Dynamic";
ContentPlaceHolder1_RequiredFieldValidator2.validationGroup = "GrpRequestVOTP";
ContentPlaceHolder1_RequiredFieldValidator2.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ContentPlaceHolder1_RequiredFieldValidator2.initialvalue = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        
theForm.oldSubmit = theForm.submit;
theForm.submit = WebForm_SaveScrollPositionSubmit;

theForm.oldOnSubmit = theForm.onsubmit;
theForm.onsubmit = WebForm_SaveScrollPositionOnSubmit;
WebForm_AutoFocus('ContentPlaceHolder1_txtName');Sys.Application.add_init(function() {
    $create(Sys.UI._UpdateProgress, {"associatedUpdatePanelId":null,"displayAfter":500,"dynamicLayout":true}, null, null, $get("updWebsite"));
});

document.getElementById('SelectRegion_RFVDistrict').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVDistrict'));
}

document.getElementById('SelectRegion_RFVTehsil').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVTehsil'));
}

document.getElementById('SelectRegion_RFVVillage').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVVillage'));
}

document.getElementById('SelectRegion_RFVYear').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('SelectRegion_RFVYear'));
}

document.getElementById('ContentPlaceHolder1_RFVName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVName'));
}

document.getElementById('ContentPlaceHolder1_RFVFatherName').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RFVFatherName'));
}

document.getElementById('rfvCountryCode').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('rfvCountryCode'));
}

document.getElementById('revCountryCode').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('revCountryCode'));
}

document.getElementById('RFVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('RFVMobileNumber'));
}

document.getElementById('REVMobileNumber').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('REVMobileNumber'));
}

document.getElementById('REVEmail').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('REVEmail'));
}

document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ContentPlaceHolder1_RequiredFieldValidator2'));
}
Sys.Application.add_init(function() {
    $create(Sys.Extended.UI.ModalPopupBehavior, {"backgroundCssClass":"modalBackground","cancelControlID":"ContentPlaceHolder1_btnOK","dynamicServicePath":"/Subscription.aspx","id":"ModalPopupExtenderAlert","popupControlID":"ContentPlaceHolder1_pnlmsgConfirm"}, null, null, $get("ContentPlaceHolder1_btnShowPopup"));
});
//]]>
</script>
</form>

</body>

</html>
